function [a_pattern, b_pattern, a, b] = complementaryGolaySequence(samplingTime, sequence_duration, sequence_order)
% Golay complementary excitation
% This function generates a Golay complementary pair excitation with 2^n
% elements and sequence_duration seconds longer.
% -------------------------------------------------------------------------
% USAGE:
% [a_pattern, b_pattern, a, b] = complementaryGolaySequence(kgrid, ...
% sequence_duration, sequence_order)
% -------------------------------------------------------------------------
% EXAMPLE:
% golay_duration = 20e-6; % [s]
% n = 4; % sequence with 2^n elements
% 
% [a_pattern, b_pattern, a, b] = complementaryGolaySequence(kgrid, ...
% golay_duration, n)
% -------------------------------------------------------------------------
% INPUT:
% kgrid             - k-Wave grid structure
% chirp_duration    - pulse duration [s]
% sequence_order    - sequence order.
% -------------------------------------------------------------------------
% OUTPUT:
% a_pattern         - the code sequence with sequence_duration seconds
%                     sampled at 1/kgrid.dt
% b_pattern         - the base sequence with sequence_duration seconds
%                     sampled at 1/kgrid.dt
% a                 - code sequence with 2^n elements
% b                 - base sequence with 2^n elements
% -------------------------------------------------------------------------
% author: Ramon Cravo Fernandes (eng.ramon.cravo@gmail.com)
% date: 07rd August 2015
% last update: 07rd August 2015
% -------------------------------------------------------------------------

    [a, b] = complementaryGolayCode(sequence_order);
    L = length(a);

    pattern_length = sequence_duration/samplingTime;
    
    if pattern_length < L
        error('Inconsistent duration');
    end
    
    code_length = round(pattern_length/L);

    for ii = 1:L
        a_pattern(((ii - 1)*code_length + 1):(ii*code_length)) = a(ii)*ones(1, code_length);
        b_pattern(((ii - 1)*code_length + 1):(ii*code_length)) = b(ii)*ones(1, code_length);
    end

end


function [a_n, b_n] = complementaryGolayCode(n)
% Golay sequence
% -------------------------------------------------------------------------
% Based on Marc van Wanrooij Golay.M code (marcvanwanrooij@neural-code.com)
% -------------------------------------------------------------------------
% a_0(ii) = delta(ii)
% b_0(ii) = delta(ii)
% 
% ii    =  -m -(m+1) ... -1 0 1 ... (m+1) m
% delta =   0    0        0 1 0       0   0
% 
% a_n(ii) = a_n-1(ii) + b_n-1(ii - 2^(n-1))
% b_n(ii) = a_n-1(ii) - b_n-1(ii - 2^(n-1))
% -------------------------------------------------------------------------

    a_n = 1; % a_0(0)
    b_n = 1; % b_0(0)

    for loop = 1:n          % vectorial recursive code generation
        dum = a_n;          % a_n-1 = a_n;
        a_n = [dum b_n];    % a_n = [a_n-1(:), b_n-1(:)]
        b_n = [dum -b_n];   % b_n = [b_n-1(:), -b_n-1(:)]
    end

end
