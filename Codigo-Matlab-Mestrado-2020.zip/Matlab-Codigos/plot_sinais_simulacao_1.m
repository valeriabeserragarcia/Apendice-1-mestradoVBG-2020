%***************************************************************************************************
% Universidade Estadual de Campinas [University of Campinas] - UNICAMP
% Fac. de Eng. El�trica e de Computa��o [School of Electrical and Computing Engineering] - FEEC
% Departamento de Engenharia Biom�dica [Department of Biomedical Engineering] - DEB (1)
% Centro de Engenharia Biom�dica [Center for Biomedical Engineering] - CEB (2)
%
% Autor [Author]: Tiago de Moraes Machado {machado.tiago@gmail.com} (1)
% Orientador [Advisor]: Prof. Dr. Eduardo Tavares Costa (1),(2)
%
%***************************************************************************************************
% Revisao 1
% Autor: Amauri Amorin Assef
% Descri��o: Script de simula��o desenvolvido a partir da vers�o do arquivo
% Codigo_Final_4.
%
% O arquivo pode ser exetutado com uma das duas frequ�ncias: 2,25 e 5 MHz.
% Verificar e selecionar a op��o na se��o:
% "TRANSDUCER MODELLING: CIRCULAR MONO-ELEMENT"
%
% Conforme a frequ�ncia do transdutor (2,25 ou 5 MHz) os seguintes
% arquivos podem ser usados na simula��o:
%         filename = 'chirp-2.25MHz-5us.csv';
%         filename = 'chirp-2.25MHz-10us.csv';
%         filename = 'chirp-2.25MHz-20us.csv';
%         filename = 'chirp-5MHz-5us.csv';
%         filename = 'chirp-5MHz-10us.csv';
%         filename = 'chirp-5MHz-20us.csv';
%
% 1 - Selecionar o tipo do transdutor atrav�s da string "transdType":
%     '2.25 MHz' ou '5 MHz';
%
% 2 - Selecionar a dura��o do pulso de excita��o atrav�s da string
%    "pulse_duration": '5us', '10us' ou '20us';
%***************************************************************************************************

close all;
clear all;

clc;
disp(' ');
disp('1D manual simulation -> A-lines');
disp(' ');

%% Central pulse frequency (Hz)

%--------------------------------------------------------
% Selecionar a frequencia central do transdutor
%--------------------------------------------------------

transdType = '2.25 MHz';
%transdType = '5.0 MHz';


%% Dura��o do pulso de excita��o

%--------------------------------------------------------
% Selecionar a dura��o do pulso de excita��o
%--------------------------------------------------------

pulse_duration = '5us';
%pulse_duration = '10us';
%pulse_duration = '20us';

%% Settings to plot figures
FontName = 'Helvetia';
FontWeight = 'Bold';
FontSizeTitle = 15;
FontSizeXlabel = 12;
FontSizeYlabel = 12;
FontSizeAxes = 12;
esp = 0.8;

%% LOAD GLOBAL PARAMETERS

% Sound speed (m/s)
soundSpeed = 1540;
% Sampling frequency (Hz)
samplingFreq = 160 * 10^6;
% Sampling time (s)
samplingTime = 1/samplingFreq;
% Window size used to plot the data
winFreq = 10000000;

samplingFreq2=  40 * 10^6;        % *************frequencia de amostragem da recep��o de 40MHz

%% TRANSDUCER MODELLING: CIRCULAR MONO-ELEMENT

% Central pulse frequency (Hz)

tf = strcmp(transdType,'2.25 MHz');

if tf == 1
    transdCenterFreq = 2.25 * 10^6;
    disp('Freq. Transdutor = 2.25 MHz');
else
    transdCenterFreq = 5 * 10^6;
    disp('Freq. Transdutor = 5 MHz');
end;

% Setting the transducer as having one dimension (1D). Do not change it.
diamTransd1D = 0;
% Fractional bandwidth (if ratio is 1 --> 100%)
% fractionalBW = 0.4; %largura de banda/frequ�ncia central (normalizado)para 2.25MHz
fractionalBW = 0.4; %largura de banda/frequ�ncia central (normalizado)para 5MHz
% fractionalBW = 0.6344; %largura de banda/frequ�ncia central (normalizado)para 10MHz
% Effective transducer bandwidth is computed as largBanda * freqCentral
transdBW = fractionalBW * transdCenterFreq;
% Wavelength
lambda = soundSpeed/transdCenterFreq;

%% Teste pulso ultrass�nico
fs = 40e6;
f0 = transdCenterFreq;

escala_t = 0:1/fs:3/f0;

% Set the impulse response
impulse_response=cos(2*pi*f0*(escala_t));
impulse_response=impulse_response.*hanning(max(size(impulse_response)))';
impulse_response_norm = impulse_response/max(abs(impulse_response));

plot(escala_t*10^6,impulse_response_norm,'b-','LineWidth',1.5);
title('Pulso ultrass�nico','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
grid off;
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

%-----------------------------------
% FFT do pulso ultrass�nico
%-----------------------------------
[N,M]=size(impulse_response_norm');
impulse_response_norm_fft = zeros(1024,1);
impulse_response_norm_fft(1:N,1) = impulse_response_norm;

% N�mero de amostras para a FFT
NFFT = length(impulse_response_norm_fft);
N = NFFT;

Y1 = fft(impulse_response_norm_fft);

f=(fs*(0:(N-2)/2)/N)';
f=f*1e-6;

sinal_fft = abs(Y1(1:(N/4))/N);
sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));

figure;
%plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1.5);
title('Espectro do pulso ultrass�nico','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Eco');
grid on;
xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;


%% Phantom 1D
N = 500;
phantom = zeros(N,1);

phantom(N/10,1) = 0.5;
phantom(N*3/10,1) = 1;
phantom(N*6/10,1) = 0.75;
phantom(N*7/10,1) = 0.25;
phantom(N*9/10,1) = 1;

figure;
plot(phantom,'b-','LineWidth',1.5);
title('Phantom Unidimensional 1D','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Espalhadores ac�sticos');
xlabel('Profundidade [mm]','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

%-----------------------------------
% FFT do phantom
%-----------------------------------
[N,M]=size(phantom);

phantom_fft = zeros(512,1);
phantom_fft(1:N,1) = phantom;

% N�mero de amostras para a FFT
NFFT = length(phantom_fft);
N = NFFT;

Y1 = fft(phantom_fft);

f=(fs*(0:(N-2)/2)/N)';
f=f*1e-6;

sinal_fft = abs(Y1(1:(N/4))/N);
sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));

figure;
%plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
title('Espectro do phantom 1D','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Eco');
grid on;
xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;


%% Convolu��o dos sinais retroespalhados

a= conv(impulse_response_norm,phantom);
[N,M]=size(a);

escala_n = 0:1:N-1;
escala_t = escala_n/fs;
escala_t = escala_t';

b=abs(hilbert(a))';
figure;
plot(escala_t*10^6,a,'b-','LineWidth',1);
hold on;
plot(escala_t*10^6,b,'r--','LineWidth',1.5);
title('Sinal retroespalhado (linha A)','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Sinal de RF','Envelope');
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;


figure;
imagesc(b);
colormap(gray);
colorbar;
%plot(escala_t*10^6,b,'r--','LineWidth',1.5);
title('Envelope em escala de cinza','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
%      'FontSize',FontSizeYlabel);
axis tight;

% Retirar os valores dos eixos
%set(gca,'visible','off')



%% Phantom 1D - conjunto de espalhadores

espacamento = 3*lambda;

tamanho = 2048;
phantom1 = zeros(tamanho,1);
% snr = 7.5;               %db
% out = awgn(in,snr);

n = 100;
r = rand(n,1);

passo = round(tamanho/n);

for i=1:1:n-1
    phantom1(passo*i,1)=r(i,1);
end;

[N,M]=size(phantom1);
escala_t = (0:1:N-1)/fs;
escala_x = escala_t * soundSpeed/2;

figure;
plot(escala_t*10^6,phantom1,'b-','LineWidth',1);
title('Espalhadores ac�sticos equivalentes','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Sinal de RF','Envelope');
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;


figure;
plot(escala_x*10^3,phantom1,'b-','LineWidth',1);
title('Espalhadores ac�sticos equivalentes','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Sinal de RF','Envelope');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

%% Convolu��o dos sinais retroespalhados

a = conv(impulse_response_norm,phantom1);
[N,M]=size(a);

escala_n = 0:1:N-1;
escala_t = escala_n/fs;
escala_t = escala_t';
escala_x = escala_t * soundSpeed/2;

b=abs(hilbert(a))';
figure;
plot(escala_t*10^6,a,'b-','LineWidth',1);
hold on;
plot(escala_t*10^6,b,'r--','LineWidth',1.5);
title('Sinal retroespalhado (linha A)','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Sinal de RF','Envelope');
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

b=abs(hilbert(a))';
figure;
plot(escala_x*10^3,a,'b-','LineWidth',1);
hold on;
plot(escala_x*10^3,b,'r--','LineWidth',1.5);
title('Sinal retroespalhado (linha A)','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Sinal de RF','Envelope');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;


% %-----------------------------------
% % FFT do Sinal retroespalhado (linha A)
% %-----------------------------------
% [N,M]=size(a);
% a_fft = zeros(512,1);
% a_fft(1:N,1) = a;
%
% % N�mero de amostras para a FFT
% NFFT = length(a_fft);
% N = NFFT;
%
% Y1 = fft(a_fft);
%
% f=(fs*(0:(N-2)/2)/N)';
% f=f*1e-6;
%
% sinal_fft = abs(Y1(1:(N/4))/N);
% sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
%
% figure;
% %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
% plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
% title('Espectro do Sinal retroespalhado (linha A)','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% %legend('Eco');
% grid on;
% xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
%      'FontSize',FontSizeYlabel);
% axis tight;
%
% [N,M]=size(impulse_response_norm);
%
% noiseSignal = rand(1, 32);
% figure;
% plot(noiseSignal);

%-----------------------------------
% FFT do phantom
%-----------------------------------
[N,M]=size(phantom1);

% phantom1_fft = zeros(2048,1);
% phantom1_fft(1:N,1) = phantom1;

phantom1_fft = phantom1;

% N�mero de amostras para a FFT
NFFT = length(phantom1_fft);
N = NFFT;

Y1 = fft(phantom1_fft);

f=(fs*(0:(N-2)/2)/N)';
f=f*1e-6;

sinal_fft = abs(Y1(1:(N/4))/N);
sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));

figure;
%plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
title('Espectro do phantom 1D','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Eco');
grid on;
xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

pause;
close all;


%% Nova analise


%% Phantom 1D - conjunto de espalhadores

espacamento = 3*lambda;

tamanho = 2048;
phantom2 = zeros(tamanho,1);
% snr = 7.5;               %db
% out = awgn(in,snr);

n = 8;
passo = round(tamanho/n);

for i=1:1:n-1
    phantom2(passo*i,1)=1;
end;

[N,M]=size(phantom2);
escala_t = (0:1:N-1)/fs;
escala_x = escala_t * soundSpeed/2;

figure;
plot(escala_t*10^6,phantom2,'b-','LineWidth',1);
title('Espalhadores ac�sticos equivalentes','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Espalhadores (interfaces ac�sticas)');
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;


figure;
plot(escala_x*10^3,phantom2,'b-','LineWidth',1);
title('Espalhadores ac�sticos equivalentes','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Espalhadores (interfaces ac�sticas)');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

%% Convolu��o dos sinais retroespalhados

a = conv(impulse_response_norm,phantom2);
[N,M]=size(a);

escala_n = 0:1:N-1;
escala_t = escala_n/fs;
escala_t = escala_t';
escala_x = escala_t * soundSpeed/2;

b=abs(hilbert(a))';
figure;
plot(escala_t*10^6,a,'b-','LineWidth',1);
hold on;
plot(escala_t*10^6,b,'r--','LineWidth',1.5);
title('Sinal retroespalhado (linha A)','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Sinal de RF','Envelope');
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

b=abs(hilbert(a))';
figure;
plot(escala_x*10^3,a,'b-','LineWidth',1);
hold on;
plot(escala_x*10^3,b,'r--','LineWidth',1.5);
title('Sinal retroespalhado (linha A)','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Sinal de RF','Envelope');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

pause;
close all;


%% CHIRP (OR LINEAR FREQUENCY MODULATION) CONSTRUCTION

% Coded excitation parameters
A = 1.0; % Amplitude
T = 5*10^-6; % Time duration of the excitation 5us
% T = 10*10^-6; % Time duration of the excitation 10us
% T = 20*10^-6; % Time duration of the excitation 20us
sampFreqChirp = samplingFreq; % Chirp sampling frequency

% Optimum factor to chirp/transducer ratio
optimumFactorBW = 2.0; % ******

% Window function to apply amplitude tapering such as Tukey, Gaussian,
% Hanning, and son on
winTap = 'lanczos';
tapFactor = 25; % Tapering factor (%)
tapCheby = 60; % Sidelobe leve cutoff for mismatch filtering

% Firstly, we must create a linear modulation frequency (LFM) signal
[LFMchirp,tapLFMchirp,tChirp,startFreqSweep,finalFreqSweep,B,optimalBW,...
    TBP] = usGenChirpExcitation_TiagoMMachado(A,T,sampFreqChirp,...
    transdCenterFreq,transdBW,optimumFactorBW,tapFactor,winTap);

figure, % if you want to plot just the points, remove the tChirp variable
%plot(tChirp*10^6,real(LFMchirp),'k-','LineWidth',1.5);
plot(tChirp*10^6,real(LFMchirp),'b-','LineWidth',1.5);
title('Sinal de excita��o chirp (LFM)','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
grid on;
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
%set(0,'DefaultLineLineSmoothing','off');
%set(gca,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeAxes);
%set(gca,'LooseInset',get(gca,'TightInset'));
axis([0 tChirp(end)*10^6 min(real(LFMchirp))-0.25 max(real(LFMchirp))+0.25]);

sinal_chirp_trad = real(LFMchirp);

[M,N]=size(sinal_chirp_trad);
sinal_chirp_trad_fft = zeros(2048,1);
sinal_chirp_trad_fft(1:N,1) = sinal_chirp_trad;

% N�mero de amostras para a FFT
NFFT = length(sinal_chirp_trad_fft);
N = NFFT;

Y1 = fft(sinal_chirp_trad_fft);

f=(samplingFreq*(0:(N-2)/2)/N)';
f=f*1e-6;

sinal_fft = abs(Y1(1:(N/4))/N);
sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));

figure;
%plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
title('FFT do sinal chirp (LFM) tradicional','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Eco');
grid on;
xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;


sinal_tapLFMchirp = real(tapLFMchirp);

figure, % if you want to plot just the points, remove the tChirp variable
%plot(tChirp*10^6,real(tapLFMchirp),'k-','LineWidth',1.5);
plot(tChirp*10^6,real(tapLFMchirp),'b-','LineWidth',1.5);
title('Sinal de excita��o chirp (LFM) com tapering de amplitude','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
grid on;
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
% set(0,'DefaultLineLineSmoothing','off');
% set(gca,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeAxes);
% set(gca,'LooseInset',get(gca,'TightInset'));
axis([0 tChirp(end)*10^6 min(real(tapLFMchirp))-0.25 max(real(tapLFMchirp))+0.25]);


[M,N]=size(sinal_tapLFMchirp);
sinal_tapLFMchirp_fft = zeros(2048,1);
sinal_tapLFMchirp_fft(1:N,1) = sinal_tapLFMchirp;

% N�mero de amostras para a FFT
NFFT = length(sinal_tapLFMchirp_fft);
N = NFFT;

Y1 = fft(sinal_tapLFMchirp_fft);

f=(samplingFreq*(0:(N-2)/2)/N)';
f=f*1e-6;

sinal_fft = abs(Y1(1:(N/4))/N);
sinal_fft_1 = 20*log10(sinal_fft/max(sinal_fft));

figure;
%plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
plot(f(1:NFFT/4),sinal_fft_1,'b-','LineWidth',1);
title('FFT do sinal chirp (LFM) com tapering de amplitude','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Eco');
grid on;
xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

figure;
%plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
hold on;
plot(f(1:NFFT/4),sinal_fft_1,'r-','LineWidth',1);
title('Expectro em frequ�ncia','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Eco');
grid on;
legend('Chirp tradicional','Chirp com tapering')
xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

pause;
close all;
%break;

%
% %------------------------------------------------
% % Gera��o dos sinais M3 a M0
% %------------------------------------------------
% N_degraus = 7;
% sinal_norm = round(real(tapLFMchirp) * N_degraus);
% % sinal_norm = real(tapLFMchirp);
% t = tChirp;
% L = max(size(sinal_norm));
% M0=zeros(L,1);
% M1=zeros(L,1);
% M2=zeros(L,1);
% M3=zeros(L,1);
%
%
% %Sinais M3:M0 para grava��o na FPGA
%
% for i=1:L
%     if (sinal_norm(1,i) >= 0)
%         M0(i,1) = rem(sinal_norm(1,i),2);
%         M1(i,1) = rem(floor(sinal_norm(1,i)/2),2);
%         M2(i,1) = floor(floor(sinal_norm(1,i)/2)/2);
%         M3(i,1) = 0;
%     else
%         M0(i,1) = abs(rem(sinal_norm(1,i),2));
%         M1(i,1) = abs(rem(ceil(sinal_norm(1,i)/2),2));
%         M2(i,1) = abs(ceil(ceil(sinal_norm(1,i)/2)/2));
%         M3(i,1) = 1;
%     end
% end
%
% %Sinais M3:M0 para grava��o na FPGA
%
% sinais_M=zeros(L,4);
% sinais_M(:,1) = M3; % Sinais M3:M0
% sinais_M(:,2) = M2;
% sinais_M(:,3) = M1;
% sinais_M(:,4) = M0;
%
% M0A=M0';
% M1A=M1';
% M2A=M2';
% M3A=M3';
%
% %----------------------------------------------------
% % Prova dos sinais M
% %----------------------------------------------------
% for (i=1:L)
%     prova_M(i,1) = (-1)^M3(i,1)*(M2(i,1)*2^2 + M1(i,1)*2 + M0(i,1));
% end
% figure;
% %stairs(t' * 1e6,prova_M,'k-','LineWidth',1.5);
% stairs(t' * 1e6,prova_M,'b-','LineWidth',1.5);
% title('Prova do sinais M3:M0','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% grid on;
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%      'FontSize',FontSizeXlabel);
% ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
%      'FontSize',FontSizeYlabel);
% % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
% %     'FontSize',FontSizeYlabel);
% %axis tight;
%
% figure
% set(gcf,'Position',[200 50 600 600])
% subplot(5,1,1);
% %stairs(t' * 1e6,prova_M,'k-','LineWidth',esp);
% stairs(t' * 1e6,prova_M,'b-','LineWidth',esp);
% title('Prova do sinais M3:M0','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% %axis tight;
%
% subplot(5,1,2);
% stairs(t' * 1e6, M0,'b-','LineWidth',esp);
% title('Sinal M0','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% axis ([0 max(t)*1e6 0 1.2]);
%
% subplot(5,1,3);
% stairs(t' * 1e6, M1,'b-','LineWidth',esp);
% title('Sinal M1','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% axis ([0 max(t)*1e6 0 1.2]);
%
% subplot(5,1,4);
% stairs(t' * 1e6, M2,'b-','LineWidth',esp);
% title('Sinal M2','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% axis ([0 max(t)*1e6 0 1.2]);
%
% subplot(5,1,5);
% stairs(t' * 1e6, M3,'b-','LineWidth',esp);
% title('Sinal M3','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%      'FontSize',FontSizeXlabel);
%
% %axis tight;
% axis ([0 max(t)*1e6 0 1.2]);
%
% %----------------------------------------------------
% % Exemplo de peso dos registros LV para 7 n�veil + e 7 n�veis -
% %----------------------------------------------------
% N_bits = 7;
% Valor_maximo_LV = 2^7-1;
% Norm = floor (Valor_maximo_LV/N_bits);
%
% % **** Testar com outras normaliza��es para verificar a linearidade
%
% for i=1:16
%     LV(i,1)=i-1;                                        %LV0 a LV15
%     if (i<=8)
%         LV(i,2) = i-1;                                  % Peso de LV = 0 a 7
%         LV(i,4) = 0;                                    % M3 = 0
%         LV(i,5) = floor(floor((i-1)/2)/2);              % M2
%         LV(i,6) = rem(floor((i-1)/2),2);                % M1
%         LV(i,7) = rem((i-1),2);                         % M0
%     elseif i==9
%         LV(i,2) = 0;                                    % Peso de LV 8
%         LV(i,4) = 1;                                    % M3 = 1
%         LV(i,5) = 0;                                    % M2
%         LV(i,6) = 0;                                    % M1
%         LV(i,7) = 0;                                    % M0
%     else
%         LV(i,2) = i-9;                                  % Peso de LV de 9 a 16
%         LV(i,4) = 1;                                    % M3 = 1
%         LV(i,5) = abs(floor(floor((i-9)/2)/2));         % M2
%         LV(i,6) = abs(rem(floor((i-9)/2),2));           % M1
%         LV(i,7) = abs(rem((i-9),2));                    % M0
%     end;
%     LV(i,3) = LV(i,2)*Norm;
%
%     % Incluido o valor do M3:M0 entre as colunas 4 e 7
%     % Incluido o valor de LV na coluna 3 para grava��o no MD2134
%
% end;
%
% % ou
%
% % Positivo
% LV0=0;
% LV1=1 * Norm;
% LV2=2 * Norm;
% LV3=3 * Norm;
% LV4=4 * Norm;
% LV5=5 * Norm;
% LV6=6 * Norm;
% LV7=7 * Norm;
%
% % Negativo
% LV8=0;
% LV9=1 * Norm;
% LV10=2 * Norm;
% LV11=3 * Norm;
% LV12=4 * Norm;
% LV13=5 * Norm;
% LV14=6 * Norm;
% LV15=7 * Norm;
%
% %------------------------------------------------
% % Sinal de sa�da esperado com amplitude dos registros LV
% %------------------------------------------------
% sinal_norm_LV = prova_M * Norm';
% figure;
% stairs(t * 1e6,sinal_norm_LV,'b-','LineWidth',1.5);
% grid on;
% title('Prova do sinais M3:M0 com pesos do LV','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Valores de LV','FontName',FontName,'FontWeight',FontWeight,...
%      'FontSize',FontSizeYlabel);
%
% %axis tight;


%------------------------------------------------
% Tabela completa
%------------------------------------------------

% for i=1:16
%     LV_tabela(i,1) = (i-1);
%     if
%         LV_tabela(i,2) = (i-1);
%     end;
% end;



%% Leitura dos dados de arquivo do tipo csv

addpath('TESTES-62V')

numero_pulsos = 3;
tabela_pulso = zeros(65535,numero_pulsos);

for i=1:1:3

    
    tf = strcmp(transdType,'2.25 MHz');
    
    if tf == 1
        if i==1
            filename = 'chirp-2.25MHz-5us.csv';
            
            T1 = readtable(filename);
            
            % Convers�o de Tabela para vetor 2D
            A = table2array(T1);
            
            % Pega informa��es somente do canal 4 (total de 8 canais)
            pulso = A(:,4);
            
            tabela_pulso(:,i) = pulso;

            %intervalo do primeiro pulso ap�s a excita��o
            dado1 = pulso(8075:8350);
        elseif i==2
            filename = 'chirp-2.25MHz-10us.csv';
            
            T1 = readtable(filename);
            
            % Convers�o de Tabela para vetor 2D
            A = table2array(T1);
            
            % Pega informa��es somente do canal 4 (total de 8 canais)
            pulso = A(:,4);
            
            tabela_pulso(:,i) = pulso;
            
            %intervalo do primeiro pulso ap�s a excita��o
            dado2 = pulso(18050:18500);
        else
            filename = 'chirp-2.25MHz-20us.csv';
            
            T1 = readtable(filename);
            
            % Convers�o de Tabela para vetor 2D
            A = table2array(T1);
            
            % Pega informa��es somente do canal 4 (total de 8 canais)
            pulso = A(:,4);
            
            tabela_pulso(:,i) = pulso;
            %intervalo do primeiro pulso ap�s a excita��o
            dado3 = pulso(22000:22900);
        end;
    else
        % Leitura da Tabela de dados
        if i==1
            filename = 'chirp-5MHz-5us.csv';
            
            T1 = readtable(filename);
            
            % Convers�o de Tabela para vetor 2D
            A = table2array(T1);
            
            % Pega informa��es somente do canal 4 (total de 8 canais)
            pulso = A(:,4);
            
            tabela_pulso(:,i) = pulso;
            
            %intervalo do primeiro pulso ap�s a excita��o
            dado1 = pulso(24475:24725);
        elseif i==2
            filename = 'chirp-5MHz-10us.csv';
            
            T1 = readtable(filename);
            
            % Convers�o de Tabela para vetor 2D
            A = table2array(T1);
            
            % Pega informa��es somente do canal 4 (total de 8 canais)
            pulso = A(:,4);
            
            tabela_pulso(:,i) = pulso;
            
            %intervalo do primeiro pulso ap�s a excita��o
            dado2 = pulso(17025:17450);
        else
            filename = 'chirp-5MHz-20us.csv';
            
            T1 = readtable(filename);
            
            % Convers�o de Tabela para vetor 2D
            A = table2array(T1);
            
            % Pega informa��es somente do canal 4 (total de 8 canais)
            pulso = A(:,4);
            
            tabela_pulso(:,i) = pulso;

            % intervalo do primeiro pulso ap�s a excita��o
            dado3 = pulso(11500:12300);
        end;
    end;
  
    [N,M] = size(pulso);
    escala = (0:1:N-1);
    
    figure;
    plot(escala,pulso,'LineWidth',1);
    title(filename,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    % title('Prova do sinais M3:M0 com pesos do LV','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    axis tight;
    
    if i==1
        % intervalo do primeiro pulso ap�s a excita��o
        %dado1 = pulso(24475:24725);
        figure;
        plot(dado1,'LineWidth',1);
        title(filename,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
        xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeXlabel);
        ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeYlabel);
        % title('Prova do sinais M3:M0 com pesos do LV','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
        xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeXlabel);
        axis tight;
        
        %---------------------------------------------------
        % C�lculo das FFTs dos sinais para compara��o
        %---------------------------------------------------
        informacao = zeros(2048,1);
        [N,M] = size(dado1);
        informacao(1:N,1) = dado1;
        
        [N,M]=size(informacao);
        
        % N�mero de amostras para a FFT
        NFFT = length(informacao);
        
        Y1 = fft(informacao);
        
        fs = 40e6;
        
        f=(fs*(0:(N-2)/2)/N)';
        f=f*1e-6;
        
        sinal_fft = abs(Y1(1:(N/4))/N);
        sinal_fft_1 = 20*log10(sinal_fft/max(sinal_fft));
        
        figure;
        %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
        plot(f(1:NFFT/4),sinal_fft_1,'b-','LineWidth',1);
        title(filename,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
        %legend('Eco');
        grid on;
        xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeXlabel);
        ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeYlabel);
        axis tight;
        
        
    elseif i==2
        % intervalo do primeiro pulso ap�s a excita��o
        %dado2 = pulso(17025:17450);
        figure;
        plot(dado2,'LineWidth',1);
        title(filename,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
        xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeXlabel);
        ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeYlabel);
        % title('Prova do sinais M3:M0 com pesos do LV','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
        xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeXlabel);
        axis tight;
        
        
        [N,M] = size(dado2);
        informacao(1:N,1) = dado2;
        
        [N,M]=size(informacao);
        
        % N�mero de amostras para a FFT
        NFFT = length(informacao);
        
        Y1 = fft(informacao);
        
        fs = 40e6;
        
        f=(fs*(0:(N-2)/2)/N)';
        f=f*1e-6;
        
        sinal_fft = abs(Y1(1:(N/4))/N);
        sinal_fft_1 = 20*log10(sinal_fft/max(sinal_fft));
        
        figure;
        %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
        plot(f(1:NFFT/4),sinal_fft_1,'b-','LineWidth',1);
        title(filename,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
        %legend('Eco');
        grid on;
        xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeXlabel);
        ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeYlabel);
        axis tight;
        
        
    else
        % intervalo do primeiro pulso ap�s a excita��o
        %dado3 = pulso(11500:12300);
        figure;
        plot(dado3,'LineWidth',1);
        title(filename,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
        xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeXlabel);
        ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeYlabel);
        % title('Prova do sinais M3:M0 com pesos do LV','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
        xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeXlabel);
        axis tight;
        
        
        [N,M] = size(dado3);
        informacao(1:N,1) = dado3;
        
        [N,M]=size(informacao);
        
        % N�mero de amostras para a FFT
        NFFT = length(informacao);
        
        Y1 = fft(informacao);
        
        fs = 40e6;
        
        f=(fs*(0:(N-2)/2)/N)';
        f=f*1e-6;
        
        sinal_fft = abs(Y1(1:(N/4))/N);
        sinal_fft_1 = 20*log10(sinal_fft/max(sinal_fft));
        
        figure;
        %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
        plot(f(1:NFFT/4),sinal_fft_1,'b-','LineWidth',1);
        title(filename,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
        %legend('Eco');
        grid on;
        xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeXlabel);
        ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
            'FontSize',FontSizeYlabel);
        axis tight;
        
        
    end;
    
    
end;


pause;
close all;


%% Phantom 1D - conjunto de espalhadores para a analise com o chirp

espacamento = 3*lambda;

tamanho = 2048;
phantom3 = zeros(tamanho,1);
% snr = 7.5;               %db
% out = awgn(in,snr);

%n = 100;
n = 10;
r = rand(n,1);

passo = round(tamanho/n);

for i=1:1:n-1
    phantom3(passo*i,1)=r(i,1);
end;

[N,M]=size(phantom3)
escala_t = (0:1:N-1)/fs;
escala_x = escala_t * soundSpeed/2;

figure;
plot(escala_t*10^6,phantom3,'b-','LineWidth',1);
title('Espalhadores ac�sticos equivalentes - Phantom 3','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Sinal de RF','Envelope');
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;


figure;
plot(escala_x*10^3,phantom3,'b-','LineWidth',1);
title('Espalhadores ac�sticos equivalentes','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Sinal de RF','Envelope');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;



%% SELE�AO DO SINAL DE ECO CHIRP20

%%Convolu��o dos sinais retroespalhados

%--------------------------------------------------------
% A sele��o do sinal de eco � realizada no inicio do c�digo
%--------------------------------------------------------

pd = strcmp(pulse_duration,'5us');
if pd == 1
    chirp20 = dado1;                % sinal de eco com excita��o chirp de 5 us
    disp('Eco com excita��o chirp de 5 us ');
else
    pd = strcmp(pulse_duration,'10us');
    if pd == 1
        chirp20 = dado2;            % sinal de eco com excita��o chirp de 10 us
        disp('Eco com excita��o chirp de 10 us ');
    else
        chirp20 = dado3;            % sinal de eco com excita��o chirp de 20 us
        disp('Eco com excita��o chirp de 20 us ');
    end;
end;


ecoChirp20 = conv(chirp20,phantom3);
[N,M]=size(ecoChirp20);

escala_n = 0:1:N-1;
escala_t = escala_n/fs;
escala_t = escala_t';
escala_x = escala_t * soundSpeed/2;

b=abs(hilbert(ecoChirp20))';
figure;
plot(escala_t*10^6,ecoChirp20,'b-','LineWidth',1);
hold on;
plot(escala_t*10^6,b,'r--','LineWidth',1.5);
title('Sinal retroespalhado (linha A)','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Sinal de RF','Envelope');
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

figure;
plot(escala_x*10^3,ecoChirp20,'b-','LineWidth',1);
hold on;
plot(escala_x*10^3,b,'r--','LineWidth',1.5);
title('Sinal retroespalhado (linha A)','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Sinal de RF','Envelope');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

%--------------------------------------
% Inverte (flip) do vetor do sinal
%--------------------------------------
%tapChirpREAL = fliplr(chirp20(16090:16890)')'; % MUDAR INTERVALO... chirp enviado para o transdutor capturado pelo sistema de aquisi��o
tapChirpREAL = fliplr(chirp20')'; % MUDAR INTERVALO... chirp enviado para o transdutor capturado pelo sistema de aquisi��o
[N,M]=size(tapChirpREAL);
% escala = (1:1:N)/samplingFreq;
escala = (0:1:N-1)/samplingFreq2;

figure;
plot(escala*1e6,tapChirpREAL,'b-','LineWidth',0.8);
title('Sinal chirp com tap real fliplr - tapChirpREAL','FontName',FontName,...
    'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

figure;
subplot(2,1,1);
plot(escala*1e6,chirp20,'b-','LineWidth',0.8);
title('Pulso - chirp20','FontName',FontName,...
    'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

subplot(2,1,2);
plot(escala*1e6,tapChirpREAL,'b-','LineWidth',0.8);
title('Sinal chirp com tap real fliplr - tapChirpREAL','FontName',FontName,...
    'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;


%------------------------------------
% Filtro com o mesmo tamanho do vetor com perfil Gaussuiano
%------------------------------------
wn = usGenWindowFilter_TiagoMMachado(tapChirpREAL, 60,'chebyshev');

wn = wn';
[N,M]=size(wn);
% escala = (1:1:N)/samplingFreq;
escala = (0:1:N-1)/samplingFreq2; %frequencia de amostragem de 40MHz na recep��o
figure;
plot(escala*1e6, wn,'b-','LineWidth',0.8);
title('Sinal chirp com tap','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

%----------------------------------------------------------
%Sinal flip com aplica��o do filtro com perfil Gaussiano
%Filtro mismatchFilt (descasado)
%----------------------------------------------------------
%wn = wn';
mismatchFilt = wn.*tapChirpREAL;
[N,M]=size(mismatchFilt);
% escala = (1:1:N)/samplingFreq;
escala = (1:1:N)/samplingFreq2;
figure;
plot(escala*1e6,mismatchFilt,'b-','LineWidth',0.8);
title('mismatchFilt','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

%----------------------------------------------------------
%Sinal flip sem aplica��o do filtro com perfil Gaussiano
%Filtro matchFilt (casado)
%Convolu��o do sinal de eco com o filtro matchFilt (casado)
%----------------------------------------------------------

matchFilt = tapChirpREAL;
mismatchFilt_RF = conv(ecoChirp20, mismatchFilt); % ecoChirp20 � o RAW data capturado
matchFilt_RF = conv(ecoChirp20, matchFilt);

[N,M]=size(tapChirpREAL);
% escala = (1:1:N)/samplingFreq;
escala = (0:1:N-1)/samplingFreq2;
figure;
plot(escala*1e6,tapChirpREAL,'b-','LineWidth',0.8);
title('tapChirpREAL','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;


[N,M]=size(mismatchFilt_RF);
% escala = (1:1:N)/samplingFreq;
escala = (0:1:N-1)/samplingFreq2; %amostragem de 40MHz na recep��o
figure;
plot(escala*1e3,mismatchFilt_RF,'b-','LineWidth',0.8);
hold on;
plot(escala*1e3,abs(hilbert(mismatchFilt_RF)),'r-','LineWidth',0.8);
legend('Sinal Mismatch','Envelope');
title('mismatchFilt RF','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

[N,M]=size(ecoChirp20);
escala = (0:1:N-1)/samplingFreq2;

a = ecoChirp20./max(abs(ecoChirp20));
b = conv(ecoChirp20, matchFilt)./max(abs(conv(ecoChirp20, matchFilt)));
c = conv(ecoChirp20, mismatchFilt)./max(abs(conv(ecoChirp20, mismatchFilt)));

[X,Y]=size(b);
escala_conv = (0:1:X-1)/samplingFreq2;

figure;

%plot(ecoChirp20./max(abs(ecoChirp20))), hold on, plot(conv(ecoChirp20, matchFilt)./max(abs(conv(ecoChirp20, matchFilt)))), plot(conv(ecoChirp20, mismatchFilt)./max(abs(conv(ecoChirp20, mismatchFilt))))
plot(escala*1e3,a,'b-','LineWidth',0.8);
hold on;
plot(escala_conv*1e3,b,'k-','LineWidth',0.8);
hold on;
plot(escala_conv*1e3,c,'r-','LineWidth',0.8);
legend('ecoChirp20','ecoChirp20 matchFilt','ecoChirp20 mismatchFilt');
xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

figure;
subplot(3,1,1);
plot(escala*1e3,a,'b-','LineWidth',0.8);
legend('ecoChirp20');
axis tight;
subplot(3,1,2);
plot(escala_conv*1e3,b,'b-','LineWidth',0.8);
hold on;
plot(escala_conv*1e3,abs(hilbert(b)),'r-','LineWidth',0.8);
legend('ecoChirp20 matchFilt','Envelope');
axis tight;
subplot(3,1,3);
plot(escala_conv*1e3,c,'b-','LineWidth',0.8);
hold on;
plot(escala_conv*1e3,abs(hilbert(c)),'r-','LineWidth',0.8);
legend('ecoChirp20 mismatchFilt','Envelope');
xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
%ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
axis tight;

figure;
subplot(2,1,1);
plot(escala*1e3,a,'b-','LineWidth',0.8);
legend('ecoChirp20');
axis tight;
subplot(2,1,2);
plot(escala_conv*1e3,b,'b-','LineWidth',0.8);
hold on;
plot(escala_conv*1e3,abs(hilbert(b)),'r-','LineWidth',0.8);
legend('ecoChirp20 matchFilt','Envelope');
axis tight;
xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
%ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);


figure;
subplot(2,1,1);
plot(escala*1e3,a,'b-','LineWidth',0.8);
legend('ecoChirp20');
axis tight;
subplot(2,1,2);
plot(escala_conv*1e3,c,'b-','LineWidth',0.8);
hold on;
plot(escala_conv*1e3,abs(hilbert(c)),'r-','LineWidth',0.8);
legend('ecoChirp20 mismatchFilt','Envelope');
axis tight;
xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
%ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);

%-----------------------------------
% FFT do sinal com sinal de eco bruto
%-----------------------------------
[N,M]=size(a);

phantom_fft = zeros(2^12,1);
phantom_fft(1:N,1) = a;

% N�mero de amostras para a FFT
NFFT = length(phantom_fft);
N = NFFT;

Y1 = fft(phantom_fft);

f=(fs*(0:(N-2)/2)/N)';
f=f*1e-6;

sinal_fft = abs(Y1(1:(N/4))/N);
sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));

figure;
%plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
title('Espectro do sinal bruto de RF','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Eco');
grid on;
xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;


%-----------------------------------
% FFT do sinal com sinal de com filtro casado
%-----------------------------------
[N,M]=size(b);

phantom_fft = zeros(2^12,1);
phantom_fft(1:N,1) = b;

% N�mero de amostras para a FFT
NFFT = length(phantom_fft);
N = NFFT;

Y1 = fft(phantom_fft);

f=(fs*(0:(N-2)/2)/N)';
f=f*1e-6;

sinal_fft = abs(Y1(1:(N/4))/N);
sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));

figure;
%plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
title('Espectro do sinal bruto com aplica��o de filtro casado','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Eco');
grid on;
xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

%-----------------------------------
% FFT do sinal com sinal de com filtro descasado
%-----------------------------------
[N,M]=size(c);

phantom_fft = zeros(2^12,1);
phantom_fft(1:N,1) = c;

% N�mero de amostras para a FFT
NFFT = length(phantom_fft);
N = NFFT;

Y1 = fft(phantom_fft);

f=(fs*(0:(N-2)/2)/N)';
f=f*1e-6;

sinal_fft = abs(Y1(1:(N/4))/N);
sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));

figure;
%plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
title('Espectro do sinal bruto com aplica��o de filtro descasado','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Eco');
grid on;
xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;




break;






%% Leitura dos dados de arquivo do tipo csv


%----------------------------------------------------------
% Leitura do primeiro arquivo *.csv referente ao pulso (variavel chirp20)
%----------------------------------------------------------
[filename1,path] = uigetfile('*.csv','Selecione o arquivo referente ao PULSO (chirp*.cvs');
if isequal(filename1,0)
    disp('User selected Cancel');
    return;
else
    disp(['Arquivo 1 ', fullfile(path,filename1)]);
end

% Leitura da Tabela de dados
T1 = readtable(filename1);

% Convers�o de Tabela para vetor 2D
A = table2array(T1);
pulso = A(:,4);

% [N,M] = size(A);
% escala = (1:1:N);
% figure;
% plot(escala,A);
% title(filename1);
% % legend('1','2','3','4','5','6','7','8');
% xlabel('Indice'); ylabel('Amplitude');
% axis tight;

%----------------------------------------------------------
% Leitura do segundo arquivo *.csv referente ao pulso+eco
%----------------------------------------------------------
[filename2,path] = uigetfile('*.csv','Selecione o arquivo referente ao PULSO+ECO');
if isequal(filename1,0)
    disp('User selected Cancel');
    return;
else
    disp(['Arquivo 2 ', fullfile(path,filename2)]);
end

% Leitura da Tabela de dados
T2 = readtable(filename2);

% Convers�o de Tabela para vetor 2D
B = table2array(T2);
pulso_eco = B(:,4);

%----------------------------------------------------------
% Plot da primeira onda e selecao de intervalo para processamento
% Sinal pulso para sele��o de intervalo
%----------------------------------------------------------
fs = 40e6;

[N,M] = size(pulso);
%escala = (1:1:N)/samplingFreq*1e6;  % ajuste para escala em us
escala = (0:1:N-1);
escala_tempo = (0:1:N-1)/fs;

figure;
plot(escala,pulso,'b-','LineWidth',0.8);
title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Eco');
xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

figure;
plot(escala_tempo*1e3,pulso,'b-','LineWidth',0.8);
title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Eco');
xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

figure;
plot(escala_tempo*1e3,pulso,'b-','LineWidth',0.8);
hold on;
plot(escala_tempo*1e3,abs(hilbert(pulso)),'r-','LineWidth',0.8);
title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Eco','Envelope');
xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

pulso_norm = pulso/max(abs(pulso));

figure;
plot(escala_tempo*1e3,pulso_norm,'b-','LineWidth',0.8);
title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Eco');
xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;


%Cria��o dos vetores de intervalor de amostras
intervalo = zeros(2,1);

%-------------------------------------------------------------------------
% Teste para aplicar zoom na �rea selecionada
% O la�o � repetido caso a tecla pressionada ao final seja diferente de 1
%-------------------------------------------------------------------------
teste = 0;              % valor inicial para o la�o

while (teste ~= 1)
    %Leitura do intervalo entre as amostras
    intervalo(1) = input('Digite o intervalo inicial (�ndice) do sinal PULSO: ');
    intervalo(2) = input('Digite o intervalo final (�ndice) do sinal PULSO: ');
    
    figure;
    plot(escala,pulso,'b-','LineWidth',0.8);
    title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend('Pulso');
    xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    axis tight;
    
    figure;
    plot(escala,pulso,'b-','LineWidth',0.8);
    title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend('Pulso');
    xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    axis ([intervalo(1) intervalo(2) ...
        min(min(A(intervalo(1):intervalo(2),:))) max(max(A(intervalo(1):intervalo(2),:)))]);
    
    figure;
    plot(escala,pulso,'b-','LineWidth',0.8);
    hold on;
    plot(escala,abs(hilbert(pulso)),'r-','LineWidth',0.8);
    title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % grid on;);
    legend('Pulso','Envelope');
    xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    
    axis ([intervalo(1) intervalo(2) ...
        min(min(A(intervalo(1):intervalo(2),:))) max(max(A(intervalo(1):intervalo(2),:)))]);
    
    teste = input('Repetir ajuste? Digite 1 para nao repetir: ');
    
end;

disp('Selecao apresentada');

chirp20 = pulso(intervalo(1):intervalo(2),1);
ecoChirp20 = pulso_eco;

[N,M] = size(chirp20);

escala_amostra_pulso = 0:1:N-1;
escala_tempo_pulso = escala_amostra_pulso/fs;

[N,M] = size(ecoChirp20);

escala_amostra_pulso_eco = 0:1:N-1;
escala_tempo_pulso_eco = escala_amostra_pulso_eco/fs;

figure;
subplot(2,1,1);
plot(chirp20,'b-','LineWidth',0.8);
title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Pulso - chirp20');
xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

subplot(2,1,2);
plot(ecoChirp20);
title(filename2);
legend('Pulso + Eco - ecoChirp20');
xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

figure;
subplot(2,1,1);
plot(escala_tempo_pulso,chirp20,'b-','LineWidth',0.8);
title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Pulso - chirp20');
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

subplot(2,1,2);
plot(escala_tempo_pulso_eco, ecoChirp20);
title(filename2);
legend('Pulso + Eco - ecoChirp20');
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

% [N,M] = size(pulso_eco);
% %escala = (1:1:N)/samplingFreq*1e6;  % ajuste para escala em us
% escala = (1:1:N);
%
% figure;
% plot(escala,pulso_eco);
% %title('Sinal 2')
% title(filename2);
% legend('Pulso Eco');
% %xlabel('Tempo (us)');ylabel('Amplitude');
% xlabel('Indice');ylabel('Amplitude');
% axis tight;

%return;


%% CHIRP (OR LINEAR FREQUENCY MODULATION) CONSTRUCTION

%chirp20 = zeros(20000,1);
%chirp20(16090:16890)=sinal_tapLFMchirp;
%ecoChirp20 = zeros(20000,1);
%posicao1 = 1000;
%posicao2 = 5000;
%posicao3 = 10000;
%posicao4 = 15000;
%ecoChirp20(posicao1:posicao1+800)=sinal_tapLFMchirp;
%ecoChirp20(posicao2:posicao2+800)=sinal_tapLFMchirp;
%ecoChirp20(posicao3:posicao3+800)=sinal_tapLFMchirp;
%ecoChirp20(posicao4:posicao4+800)=sinal_tapLFMchirp;

samplingFreq2=  40 * 10^6;        % *************frequencia de amostragem da recep��o de 40MHz

%--------------------------------------
% Inverte (flip) do vetor do sinal
%--------------------------------------

%tapChirpREAL = fliplr(chirp20(16090:16890)')'; % MUDAR INTERVALO... chirp enviado para o transdutor capturado pelo sistema de aquisi��o
tapChirpREAL = fliplr(chirp20')'; % MUDAR INTERVALO... chirp enviado para o transdutor capturado pelo sistema de aquisi��o
[N,M]=size(tapChirpREAL);
% escala = (1:1:N)/samplingFreq;
escala = (0:1:N-1)/samplingFreq2;

figure;
plot(escala*1e6,tapChirpREAL,'b-','LineWidth',0.8);
title('Sinal chirp com tap real fliplr - tapChirpREAL','FontName',FontName,...
    'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

figure;
subplot(2,1,1);
plot(escala*1e6,chirp20,'b-','LineWidth',0.8);
title('Pulso - chirp20','FontName',FontName,...
    'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

subplot(2,1,2);
plot(escala*1e6,tapChirpREAL,'b-','LineWidth',0.8);
title('Sinal chirp com tap real fliplr - tapChirpREAL','FontName',FontName,...
    'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;


%------------------------------------
% Filtro com o mesmo tamanho do vetor com perfil Gaussuiano
%------------------------------------
wn = usGenWindowFilter_TiagoMMachado(tapChirpREAL, 60,'chebyshev');

wn = wn';
[N,M]=size(wn);
% escala = (1:1:N)/samplingFreq;
escala = (0:1:N-1)/samplingFreq2; %frequencia de amostragem de 40MHz na recep��o
figure;
plot(escala*1e6, wn,'b-','LineWidth',0.8);
title('Sinal chirp com tap','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

%----------------------------------------------------------
%Sinal flip com aplica��o do filtro com perfil Gaussiano
%Filtro mismatchFilt (descasado)
%----------------------------------------------------------
%wn = wn';
mismatchFilt = wn.*tapChirpREAL;
[N,M]=size(mismatchFilt);
% escala = (1:1:N)/samplingFreq;
escala = (1:1:N)/samplingFreq2;
figure;
plot(escala*1e6,mismatchFilt,'b-','LineWidth',0.8);
title('mismatchFilt','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

%----------------------------------------------------------
%Sinal flip sem aplica��o do filtro com perfil Gaussiano
%Filtro matchFilt (casado)
%Convolu��o do sinal de eco com o filtro matchFilt (casado)
%----------------------------------------------------------

matchFilt = tapChirpREAL;
mismatchFilt_RF = conv(ecoChirp20, mismatchFilt); % ecoChirp20 � o RAW data capturado
matchFilt_RF = conv(ecoChirp20, matchFilt);

[N,M]=size(tapChirpREAL);
% escala = (1:1:N)/samplingFreq;
escala = (0:1:N-1)/samplingFreq2;
figure;
plot(escala*1e6,tapChirpREAL,'b-','LineWidth',0.8);
title('tapChirpREAL','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;


[N,M]=size(mismatchFilt_RF);
% escala = (1:1:N)/samplingFreq;
escala = (0:1:N-1)/samplingFreq2; %amostragem de 40MHz na recep��o
figure;
plot(escala*1e3,mismatchFilt_RF,'b-','LineWidth',0.8);
title('mismatchFilt RF','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

[N,M]=size(ecoChirp20);
escala = (0:1:N-1)/samplingFreq2;

a = ecoChirp20./max(abs(ecoChirp20));
b = conv(ecoChirp20, matchFilt)./max(abs(conv(ecoChirp20, matchFilt)));
c = conv(ecoChirp20, mismatchFilt)./max(abs(conv(ecoChirp20, mismatchFilt)));

[X,Y]=size(b);
escala_conv = (0:1:X-1)/samplingFreq2;

figure;

%plot(ecoChirp20./max(abs(ecoChirp20))), hold on, plot(conv(ecoChirp20, matchFilt)./max(abs(conv(ecoChirp20, matchFilt)))), plot(conv(ecoChirp20, mismatchFilt)./max(abs(conv(ecoChirp20, mismatchFilt))))
plot(escala*1e3,a,'b-','LineWidth',0.8);
hold on;
plot(escala_conv*1e3,b,'k-','LineWidth',0.8);
hold on;
plot(escala_conv*1e3,c,'r-','LineWidth',0.8);
legend('ecoChirp20','ecoChirp20 matchFilt','ecoChirp20 mismatchFilt');
xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
axis tight;

figure;
subplot(3,1,1);
plot(escala*1e3,a,'b-','LineWidth',0.8);
legend('ecoChirp20');
axis tight;
subplot(3,1,2);
plot(escala_conv*1e3,b,'k-','LineWidth',0.8);
legend('ecoChirp20 matchFilt');
axis tight;
subplot(3,1,3);
plot(escala_conv*1e3,c,'r-','LineWidth',0.8);
legend('ecoChirp20 mismatchFilt');
xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
%ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
axis tight;

