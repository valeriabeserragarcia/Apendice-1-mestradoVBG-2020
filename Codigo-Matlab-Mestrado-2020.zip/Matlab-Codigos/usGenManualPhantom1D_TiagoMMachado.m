function [pht1D,ampScatter,miliPhantom] = usGenManualPhantom1D_TiagoMMachado(NaxialScatt,sizePhantom,n,flag,inputPos,inputAmpScatt,inputAngScatt)
%***************************************************************************************************
% Universidade Estadual de Campinas [University of Campinas] - UNICAMP
% Fac. de Eng. El�trica e de Computa��o [School of Electrical and Computing Engineering] - FEEC
% Departamento de Engenharia Biom�dica [Department of Biomedical Engineering] - DEB (1)
% Centro de Engenharia Biom�dica [Center for Biomedical Engineering] - CEB (2)
%
% Autor [Author]: Tiago de Moraes Machado {machado.tiago@gmail.com} (1)
% Orientador [Adviser]: Prof. Dr. Eduardo Tavares Costa (1),(2)
%
% OBjetivo [Goal]: Gerar manualmente phantom computacional unidimensional, a fim de poder controlar
% o posicionamento dos espalhadores
%
%***************************************************************************************************

if (nargin <= 3),
    flag = 1;
    inputPos = 0;
    inputAmpScatt = 0;
    inputAngScatt = 0;
end

if (NaxialScatt <= 0),
    NaxialScatt = 1;
end

f = phantom(1,n,0);

if (flag == 1),

disp('Na dire��o axial');
axialScattPos = zeros(0);
ampScatt = zeros(0);
angScatt = zeros(0);
pht1D = f;
ampScatter = f;
count = 0;
for ii = 1:NaxialScatt,
    count = count + 1;
    fprintf('Posicao do espalhador %d [mm]: ',ii);
%     axialScattPos(ii) = (n/(sizePhantom*1.0E-3))*1.0E-3 * input('')
    axialScattPos(ii) = (n/sizePhantom)*1.0E-3 * input('');
    ampScatt(ii) = input('Amplitude [entre 0 e 1]: ');
    angScatt(ii) = input('Fase [graus, entre 0 e 180o]: ');
end

else
    pht1D = f;
    ampScatter = f;
    axialScattPos = (n/sizePhantom)*1.0E-3 * inputPos;
    ampScatt = inputAmpScatt;
    angScatt = inputAngScatt;
    
end

% Armazena a quantidade de espalhadores na direcao axial
qttAxialScatt = axialScattPos;
% Arrendonda posicao do espalhador para o  mais proximo numero inteiro
posColPhantom = round(qttAxialScatt);
% converte posicao no phantom em milimetros
miliPhantom = axialScattPos*(sizePhantom*1.0E-3)./n;
% Converte o angulo: graus em radianos
radian = angScatt*(pi/180);
% chama a funcao 'PHANTOMUS' para gerar a estrutura 1-D de acordo com a
% amplitude e fase informada pelo usuario
pht1D(posColPhantom) = ampScatt.*(cos(radian)+(1i*sin(radian)));
ampScatter(posColPhantom) = ampScatt;

end
