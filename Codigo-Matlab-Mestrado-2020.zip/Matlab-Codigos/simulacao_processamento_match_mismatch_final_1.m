%***************************************************************************************************
% Universidade Estadual de Campinas [University of Campinas] - UNICAMP
% Fac. de Eng. El�trica e de Computa��o [School of Electrical and Computing Engineering] - FEEC
% Departamento de Engenharia Biom�dica [Department of Biomedical Engineering] - DEB (1)
% Centro de Engenharia Biom�dica [Center for Biomedical Engineering] - CEB (2)
% Universidade Tecnol�gica Federal do Paran� [Federal University of Technology � Paran�] - UTFPR (3) 
%
% Autores(as): 
% Val�ria Bezerra Garcia
% Amauri Amorin Assef {amauriassef@utfpr.edu.br} (3)
% Tiago de Moraes Machado {machado.tiago@gmail.com} 
% Orientador : Prof. Dr. Eduardo Tavares Costa (1),(2)
%
%***************************************************************************************************
% Descri��o: Script de simula��o desenvolvido para cria��o de phantom com
% dois grupos de espalhadores (fios de nylon). Os grupos possuem as 
% seguintes especifica��es:
% 1)  1o grupo 
% Distancia_do 1o fio de nylon do grupo 1 = 2 cm;
% 11 alvos com espa�amento de 5,16 mm

% 2)  2o grupo 
% Distancia_do 1o fio de nylon do grupo 2 = 6,1 cm;
% 5 alvos com espa�amento de 2,72, 4,75, 6,83 e 10,48 mm;
%
% O arquivo pode ser exetutado com as seguintes op��es:
%
% 1 - Selecionar o tipo do transdutor atrav�s da string "transdType":
%     '2.25 MHz' ou '5 MHz';
%
% 2 - Selecionar a dura��o do pulso de excita��o atrav�s da string
%    "pulse_duration": '5us', '10us' ou '20us';
%***************************************************************************************************
% Vers�o 1
% Revis�o: Retirada a normaliza��o nos sinais processados pelos filtros casado e
% descasado para mostrar a melhora na rela��o sinal-ru�do 
%***************************************************************************************************


close all;
clear all;

clc;
disp('=========================================================== ');
disp('Simula��o dos 2 grupos de espalhadores do Phantom da Unicamp');
disp('=========================================================== ');
disp(' ');

%% Central pulse frequency (Hz)

%--------------------------------------------------------
% Selecionar a frequencia central do transdutor
%--------------------------------------------------------

transdType = '2,25 MHz';
% transdType = '5,0 MHz';


%% Dura��o do pulso de excita��o

%--------------------------------------------------------
% Selecionar a dura��o do pulso de excita��o chip
%--------------------------------------------------------

pulse_duration = '5 \mus';      % us
% pulse_duration = '10 \mus';
% pulse_duration = '20 \mus';

%% Settings to plot figures
FontName = 'Helvetia';
FontWeight = 'Bold';
FontSizeTitle = 15;
FontSizeXlabel = 12;
FontSizeYlabel = 12;
FontSizeAxes = 12;
esp = 0.8;

%% LOAD GLOBAL PARAMETERS

% Sound speed (m/s)
soundSpeed = 1480;
% Sampling frequency (Hz)
samplingFreq = 160 * 10^6;
% Sampling time (s)
samplingTime = 1/samplingFreq;
% Window size used to plot the data
winFreq = 10000000;
% Frequencia de amostragem da recep��o de 40 MHz
samplingFreq2=  40 * 10^6;
% Frequencia de amostragem da recep��o de 40 MHz
fs = samplingFreq2;

%% TRANSDUCER MODELLING: CIRCULAR MONO-ELEMENT

% Verifica a frequencia central do transdutor
tf = strcmp(transdType,'2,25 MHz');

if tf == 1
    transdCenterFreq = 2.25 * 10^6;
    disp('Freq. central do transdutor = 2.25 MHz');
    freq_central = 'fc = 2,25 MHz';
else
    transdCenterFreq = 5 * 10^6;
    disp('Freq. central do transdutor = 5 MHz');
    freq_central = 'fc = 5 MHz';
end;

pd = strcmp(pulse_duration,'5 \mus');
if pd == 1
    disp('Dura��o do pulso chirp = 5 us');
else
    pd = strcmp(pulse_duration,'10 \mus');
    if pd == 1
        disp('Dura��o do pulso chirp = 10 us');
    else
        disp('Dura��o do pulso chirp = 20 us');
    end;
end;


% Central pulse frequency (Hz)
f0 = transdCenterFreq;
% Setting the transducer as having one dimension (1D). Do not change it.
diamTransd1D = 0;
% Fractional bandwidth (if ratio is 1 --> 100%)
% fractionalBW = 0.4; %largura de banda/frequ�ncia central (normalizado)para 2.25MHz
fractionalBW = 0.4; %largura de banda/frequ�ncia central (normalizado)para 5MHz
% fractionalBW = 0.6344; %largura de banda/frequ�ncia central (normalizado)para 10MHz
% Effective transducer bandwidth is computed as largBanda * freqCentral
transdBW = fractionalBW * transdCenterFreq;
% Wavelength
lambda = soundSpeed/transdCenterFreq;

%% Teste pulso ultrass�nico

escala_t = 0:1/fs:3/f0;

% Set the impulse response
impulse_response=cos(2*pi*f0*(escala_t));
impulse_response=impulse_response.*hanning(max(size(impulse_response)))';
impulse_response_norm = impulse_response/max(abs(impulse_response));

plot(escala_t*10^6,impulse_response_norm,'b-','LineWidth',1.5);
title('Pulso ultrass�nico convencional','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend(freq_central);
grid off;
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

%-----------------------------------
% FFT do pulso ultrass�nico
%-----------------------------------
[N,M]=size(impulse_response_norm');
impulse_response_norm_fft = zeros(1024,1);
impulse_response_norm_fft(1:N,1) = impulse_response_norm;

% N�mero de amostras para a FFT
NFFT = length(impulse_response_norm_fft);
N = NFFT;

Y1 = fft(impulse_response_norm_fft);

f=(fs*(0:(N-2)/2)/N)';
f=f*1e-6;

sinal_fft = abs(Y1(1:(N/4))/N);
sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));

figure;
plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1.5);
title('Espectro do pulso ultrass�nico','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend(freq_central);
grid on;
xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;


%% Phantom 1D do trabalho de mestrado

%----------------------
% Dez fios de nylon
%----------------------
d = 5.16;               % mm
N_grupo_1 = 11;         % n�mero de fios de nylon no Phantom
%N_grupo_2 = 4;          % n�mero de fios de nylon no Phantom
N_grupo_2 = 5;          % n�mero de fios de nylon no Phantom
base = 2*0.7*10^-2;       % desconsiderar a base e a parte superior
h_phantom = 16.2*10^-2-base;  % altura do phantom (fim da escala de tempo/profundidade)
distancia_transdutor_phantom1 = 2*10^-2;
distancia_transdutor_phantom2 = 6.1*10^-2;
distancia_transdutor_phantom2 = 4.7*10^-2;

pos_grupo_1 = zeros(1,N_grupo_1);
for i=1:N_grupo_1
    pos_grupo_1(1,i) = distancia_transdutor_phantom1 + (5.16*10^-3)*(i-1);
end;

%----------------------
% Quatro fios de nylon
%----------------------
%pos_grupo_2 = [2.72 4.75 6.83 10.48]*10^-3;
pos_grupo_2 = [0 2.72 7.47 14.3 24.78]*10^-3;
pos_grupo_2 = distancia_transdutor_phantom2 + pos_grupo_2;

%----------------------
% C�lculo da posi��o dos alvos nos 2 phantoms
% x = vt/2 => t = 2x/v => posicao = round(t*fs)
%----------------------
t_grupo_1 = 2*pos_grupo_1/soundSpeed;
indice_phantom_grupo1 = round(t_grupo_1*fs);

t_grupo_2 = 2*pos_grupo_2/soundSpeed;
indice_phantom_grupo2 = round(t_grupo_2*fs);

t_altura = 2*h_phantom/soundSpeed;
indice_altura = round(t_altura*fs);

%Criacao do phantom com comprimento total
phantom_grupo_1 = zeros(1,indice_altura);
phantom_grupo_2 = zeros(1,indice_altura);

for i=1:N_grupo_1
    phantom_grupo_1(1,indice_phantom_grupo1(1,i)) = 1;
end;

for i=1:N_grupo_2
    phantom_grupo_2(1,indice_phantom_grupo2(1,i)) = 1;
end;

escala_t = (1:1:indice_altura)/fs;
escala_x = escala_t * soundSpeed/2;

% figure;
% plot(escala_t*10^6,phantom_grupo_1,'b-','LineWidth',1.5);
% title('Phantom Unidimensional 1D','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend('1o grupo de espalhadores');
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% %axis tight;
% axis ([0 escala_t(end)*10^6 0 1.1]);


figure;
plot(escala_x*10^3,phantom_grupo_1,'b-','LineWidth',1.5);
title('Phantom Unidimensional 1D','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('1o grupo de espalhadores');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
%axis tight;
axis ([0 escala_x(end)*10^3 0 1.1]);

% figure;
% plot(escala_t*10^6,phantom_grupo_2,'b-','LineWidth',1.5);
% title('Phantom Unidimensional 1D','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend('2o grupo de espalhadores');
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% %axis tight;
% axis ([0 escala_t(end)*10^6 0 1.1]);

figure;
plot(escala_x*10^3,phantom_grupo_2,'b-','LineWidth',1.5);
title('Phantom Unidimensional 1D','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('2o grupo de espalhadores');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
%axis tight;
axis ([0 escala_x(end)*10^3 0 1.1]);

pause;

%% Convolu��o dos sinais retroespalhados para o grupo 1

a = conv(impulse_response_norm,phantom_grupo_1)';

% Retirada das amostras incluidas na convolu��o
pos = ceil(max(size(impulse_response_norm))/2); 
a_temp = a(pos:end-pos+1);
a = a_temp;

[N,M]=size(a);

escala_n = 1:1:N;
escala_t = escala_n/fs;
escala_t = escala_t';
escala_x = escala_t * soundSpeed/2;

%----------------------
% Atenuacao
%----------------------
disp('atenua��o = 0.1 dB/cmMHz');
if tf == 1
    atenuacao = 0.1*2.25; % 0.1 dB/cmMHz
else
    atenuacao = 0.1*5; % 0.1 dB/cmMHz
end;

alpha = -1*atenuacao*escala_x*10^2;
exponencial = exp(alpha);
a_aten = a.*exponencial;
a_aten = a_aten/max(abs(a_aten));

b=abs(hilbert(a_aten))';

% figure;
% plot(escala_t*10^6,a_aten,'b-','LineWidth',1);
% hold on;
% plot(escala_t*10^6,b,'r--','LineWidth',1.5);
% titulo = ['Sinal retroespalhado - fc = ',transdType,' - 1o Grupo'];
% title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend('Sinal de RF','Envelope');
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% %axis tight;
% axis ([0 escala_t(end)*10^6 -1 1]);

figure;
plot(escala_x*10^3,a_aten,'b-','LineWidth',1);
hold on;
plot(escala_x*10^3,b,'r-','LineWidth',1.5);
titulo = ['Sinal retroespalhado - fc = ',transdType,' - 1o Grupo'];
title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Sinal de RF','Envelope');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
%axis tight;
axis ([0 escala_x(end)*10^3 -1 1]);

figure;
plot(escala_x*10^3,a_aten,'b-','LineWidth',1);
hold on;
plot(escala_x*10^3,b,'r-','LineWidth',1);
titulo = ['Amplia��o do 1o eco - fc = ',transdType,' - 1o Grupo'];
title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Sinal de RF','Envelope');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis ([19.4 20.6 -1 1]);

pause;


%% Convolu��o dos sinais retroespalhados para o grupo 2

a = conv(impulse_response_norm,phantom_grupo_2)';

% Retirada das amostras incluidas na convolu��o
pos = ceil(max(size(impulse_response_norm))/2); 
a_temp = a(pos:end-pos+1);
a = a_temp;

[N,M]=size(a);

escala_n = 1:N;
escala_t = escala_n/fs;
escala_t = escala_t';
escala_x = escala_t * soundSpeed/2;

%----------------------
% Atenuacao
%----------------------
if tf == 1
    atenuacao = 0.1*2.25; % 0.1 dB/cmMHz
else
    atenuacao = 0.1*5; % 0.1 dB/cmMHz
end;

alpha = -1*atenuacao*escala_x*10^2;
exponencial = exp(alpha);
a_aten = a.*exponencial;
a_aten = a_aten/max(abs(a_aten));

b=abs(hilbert(a_aten))';

% figure;
% plot(escala_t*10^6,a_aten,'b-','LineWidth',1);
% hold on;
% plot(escala_t*10^6,b,'r--','LineWidth',1.5);
% titulo = ['Sinal retroespalhado - fc = ',transdType,' - 2o Grupo'];
% title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend('Sinal de RF','Envelope');
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% %axis tight;
% axis ([0 escala_t(end)*10^6 -1 1]);

figure;
plot(escala_x*10^3,a_aten,'b-','LineWidth',1);
hold on;
plot(escala_x*10^3,b,'r-','LineWidth',1);
titulo = ['Sinal retroespalhado - fc = ',transdType,' - 2o Grupo'];
title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Sinal de RF','Envelope');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
%axis tight;
axis ([0 escala_x(end)*10^3 -1 1]);

figure;
plot(escala_x*10^3,a_aten,'b-','LineWidth',1);
hold on;
plot(escala_x*10^3,b,'r-','LineWidth',1);
titulo = ['Amplia��o do 1o eco - fc = ',transdType,' - 2o Grupo'];
title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend('Sinal de RF','Envelope');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
%axis tight;
axis ([63 64.5 -1 1]);
pause;
close all;


%% CHIRP (OR LINEAR FREQUENCY MODULATION) CONSTRUCTION

% Coded excitation parameters
A = 1.0; % Amplitude

tempo_chirp = strcmp(pulse_duration,'5 \mus');

if tempo_chirp == 1
    T = 5*10^-6; % Time duration of the excitation 5us
else
    tempo_chirp = strcmp(pulse_duration,'10 \mus');
    if tempo_chirp == 1
        T = 10*10^-6; % Time duration of the excitation 10us
    else
        T = 20*10^-6; % Time duration of the excitation 20us
    end;
end;

sampFreqChirp = fs; % Chirp sampling frequency

% Optimum factor to chirp/transducer ratio
optimumFactorBW = 2.0; % ******

% Window function to apply amplitude tapering such as Tukey, Gaussian,
% Hanning, and son on
winTap = 'lanczos';
tapFactor = 25; % Tapering factor (%)
tapFactor_str = 'Fator Tap = 25%';
tapCheby = 60; % Sidelobe leve cutoff for mismatch filtering

% Firstly, we must create a linear modulation frequency (LFM) signal
[LFMchirp,tapLFMchirp,tChirp,startFreqSweep,finalFreqSweep,B,optimalBW,...
    TBP] = usGenChirpExcitation_TiagoMMachado(A,T,sampFreqChirp,...
    transdCenterFreq,transdBW,optimumFactorBW,tapFactor,winTap);

sinal_chirp_trad = real(LFMchirp);
sinal_chirp_trad = sinal_chirp_trad/max(abs(sinal_chirp_trad));
comprimento_filtro = max(size(sinal_chirp_trad));

if tf == 1
    faixa = 'f = 2,25 MHz +/- 1 MHz';
    
else
    faixa = 'f = 5 MHz +/- 2 MHz';
end;

figure;
plot(tChirp*10^6,sinal_chirp_trad,'b-','LineWidth',1);
title('Sinal chirp (LFM)','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
grid off;
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
legend(faixa);
axis([0 tChirp(end)*10^6 min(sinal_chirp_trad)-0.25 max(sinal_chirp_trad)+0.25]);

[M,N]=size(sinal_chirp_trad);
sinal_chirp_trad_fft = zeros(2048,1);
sinal_chirp_trad_fft(1:N,1) = sinal_chirp_trad;

% N�mero de amostras para a FFT
NFFT = length(sinal_chirp_trad_fft);
N = NFFT;

Y1 = fft(sinal_chirp_trad_fft);

f=(sampFreqChirp*(0:(N-2)/2)/N)';
f=f*1e-6;

sinal_fft = abs(Y1(1:(N/4))/N);
sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));

sinal_tapLFMchirp = real(tapLFMchirp);

figure;
plot(tChirp*10^6,real(tapLFMchirp),'b-','LineWidth',1);
title('Sinal de excita��o chirp (LFM) com tapering de amplitude','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
grid off;
xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
legend([faixa,' ',tapFactor_str]);
axis([0 tChirp(end)*10^6 min(real(tapLFMchirp))-0.25 max(real(tapLFMchirp))+0.25]);


[M,N]=size(sinal_tapLFMchirp);
sinal_tapLFMchirp_fft = zeros(2048,1);
sinal_tapLFMchirp_fft(1:N,1) = sinal_tapLFMchirp;

% N�mero de amostras para a FFT
NFFT = length(sinal_tapLFMchirp_fft);
N = NFFT;

Y1 = fft(sinal_tapLFMchirp_fft);

f=(sampFreqChirp*(0:(N-2)/2)/N)';
f=f*1e-6;

sinal_fft = abs(Y1(1:(N/4))/N);
sinal_fft_1 = 20*log10(sinal_fft/max(sinal_fft));

figure;
plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
hold on;
plot(f(1:NFFT/4),sinal_fft_1,'r-','LineWidth',1);
title('Espectro em frequ�ncia dos sinais chirp','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%legend('Eco');
grid on;
legend('Chirp tradicional','Chirp com tapering 25%')
xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis tight;

pause;

%% Convolu��o dos sinais retroespalhados para o sinal chirp - Grupo 1

a = conv(sinal_tapLFMchirp,phantom_grupo_1)';

% Retirada das amostras incluidas na convolu��o
pos = ceil(max(size(sinal_tapLFMchirp))/2); 
a_temp = a(pos:end-pos+1);
a = a_temp;

[N,M]=size(a);

escala_n = 1:N;
escala_t = escala_n/fs;
escala_t = escala_t';
escala_x = escala_t * soundSpeed/2;

%----------------------
% Atenuacao
%----------------------
if tf == 1
    atenuacao = 0.1*2.25; % 0.1 dB/cmMHz
else
    atenuacao = 0.1*5; % 0.1 dB/cmMHz
end;

alpha = -1*atenuacao*escala_x*10^2;
exponencial = exp(alpha);
a_aten = a.*exponencial;

a_aten = a_aten/max(abs(a_aten));
sinal_retroespalhado_grupo1 = a_aten;

b=abs(hilbert(a_aten))';

if tf == 1
    txt = 'f = 2,25 MHz';
else
    txt = 'f = 5 MHz';
end;

% figure;
% plot(escala_t*10^6,a_aten,'b-','LineWidth',1);
% hold on;
% plot(escala_t*10^6,b,'r--','LineWidth',1.5);
% titulo = ['Sinal retroespalhado - Chirp de ',pulse_duration,' - 1o Grupo'];
% title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% titulo_legenda = ['Sinal de RF (',txt,')'];
% legend(titulo_legenda,'Envelope');
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis ([0 escala_t(end)*10^6 -1 1]);

figure;
plot(escala_x*10^3,a_aten,'b-','LineWidth',1);
hold on;
plot(escala_x*10^3,b,'r-','LineWidth',1);
titulo = ['Sinal retroespalhado - chirp de ',pulse_duration,' - 1o Grupo'];
title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
titulo_legenda = ['Sinal de RF (',txt,')'];
legend(titulo_legenda,'Envelope');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
%text(75,-0.9,txt);
axis ([0 escala_x(end)*10^3 -1 1]);

pause;

%% Convolu��o dos sinais retroespalhados para o sinal chirp - Grupo 2

a = conv(sinal_tapLFMchirp,phantom_grupo_2)';

% Retirada das amostras incluidas na convolu��o
pos = ceil(max(size(sinal_tapLFMchirp))/2); 
a_temp = a(pos:end-pos+1);
a = a_temp;

[N,M]=size(a);

escala_n = 1:1:N;
escala_t = escala_n/fs;
escala_t = escala_t';
escala_x = escala_t * soundSpeed/2;

%----------------------
% Atenuacao
%----------------------
if tf == 1
    atenuacao = 0.1*2.25; % 0.1 dB/cmMHz
else
    atenuacao = 0.1*5; % 0.1 dB/cmMHz
end;

alpha = -1*atenuacao*escala_x*10^2;
exponencial = exp(alpha);
a_aten = a.*exponencial;
a_aten = a_aten/max(abs(a_aten));
sinal_retroespalhado_grupo2 = a_aten;

b=abs(hilbert(a_aten))';

% figure;
% plot(escala_t*10^6,a_aten,'b-','LineWidth',1);
% hold on;
% plot(escala_t*10^6,b,'r--','LineWidth',1.5);
% titulo = ['Sinal retroespalhado - Chirp de ',pulse_duration,' - 2o Grupo'];
% title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend(titulo_legenda,'Envelope');
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis ([0 escala_t(end)*10^6 -1 1]);

figure;
plot(escala_x*10^3,a_aten,'b-','LineWidth',1);
hold on;
plot(escala_x*10^3,b,'r-','LineWidth',1);
titulo = ['Sinal retroespalhado - chirp de ',pulse_duration,' - 2o Grupo'];
title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
legend(titulo_legenda,'Envelope');
xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeXlabel);
ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    'FontSize',FontSizeYlabel);
axis ([0 escala_x(end)*10^3 -1 1]);

pause;
close all;

%% Processamento dos filtros

% La�o para processar os dois grupos de espalhadores - fios de nylon
x=0;
for grupo_phantom=1:2
    
    if (grupo_phantom == 1)
        ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 1o grupo de espalhadores do phantom');
        tg = '1o Grupo';        % t�tulo do grupo
    else
        ecoChirp20 = sinal_retroespalhado_grupo2;
        disp('Prcessamento do 2o grupo de espalhadores do phantom');
        tg = '2o Grupo';        % t�tulo do grupo
    end;
    
    chirp20 = sinal_tapLFMchirp;
        
    %--------------------------------------
    % Inverte (flip) do vetor do sinal
    %--------------------------------------
    tapChirpREAL = fliplr(chirp20)'; % MUDAR INTERVALO... chirp enviado para o transdutor capturado pelo sistema de aquisi��o
    [N,M]=size(tapChirpREAL);
    escala = (1:1:N)/fs;
    escala_x = escala * soundSpeed/2;
    
    figure;
    plot(escala*1e6,tapChirpREAL,'b-','LineWidth',1);
    titulo = ['Filtro casado (match) - chirp de ',pulse_duration];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    titulo_legenda = ['Invers�o temporal (',txt,')'];
    legend(titulo_legenda);
    %legend('Invers�o temporal do sinal de chirp com tapering');
    %text(3.2,-1.2,txt);
    axis([0 escala(end)*10^6 -1.3 1.3]);
    
    figure;
    subplot(2,1,1);
    plot(escala*1e6,chirp20,'b-','LineWidth',1);
    titulo = ['Sinal com tapering - chirp de ',pulse_duration];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    legend(txt);
    %text(3.2,-1.2,txt);
    axis([0 escala(end)*10^6 -2 2]);
    
    subplot(2,1,2);
    plot(escala*1e6,tapChirpREAL,'b-','LineWidth',1);
    titulo = ['Filtro casado (match) - chirp de ',pulse_duration];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    legend('Invers�o temporal');
    axis([0 escala(end)*10^6 -2 2]);
    
    % Filtro com o mesmo tamanho do vetor com perfil Gaussuiano
    
    wn = usGenWindowFilter_TiagoMMachado(tapChirpREAL, 60,'chebyshev');
    
    wn = wn';
    [N,M]=size(wn);
    escala = (0:1:N-1)/fs; %frequencia de amostragem de 40MHz na recep��o
    
    figure;
    plot(escala*1e6, wn,'b-','LineWidth',1);
    title('Tapering Chebyshev com l�bulo secund�rio de 60 dB','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    axis tight;
    
    %----------------------------------------------------------
    %Sinal flip com aplica��o do filtro com perfil Gaussiano
    %Filtro mismatchFilt (descasado)
    %----------------------------------------------------------
    mismatchFilt = wn.*tapChirpREAL;
    [N,M]=size(mismatchFilt);
    escala = (1:1:N)/fs;
    
    figure;
    plot(escala*1e6,mismatchFilt,'b-','LineWidth',1);
    titulo = ['Filtro descasado (mismatch) - chirp de ',pulse_duration];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    titulo_legenda = ['Filtro casado com tap. Chebyshev (',txt,')'];
    legend(titulo_legenda);
    axis([0 escala(end)*1e6 -1.3 1.3]);
    pause;
    close all;
    
    %% Aplica��o dos filtro
    
    %----------------------------------------------------------
    %%Sinal flip sem aplica��o do filtro com perfil Gaussiano
    %Filtro matchFilt (casado)
    %Convolu��o do sinal de eco com o filtro matchFilt (casado)
    %----------------------------------------------------------
    
    matchFilt = tapChirpREAL;
    mismatchFilt_RF = conv(ecoChirp20, mismatchFilt); % ecoChirp20 � o RAW data capturado
    matchFilt_RF = conv(ecoChirp20, matchFilt);
    
    % Retirada das amostras incluidas na convolu��o
    pos = ceil(max(size(mismatchFilt))/2); 
    mismatchFilt_RF_temp = mismatchFilt_RF(pos:end-pos+1);
    mismatchFilt_RF = mismatchFilt_RF_temp;
    
    matchFilt_RF_temp = matchFilt_RF(pos:end-pos+1);
    matchFilt_RF = matchFilt_RF_temp;
          
 %   mismatchFilt_RF = mismatchFilt_RF/max(abs(mismatchFilt_RF));
 %   matchFilt_RF = matchFilt_RF/max(abs(matchFilt_RF));
    
    % Aplica��o do filtro casado
    [N,M]=size(matchFilt_RF);
    escala = (1:1:N)/fs;
    escala_x = escala * soundSpeed/2;
    
%     figure;
%     plot(escala*1e3,matchFilt_RF,'b-','LineWidth',1);
%     hold on;
%     plot(escala*1e3,abs(hilbert(matchFilt_RF)),'r-','LineWidth',1);
%     titulo_legenda = ['Sinal filtrado (',txt,')'];
%     legend(titulo_legenda,'Envelope');
%     %legend('Sinal de RF','Envelope');
%     titulo = ['Aplica��o do filtro casado no sinal de RF - ',tg];
%     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     axis([0 escala(end)*1e3 -1 1 ]) ;
    
    figure;
    plot(escala_x*1e3,matchFilt_RF,'b-','LineWidth',1);
    hold on;
    plot(escala_x*1e3,abs(hilbert(matchFilt_RF)),'r-','LineWidth',1);
    titulo_legenda = ['Sinal filtrado (',txt,')'];
    legend(titulo_legenda,'Envelope');
    %legend('Sinal de RF','Envelope');
    titulo = ['Aplica��o do filtro casado no sinal de RF - ',tg];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    %axis([0 escala_x(end)*1e3 -1 1 ]) ;
    axis tight
    
    % Aplica��o do filtro descasado
    [N,M]=size(mismatchFilt_RF);
    escala = (0:1:N-1)/fs;
    escala_x = escala * soundSpeed/2;
    
%     figure;
%     plot(escala*1e3,mismatchFilt_RF,'b-','LineWidth',1);
%     hold on;
%     plot(escala*1e3,abs(hilbert(mismatchFilt_RF)),'r-','LineWidth',1);
%     titulo_legenda = ['Sinal filtrado (',txt,')'];
%     legend(titulo_legenda,'Envelope');
%     titulo = ['Aplica��o do filtro descasado no sinal de RF - ',tg];
%     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     axis([0 escala(end)*1e3 -1 1 ]) ;
    
    figure;
    plot(escala_x*1e3,mismatchFilt_RF,'b-','LineWidth',1);
    hold on;
    plot(escala_x*1e3,abs(hilbert(mismatchFilt_RF)),'r-','LineWidth',1);
    titulo_legenda = ['Sinal filtrado (',txt,')'];
    legend(titulo_legenda,'Envelope');
    titulo = ['Aplica��o do filtro descasado no sinal de RF - ',tg];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    %axis([0 escala_x(end)*1e3 -1 1 ]) ;
    axis tight
    
    pause;
    close;
    
    %% Comparacao final
    
    [N,M]=size(ecoChirp20);
    escala = (1:1:N)/fs;
    escala_x = escala * soundSpeed/2;
    
    %a = ecoChirp20./max(abs(ecoChirp20));
    a = ecoChirp20;
    b = matchFilt_RF;
    c = mismatchFilt_RF;
    
    [X,Y]=size(b);
    escala_conv = (1:1:X)/fs;
    escala_conv_x = escala_conv * soundSpeed/2;
    
    %-----------------------------
    % 1) Sinal casado
    %-----------------------------
    
    % Escala de tempo
%     figure;
%     subplot(2,1,1);
%     plot(escala*1e3,a,'b-','LineWidth',1);
%     hold on;
%     plot(escala*1e3,abs(hilbert(a)),'r-','LineWidth',1);
%     titulo = ['Sinal retroespalhado - Chirp de ',pulse_duration,' - ',tg];
%     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     titulo_legenda = ['Sinal de RF (',txt,')'];
%     legend(titulo_legenda,'Envelope');
%     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     axis([0 escala(end)*1e3 -1 1]) ;
%     
%     subplot(2,1,2);
%     plot(escala_conv*1e3,b,'b-','LineWidth',1);
%     titulo = ['Aplica��o do filtro casado - ',tg];
%     title(titulo,'FontName',FontName,...
%         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     hold on;
%     plot(escala_conv*1e3,abs(hilbert(b)),'r-','LineWidth',1);
%     legend('Sinal filtrado','Envelope');
%     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     axis([0 escala_conv(end)*1e3 -1 1]) ;
%     %axis([0 escala(end)*1e3 -1 1]) ;
     
      % Escala de profundidade
    figure;
    subplot(2,1,1);
    plot(escala_x*1e3,a,'b-','LineWidth',1);
    hold on;
    plot(escala_x*1e3,abs(hilbert(a)),'r-','LineWidth',1);
    titulo = ['Sinal retroespalhado - chirp de ',pulse_duration,' - ',tg];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    titulo_legenda = ['Sinal de RF (',txt,')'];
    legend(titulo_legenda,'Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    %axis([0 escala_x(end)*1e3 -1 1]) ;
    axis tight;
    
    subplot(2,1,2);
    plot(escala_conv_x*1e3,b,'b-','LineWidth',1);
    titulo = ['Aplica��o do filtro casado - ',tg];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    hold on;
    plot(escala_conv_x*1e3,abs(hilbert(b)),'r-','LineWidth',1);
    legend('Sinal filtrado','Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    %axis([0 escala_conv_x(end)*1e3 -1 1]) ;
    %axis([0 escala_x(end)*1e3 -1 1]) ;
    axis tight;
  
    v1 = min(a(1000:7000,1));
    v2 = max(a(1000:7000,1));
    
    % Ampliacao da escala de profundidade
    figure;
    subplot(2,1,1);
    plot(escala_x*1e3,a,'b-','LineWidth',1);
    hold on;
    plot(escala_x*1e3,abs(hilbert(a)),'r-','LineWidth',1);
    titulo = ['Amplia��o do eco - chirp de ',pulse_duration,' - ',tg];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    titulo_legenda = ['Sinal de RF (',txt,')'];
    legend(titulo_legenda,'Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    if grupo_phantom == 1
        %axis([10 80 -2 2]) ;
        axis([10 80 v1 v2]) ;
    else
        %axis([55 80 -2 2]) ;
        axis([40 80 v1 v2]) ;
    end;
    
    v1 = min(b(1000:7000,1));
    v2 = max(b(1000:7000,1));
    
    subplot(2,1,2);
    plot(escala_conv_x*1e3,b,'b-','LineWidth',1);
    hold on;
    plot(escala_conv_x*1e3,abs(hilbert(b)),'r-','LineWidth',1);
    titulo = ['Amplia��o do eco com filtro casado - ',tg];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend('Sinal filtrado','Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    if grupo_phantom == 1
       % axis([10 80 -2 2]) ;
        axis([10 80 v1 v2]) ;
    else
        %axis([55 80 -2 2]) ;
        axis([40 80 v1 v2]) ;
    end;
     
   
    %-----------------------------
    % 2) Sinal descasado
    %-----------------------------
    
    % Escala de tempo
%     figure;
%     subplot(2,1,1);
%     plot(escala*1e3,a,'b-','LineWidth',1);
%     hold on;
%     plot(escala*1e3,abs(hilbert(a)),'r-','LineWidth',1);
%     titulo = ['Sinal retroespalhado - chirp de ',pulse_duration,' - ',tg];
%     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     titulo_legenda = ['Sinal de RF (',txt,')'];
%     legend(titulo_legenda,'Envelope');
%     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     axis([0 escala(end)*1e3 -1 1]) ;
%     
%     subplot(2,1,2);
%     plot(escala_conv*1e3,c,'b-','LineWidth',1);
%     titulo = ['Aplica��o do filtro descasado - ',tg];
%     title(titulo,'FontName',FontName,...
%         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     hold on;
%     plot(escala_conv*1e3,abs(hilbert(c)),'r-','LineWidth',1);
%     legend('Sinal filtrado','Envelope');
%     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     %axis([0 escala_conv(end)*1e3 -1 1]) ;
%     axis([0 escala_conv(end)*1e3 -1 1]) ;
    
    % Escala de profundidade
    figure;
    subplot(2,1,1);
    plot(escala_x*1e3,a,'b-','LineWidth',1);
    hold on;
    plot(escala_x*1e3,abs(hilbert(a)),'r-','LineWidth',1);
    titulo = ['Sinal retroespalhado - chirp de ',pulse_duration,' - ',tg];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    titulo_legenda = ['Sinal de RF (',txt,')'];
    legend(titulo_legenda,'Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    axis([0 escala_x(end)*1e3 -1 1]) ;
    
    v1 = min(c(1000:7000,1));
    v2 = max(c(1000:7000,1));
    
    subplot(2,1,2);
    plot(escala_conv_x*1e3,c,'b-','LineWidth',1);
    titulo = ['Aplica��o do filtro descasado - ',tg];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    hold on;
    plot(escala_conv_x*1e3,abs(hilbert(c)),'r-','LineWidth',1);
    legend('Sinal filtrado','Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    %axis([0 escala_conv_x(end)*1e3 -1 1]) ;
    %axis([0 escala_x(end)*1e3 -1 1]) ;
    axis tight;
    
    v1 = min(a(1000:7000,1));
    v2 = max(a(1000:7000,1));
    
     % Amplia�ao da scala de profundidade
    figure;
    subplot(2,1,1);
    plot(escala_x*1e3,a,'b-','LineWidth',1);
    hold on;
    plot(escala_x*1e3,abs(hilbert(a)),'r-','LineWidth',1);
    titulo = ['Amplia��o do eco - chirp de ',pulse_duration,' - ',tg];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    titulo_legenda = ['Sinal de RF (',txt,')'];
    legend(titulo_legenda,'Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    if grupo_phantom == 1
        %axis([10 80 -2 2]) ;
        axis([10 80 v1 v2]) ;
    else
        %axis([55 80 -2 2]) ;
        axis([40 80 v1 v2]) ;
    end;
    
    v1 = min(c(1000:7000,1));
    v2 = max(c(1000:7000,1));
    
    subplot(2,1,2);
    plot(escala_conv_x*1e3,c,'b-','LineWidth',1);
    hold on;
    plot(escala_conv_x*1e3,abs(hilbert(c)),'r-','LineWidth',1);
    titulo = ['Amplia��o do eco com filtro descasado - ',tg];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend('Sinal filtrado','Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    if grupo_phantom == 1
        %axis([10 80 -2 2]) ;
        axis([10 80 v1 v2]) ;
    else
        %axis([55 80 -2 2]) ;
        axis([40 80 v1 v2]) ;
    end;
   
   
    %% FFT do sinal com sinal de eco bruto

    [N,M]=size(a);
    
    phantom_fft = zeros(2^12,1);
    phantom_fft(1:N,1) = a;
    
    % N�mero de amostras para a FFT
    NFFT = length(phantom_fft);
    N = NFFT;
    
    Y1 = fft(phantom_fft);
    
    f=(fs*(0:(N-2)/2)/N)';
    f=f*1e-6;
    
    sinal_fft = abs(Y1(1:(N/4))/N);
    sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
    
    figure;
    %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
    plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
    titulo = ['Espectro do sinal bruto de RF - ',tg];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend(txt);
    grid on;
    xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    axis tight;
        
    %-----------------------------------
    % FFT do sinal com sinal de com filtro casado
    %-----------------------------------
    [N,M]=size(b);
    
    phantom_fft = zeros(2^12,1);
    phantom_fft(1:N,1) = b;
    
    % N�mero de amostras para a FFT
    NFFT = length(phantom_fft);
    N = NFFT;
    
    Y1 = fft(phantom_fft);
    
    f=(fs*(0:(N-2)/2)/N)';
    f=f*1e-6;
    
    sinal_fft = abs(Y1(1:(N/4))/N);
    sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
    
    figure;
    %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
    plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
    titulo = ['Espectro do sinal com filtro casado - ',tg];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend(txt);
    grid on;
    xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    axis tight;
    
    %-----------------------------------
    % FFT do sinal com sinal de com filtro descasado
    %-----------------------------------
    [N,M]=size(c);
    
    phantom_fft = zeros(2^12,1);
    phantom_fft(1:N,1) = c;
    
    % N�mero de amostras para a FFT
    NFFT = length(phantom_fft);
    N = NFFT;
    
    Y1 = fft(phantom_fft);
    
    f=(fs*(0:(N-2)/2)/N)';
    f=f*1e-6;
    
    sinal_fft = abs(Y1(1:(N/4))/N);
    sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
    
    figure;
    %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
    plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
    titulo = ['Espectro do sinal com filtro descasado - ',tg];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend(txt);
    grid on;
    xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    axis tight;
    
    pause;
    close all;

end;


% Janela para compara��o da redu��o do l�bulo secund�rio com o filtro
% retangular

wvtool(rectwin(comprimento_filtro));
disp('An�lise do l�bulo secund�rio com janela retangular');

% Janela para compara��o da redu��o do l�bulo secund�rio com o filtro
% Chebyshev

wvtool(wn);
disp('An�lise do l�bulo secund�rio com janela Chebyshev');