function Wn = usGenWindowFilter_TiagoMMachado(inputSignal,tapFactor,winType)
%***************************************************************************************************
% Universidade Estadual de Campinas [University of Campinas] - UNICAMP
% Fac. de Eng. El�trica e de Computa��o [School of Electrical and Computing Engineering] - FEEC
% Departamento de Engenharia Biom�dica [Department of Biomedical Engineering] - DEB (1)
% Centro de Engenharia Biom�dica [Center for Biomedical Engineering] - CEB (2)
%
% Autor [Author]: Tiago de Moraes Machado {machado.tiago@gmail.com} (1)
% Orientador [Adviser]: Prof. Dr. Eduardo Tavares Costa (1),(2)
%
%***************************************************************************************************

L = length(inputSignal);

if (strcmp(winType,'chebyshev')),
    dBsideLobe = tapFactor;
    Wn = chebwin(L,dBsideLobe)';
elseif (strcmp(winType,'tukey')),
    tapFactor = tapFactor/100;
    Wn = tukeywin(L,tapFactor)';
elseif (strcmp(winType,'kaiserwin')),
    bta = tapFactor;
    Wn = kaiser(L,bta)';
elseif (strcmp(winType,'lanczos')),
    M = L;
    tapFactor = tapFactor/100;
    m = round(M*(tapFactor/2));
    Wn = lanczosWindow(m,M);
elseif (strcmp(winType,'gaussian')),
    alpha = tapFactor;
    Wn = gausswin(L,alpha);
elseif (strcmp(winType,'blackman')),
    Wn = blackman(L,'symmetric');
end


end
