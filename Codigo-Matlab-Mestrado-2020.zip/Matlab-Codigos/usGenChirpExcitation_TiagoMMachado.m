function [LFMchirp,tapLFMchirp,t,startFreqSweep,finalFreqSweep,...
    B,optimalBW,TBP] = usGenChirpExcitation_TiagoMMachado(A,T,samplingFreq,centerFreq,transdBW,...
    optimumFactorBW,tapFactor,winType,Nsamples)
%***************************************************************************************************
% Universidade Estadual de Campinas [University of Campinas] - UNICAMP
% Fac. de Eng. El�trica e de Computa��o [School of Electrical and Computing Engineering] - FEEC
% Departamento de Engenharia Biom�dica [Department of Biomedical Engineering] - DEB (1)
% Centro de Engenharia Biom�dica [Center for Biomedical Engineering] - CEB (2)
%
% Autor [Author]: Tiago de Moraes Machado {machado.tiago@gmail.com} (1)
% Orientador [Adviser]: Prof. Dr. Eduardo Tavares Costa (1),(2)
%
%***************************************************************************************************
%
% OBJETIVO: Gerar sinal de modula��o em frequ�ncia linear unidimensional (1D), tamb�m chamado chirp 
%           linear.
%
% ENTRADA
%   A : Amplitude de modula��o/excita��o do sinal em fun��o do tempo
%   T : Tempo de dura��o do sinal/pulso, [s]
%   samplingFreqChirp : Frequ�ncia de amostragem do sinal modulado, [Hz]
%   centerFreq : Frequ�ncia central do sinal modulado, [Hz]
%   transdBW : Largura de banda do sinal (no caso de ultrassom, compreende � do transdutor), [Hz]
%   optimumFactorBW : Fator de corre��o �timo para realiza��o da varredura da largura de banda chirp
%   tapFactor : Fator de alisamento para fun��o janela a ser aplicada no sinal modulado para redu��o
%   de l�bulos laterais
%   winType : Tipo de fun��o janela a ser aplicada sobre o sinal de modula��o
%
% SA�DA
%   LFMchirp : sinal chirp (modulado linearmente)
%   tapLFMchirp : sinal chirp (modulado linearmente) alisado (tapering)
%   tChirp : vetor temporal contendo o tempo total de dura��o do sinal de excita��o gerado
%   B : Largura de banda do sinal chirp
%   TBP : Produto Tempo-Largura de Banda do sinal
%
% REFER�NCIAS
%   - Misaridis  T.  Ultrasound  imaging  using  coded  signals.  [thesis].  Denmark: 
%   Technical University of Denmark, 2001.
%   - Behar V, Adam D. Parameter optimization of pulse compression in ultrasound imaging systems 
%   with coded excitation. Ultrasonics. 2004;42(10):1101-9.
% 
%***************************************************************************************************

if (nargin < 9),
    % Constru��o do vetor de tempo do sinal de modula��o chirp
%     t = 0.01e-5:(1/samplingFreq):T;
    t = 0:(1/samplingFreq):T;
else
    samplingTime = T/Nsamples;
    % Construcao do vetor de pontos da duracao temporal Chirp
    t = (0:Nsamples-1)*samplingTime;  % 0<=t<=1s
end

% Frequ�ncia inicial de varredura
startFreqSweep = centerFreq - (transdBW/2);
% startFreqSweep = 0;

% Frequ�ncia final de varredura
finalFreqSweep = centerFreq + (transdBW/2);
% finalFreqSweep = centerFreq;

bla1 = 2*startFreqSweep;
bla2 = 2*finalFreqSweep;

% Largura de banda do sinal
B = finalFreqSweep - startFreqSweep;



% Largura de banda do sinal, ap�s aplica��o de fator de corre��o para otimizar a frequ�ncia de 
% varredura chirp
optimalBW = optimumFactorBW * B;
% optimalBW = B;

% Produto Tempo-Largura de Banda do sinal
% TBP = B*T;
TBP = optimalBW*T;
% B = optimalBW;

% Pega o comprimento (numero de pontos) do vetor de tempo Chirp
[~, col] = size(t);

% Define o tipo de funcao janela, dentro da qual a excitcao Chirp sera
% construida
fcnJanela = rectwin(col)';

% Cria sinal de excita��o codificada chirp (FM linear)
LFMchirp = fcnJanela .* A.*exp((1i*2*pi*(centerFreq-(optimalBW/2)).*t)+(2*pi*1i*((optimalBW/2)/T)*(t.*t)));

% LFMchirp = fcnJanela .* A .* exp((1i*2*pi*(centerFreq-(optimalBW/2)).* t) + ...
%     (pi*1i*((optimalBW + (optimalBW/2))/T)*(t.*t)));

% Cria sinal chirp linear alisado (tapering), com finalidade de reduzir l�bulos laterais (sidelobes)
Wn = usGenWindowFilter_TiagoMMachado(LFMchirp,tapFactor,winType);
tapLFMchirp = Wn.*LFMchirp;

end
