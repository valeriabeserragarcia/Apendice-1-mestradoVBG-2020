function [p,t]=pgauss(fc,bw,fs,diam,bwr,twr)
% PGAUSS -  Generates an analytic 1D and 2D RF gaussian modulated pulses
% [p,t] = PGAUSS(fc,bw,fs,diam,bwr,twr)
% p:   gaussian pulse
% t:   time axis (optional)
% fc:  central frequency (in Hz)
% bw:  relative bandwidth (absolute: 1=>100%)
% fs:  sampling rate (in Hz)
% diam: transducer diameter (in m, default = 0)
%       if diam = 0, generates a 1D pulse
%       if diam < 0, generates de simetrical pulse (length = width)
% bwr: bandwidth calculation level (default = -6dB)
% twr: pulse cutoff level (default = -40dB)
%
% See also GAUSPULS, HILBERT,
% Ricardo Grossi Dantas - grossi@ceb.unicamp.br

% default parameters
if (nargin<4), diam=0; end;  % pulse diameter
if (nargin<5), bwr=-6; end;  % bandwidth calculation level (in dB)
if (nargin<6), twr=-40; end; % pulse cutoff level in time domain (in dB)

% 1D pulse
tc = gauspuls('cutoff',fc,bw,bwr,twr); % returns the cutoff time
t = -tc:1/fs:tc; % time axis
% gaussian modulated pulse in time domain
p=gauspuls(t,fc,bw);
p=hilbert(p);
temp=0:length(t)-1;
temp=temp./fs;
t=temp; % time axis
if diam==0, return; end;

% 2D pulse
c=1540; % sound velocity in water
lambda=c/fc; % wavelength
gshape=abs(p); % pulse envelope
% calculates the diameter in wavelengths units or make a simetric pulse (diam<0)
if diam>0,
    dlambda=diam/lambda; % diameter in wavelenth units
    dlambda=round(dlambda*(fs/fc)); % diameter in pixels
    % make diameter odd (simetric around central point)
    if ~mod(dlambda,2), dlambda=dlambda-1; end;
elseif diam<0,
    dlambda=length(p);
end;
% replicates the 1d pulse to create the 2d pulse, according to the
% transducer diameter in lambda units
p2=repmat(p,dlambda,1);
% resample the pulse envelope to be applied, as a gain, in the lateral direction
te=0:dlambda-1;
te=(te-(max(te)/2))./fs;
temp=gauspuls(te,fc,length(p).*bw./dlambda);
latshape=abs(hilbert(temp));
y=latshape';
[m n]=size(p2);
y2=repmat(y,1,n); % 2d gain
p2=p2.*y2; % 2d gain in the 2d RF gaussian modulated pulse
p=p2./max(abs(p2(:)));
return;
