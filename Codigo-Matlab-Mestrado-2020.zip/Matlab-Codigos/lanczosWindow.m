function W = lanczosWindow(m, M)
% m = length of the taper section (sinc shape)
% M = window total length (M >= 2*m + 3)

    W = zeros(1, M);

    for kk = 2:(m + 2) % first lobe ("raised" sinc)
        W(kk) = sinc_func((m + 3 - kk), m);
    end
    
    W((m + 3):(M - m - 2)) = 1; % plator
    
    for kk = (M - m - 1):(M - 1) % second lobe ("fallen" sinc)
        W(kk) = sinc_func((kk - M + m + 2), m);
    end
    
end

function b_i = sinc_func(ii, m)
    b_i = sin((pi*ii)/(m + 2))/((pi*ii)/(m + 2));
end