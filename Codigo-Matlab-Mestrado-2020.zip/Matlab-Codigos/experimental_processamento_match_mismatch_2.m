%***************************************************************************************************
% Universidade Estadual de Campinas [University of Campinas] - UNICAMP
% Fac. de Eng. El�trica e de Computa��o [School of Electrical and Computing Engineering] - FEEC
% Departamento de Engenharia Biom�dica [Department of Biomedical Engineering] - DEB (1)
% Centro de Engenharia Biom�dica [Center for Biomedical Engineering] - CEB (2)
%
% Autor [Author]: Tiago de Moraes Machado {machado.tiago@gmail.com} (1)
% Orientador [Advisor]: Prof. Dr. Eduardo Tavares Costa (1),(2)
%
%***************************************************************************************************
% Vers�o inicial
% Autor: Amauri Amorin Assef
% Descri��o: Script de simula��o desenvolvido a partir da vers�o do arquivo
% Codigo_Final_4.
%
% O arquivo pode ser exetutado com uma das duas frequ�ncias: 2,25 e 5 MHz.
% Verificar e selecionar a op��o na se��o:
% "TRANSDUCER MODELLING: CIRCULAR MONO-ELEMENT"
%
% Conforme a frequ�ncia do transdutor (2,25 ou 5 MHz) os seguintes
% arquivos podem ser usados na simula��o:
%         filename = 'chirp-2.25MHz-5us.csv';
%         filename = 'chirp-2.25MHz-10us.csv';
%         filename = 'chirp-2.25MHz-20us.csv';
%         filename = 'chirp-5MHz-5us.csv';
%         filename = 'chirp-5MHz-10us.csv';
%         filename = 'chirp-5MHz-20us.csv';
%
% 1 - Selecionar o tipo do transdutor atrav�s da string "transdType":
%     '2.25 MHz' ou '5 MHz';
%
% 2 - Selecionar a dura��o do pulso de excita��o atrav�s da string
%    "pulse_duration": '5us', '10us' ou '20us';
%***************************************************************************************************
% Vers�o 1
% Revis�o: Incluidos todos os arquivos de processamento para sinais
% convencionais e chirp
% Inicialmente s�o gerados os sinais com excita��o utilizando pulsos convencionais
% Na segunda etapa, s�o utilizados os sinais chirp sem alvos (for dos grupos 1 e 2)
% para leitura das respostas impulsivas usadas para a aplica��o dos filtros
% casado e descasado
% Por fim, os filtros s�o aplicados em todos os sinais com excita��o chirp
% para os dois grupos, gerando 12 an�lises
%***************************************************************************************************

close all;
clear all;

clc;
disp('=========================================================== ');
disp('Processamento dos sinais experimentias dos 2 grupos de espalhadores do Phantom da Unicamp');
disp('=========================================================== ');

disp(' ');


%% Settings to plot figures
FontName = 'Helvetia';
FontWeight = 'Bold';
FontSizeTitle = 15;
FontSizeXlabel = 12;
FontSizeYlabel = 12;
FontSizeAxes = 12;
esp = 0.8;

%% LOAD GLOBAL PARAMETERS

% Sound speed (m/s)
soundSpeed = 1480;
% Sampling frequency (Hz)
samplingFreq = 160 * 10^6;
% Sampling time (s)
samplingTime = 1/samplingFreq;
% Window size used to plot the data
winFreq = 10000000;
% Frequencia de amostragem da recep��o de 40 MHz
samplingFreq2=  40 * 10^6;
% Frequencia de amostragem da recep��o de 40 MHz
fs = samplingFreq2;


%% Leitura dos dados de arquivo do tipo csv

% Leitura dos arquivos com sinais de RF captados com excita��o convencional
% de 2,25 e 5 MHz para os 2 grupos de alvos no phantom de ultrassom

addpath('TESTES-62V')

for i=1:4
    
    dif = 8237;
    
    if i==1
        % Nome do arquivo
        filename = '2.25MHz-convencional-5mm.csv';
        % String com frequ�ncia central
        transdType = '2,25 MHz';
        % String com frequ�ncia central
        freq_central = '(fc = 2,25 MHz)';
        % String com o grupo de alvos
        grupo = '1o Grupo';
        % Deslocamento de amostras para ajuste da posi��o do sinal
        inicio_zoom = 2133;
        % Tamanho total para a amplia��o da imagem
        fim_zoom = inicio_zoom + dif;
        % Limites para sele��o da resposta impulsiva
        limite1 = 7400;
        limite2 = 7600;
        
    elseif i==2
        filename = '2.25MHz-convencional-espacamento-dif.csv';
        transdType = '2,25 MHz';
        freq_central = '(fc = 2,25 MHz)';
        grupo = '2o Grupo';
        inicio_zoom = 6261;
        fim_zoom = inicio_zoom + dif;
        limite1 = 7400;
        limite2 = 7600;
    elseif i==3
        filename = '5MHz-convencional-5mm.csv';
        transdType = '5 MHz';
        freq_central = '(fc = 5 MHz)';
        grupo = '1o Grupo';
        inicio_zoom = 6763;
        fim_zoom = inicio_zoom + dif;
        limite1 = 7490;
        limite2 = 7570;
        
    else
        filename = '5MHz-convencional-espacamento-dif.csv'; % 2o Grupo
        transdType = '5 MHz';
        freq_central = '(fc = 5 MHz)';
        grupo = '2o Grupo';
        inicio_zoom = 1670;
        fim_zoom = inicio_zoom + dif;
        limite1 = 7490;
        limite2 = 7570;
    end;
    
    T1 = readtable(filename);
    
    % Convers�o de Tabela para vetor 2D
    A = table2array(T1);
    
    % Pega informa��es somente do canal 4 (total de 8 canais)
    eco = A(:,4);
    
    % Salva a linha de eco na tabela
    tabela_eco(:,i) = eco;

    % C�lculo das escalas da abscissa
    [N,M]=size(eco);
    escala_n = (1:N)';
    escala_t = escala_n/fs;
    escala_x = escala_t * soundSpeed/2;
    
    eco_norm = eco/max(abs(eco));
    
    % Figura do sinal de eco de RF no tempo
    figure;
    plot(escala_n,eco_norm,'b-');
    %titulo = ['Sinal retroespalhado - Fc = ',transdType,' - ',grupo];
    titulo = ['Sinal de eco com pulso convencional',' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Sinal bruto ',freq_central];
    legend(legenda);
    xlabel('Amostras','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 escala_n(end) -1 1]);
    
    % % Figura do sinal de eco de RF no tempo
    % figure;
    % plot(escala_n,eco_norm,'b-');
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend('Sinal bruto');
    % xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % axis tight;
    
    eco_norm_limite = eco_norm(inicio_zoom:fim_zoom,1);
    [N,M]=size(eco_norm_limite);
    
    escala_n = (1:N)';
    escala_t = escala_n/fs;
    escala_x = escala_t * soundSpeed/2;
    
    % Figura do sinal de eco de RF no tempo
    figure;
    plot(escala_x*10^3,eco_norm_limite,'b-');
    titulo = ['Sinal de eco com pulso convencional',' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Sinal bruto ',freq_central];
    legend(legenda);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    axis ([0 145 -1 1]);
    
    
    %% Filtro Passa-Faixa
    
    %HI_PASS Returns a discrete-time filter object.
    
    % Foi necess�rio incluir um filtro passa-faixa para eliminar o n�vel CC
    % do sinal de eco
    
    % MATLAB Code
    % Generated by MATLAB(R) 8.3 and the Signal Processing Toolbox 6.21.
    % Generated on: 23-Nov-2020 17:34:17
    
    % All frequency values are in MHz.
    Fs = 40;  % Sampling Frequency
    
    % Passa-faixa
    Fstop1 = 0.05;             % First Stopband Frequency
    Fpass1 = 1;                % First Passband Frequency
    Fpass2 = 9;                % Second Passband Frequency
    Fstop2 = 9.95;             % Second Stopband Frequency
    Dstop1 = 0.0031622776602;  % First Stopband Attenuation
    Dpass  = 0.057501127785;   % Passband Ripple
    Dstop2 = 0.0031622776602;  % Second Stopband Attenuation
    dens   = 20;               % Density Factor
    
    % Calculate the order from the parameters using FIRPMORD.
    [N, Fo, Ao, W] = firpmord([Fstop1 Fpass1 Fpass2 Fstop2]/(Fs/2), [0 1 ...
        0], [Dstop1 Dpass Dstop2]);
    
    filter_order = N;
    
    % Calculate the coefficients using the FIRPM function.
    b  = firpm(N, Fo, Ao, W, {dens});
    Hd = dfilt.dffir(b);
    
    % Aplica��o do filtro FIR com Transformada de Hilbert
    q = filter(Hd,eco_norm_limite);
    
    [N,M]=size(q);
    escala_dado_n = (1:N)';
    escala_dado_t = escala_dado_n/fs;
    escala_dado_x = escala_dado_t * soundSpeed/2;
    
    % % Figura da sele��o
    % figure;
    % plot(escala_dado_t*10^6,q,'b-','LineWidth',1.5);
    % titulo = ['Resposta impulsiva - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %legend('Sinal de RF','Envelope');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % %axis tight;
    % axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    
    % figure;
    % plot(escala_dado_t*10^6,eco_norm,'b-',escala_dado_t*10^6,q,'r-');
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %legend('Sinal de RF','Envelope');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % legend('Sinal bruto de RF','Sinal filtrado');
    % %axis tight;
    % axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    
    % figure;
    % plot(escala_dado_t*10^6,eco_norm,'b-',escala_dado_t*10^6,q,'r-');
    % titulo = ['Resposta impulsiva - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %legend('Sinal de RF','Envelope');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % legend('Sinal bruto','Sinal filtrado');
    % %axis tight;
    % axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    % pos = ceil(max(size(sinal_tapLFMchirp))/2);
    % a_temp = a(pos:end-pos+1);
    % a = a_temp;
    
    % Retirada das amostras incluidas na convolu��o
    [N,M]=size(q);
    q_shift = zeros(N,M);
    q_shift(1:end-(filter_order/2),1) = q(filter_order/2+1:end,1);
    
    % figure;
    % plot(escala_dado_t*10^6,eco_norm,'b-',escala_dado_t*10^6,q_shift,'r-');
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend('Sinal bruto de RF','Sinal filtrado');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % legend('Sinal bruto','Sinal filtrado');
    % %axis tight;
    % axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    figure;
    plot(escala_dado_x*10^3,q_shift,'b-');
    titulo = ['Sinal de eco com pulso convencional',' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Sinal filtrado ',freq_central];
    legend(legenda);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 145 -1 1]);
    
    hilb = abs(hilbert(q_shift));
    
    % figure;
    % plot(escala_dado_x*10^3,eco_norm_limite,'b-',escala_dado_x*10^3,q_shift,'r-');
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend('Sinal bruto ','Sinal filtrado');
    % xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % %axis tight;
    % axis ([0 escala_dado_x(end)*10^3 -1 1]);
    
    
    figure;
    plot(escala_dado_x*10^3,q_shift,'b-',escala_dado_x*10^3,hilb,'r-');
    titulo = ['Sinal de eco com pulso convencional',' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Sinal filtrado ',freq_central];
    legend(legenda,'Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 145 -1 1]);
    
    % Versao 2
    figure;
    plot(escala_dado_x*10^3,hilb,'r-');
    titulo = ['Sinal de eco com pulso convencional',' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Envelope do sinal filtrado ',freq_central];
    legend(legenda);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 145 0 1]);
    
    v1 = min(q_shift(1000:7000,1));
    v2 = max(q_shift(1000:7000,1));
    
    figure;
    plot(escala_dado_x*10^3,q_shift,'b-',escala_dado_x*10^3,hilb,'r-');
    titulo = ['Amplia��o do sinal de eco',' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Sinal filtrado ',freq_central];
    legend(legenda,'Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    %axis ([20 80 -0.6 0.6]);
    tf = strcmp(grupo,'1o Grupo');
    
    if tf == 1
        axis ([20 85 v1 v2]);
    else
        axis ([50 85 v1 v2]);
    end;
    
    
    % Versao 2
    figure;
    plot(escala_dado_x*10^3,hilb,'r-');
    titulo = ['Amplia��o do sinal de eco',' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Envelope do sinal filtrado ',freq_central];
    legend(legenda);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    %axis ([20 80 -0.6 0.6]);
    tf = strcmp(grupo,'1o Grupo');
    
    if tf == 1
        axis ([20 85 0 v2]);
    else
        axis ([50 85 0 v2]);
    end;
        
    
    
    % % Figura do sinal de eco de RF na amostra para sele��o de intervalo
    % figure;
    % plot(escala_n,eco_norm,'b-','LineWidth',1.5);
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend('Sinal de RF','Envelope');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % %axis tight;
    % axis tight;
    % %axis ([0 escala_x(end)*10^3 -1.1 1.1]);
    
    %limite1 = 7400;
    %limite2 = 7600;
    
    dado1 = eco_norm_limite(limite1:limite2);
    dado1_filtrado = q_shift(limite1:limite2);
    [N,M]=size(dado1);
    
    escala_dado_n = (1:N)';
    escala_dado_t = escala_dado_n/fs;
    escala_dado_x = escala_dado_t * soundSpeed/2;
    
    dado_norm = dado1/max(abs(dado1));
    dado_filtrado_norm = dado1_filtrado/max(abs(dado1_filtrado));
    
    % Figura da sele��o
    figure;
    plot(escala_dado_t*10^6,dado_norm,'b-',escala_dado_t*10^6,dado_filtrado_norm,'r-');
    titulo = ['Resposta impulsiva',' - ',grupo,' ',freq_central];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %    legenda = ['Sinal bruto ',freq_central];
    legend('Sinal bruto','Sinal filtrado');
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    
    %-----------------------------------
    %% FFT do pulso ultrass�nico
    %-----------------------------------
    [N,M]=size(dado_norm);
    impulse_response_norm_fft = zeros(256,1);
    impulse_response_norm_fft(1:N,1) = dado_norm;
    
    % N�mero de amostras para a FFT
    NFFT = length(impulse_response_norm_fft);
    N = NFFT;
    
    Y1 = fft(impulse_response_norm_fft);
    
    f=(fs*(0:(N-2)/2)/N)';
    f=f*1e-6;
    
    sinal_fft = abs(Y1(1:(N/4))/N);
    sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
    
    % figure;
    % plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1.5);
    % title('Espectro do pulso ultrass�nico','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend(freq_central);
    % grid on;
    % xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % axis tight;
    
    
    %-----------------------------------
    %% FFT do pulso ultrass�nico
    %-----------------------------------
    [N,M]=size(dado_filtrado_norm);
    impulse_response_norm_fft = zeros(256,1);
    impulse_response_norm_fft(1:N,1) = dado_filtrado_norm;
    
    % N�mero de amostras para a FFT
    NFFT = length(impulse_response_norm_fft);
    N = NFFT;
    
    Y1 = fft(impulse_response_norm_fft);
    
    f=(fs*(0:(N-2)/2)/N)';
    f=f*1e-6;
    
    sinal_fft = abs(Y1(1:(N/4))/N);
    sinal_fft_1 = 20*log10(sinal_fft/max(sinal_fft));
    
    figure;
    plot(f(1:NFFT/4),sinal_fft_0,'b-');
    hold on;
    plot(f(1:NFFT/4),sinal_fft_1,'r-');
    title(['Espectro da resposta impulsiva ',freq_central],'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend('Sinal bruto','Sinal filtrado');
    grid on;
    xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    axis tight;
    
    pause;
    close all;
    
end;

disp('Processamento dos sinais chirp');


%% Leitura dos 12 sinais com excita��o chirp nos 2 grupos

% N�mero de amostras para imagens ampliadas
dif = 9000;

for i=1:1:6
    
    if (i==1)
        filename = 'chirp-2.25MHz-5us.csv';
        txt = 'f = 2,25 MHz';
        pulse_duration = '5 \mus';      % us
        
        transdType = '2,25 MHz';
        freq_central = '(fc = 2,25 MHz)';
        inicio_zoom = 613;
        fim_zoom = inicio_zoom + dif;
        
        limite1 = 7450;
        limite2 = 7750;
       
    elseif (i==2)
        filename = 'chirp-2.25MHz-10us.csv';
        txt = 'f = 2,25 MHz';
        pulse_duration = '10 \mus';
        
        transdType = '2,25 MHz';
        freq_central = '(fc = 2,25 MHz)';
        inicio_zoom = 10586;
        fim_zoom = inicio_zoom + dif;
        
        limite1 = 7470;
        limite2 = 7920;
        
    elseif (i==3)
        filename = 'chirp-2.25MHz-20us.csv';
        txt = 'f = 2,25 MHz';
        pulse_duration = '20 \mus';
        
        transdType = '2,25 MHz';
        freq_central = '(fc = 2,25 MHz)';
        inicio_zoom = 14574;
        fim_zoom = inicio_zoom + dif;
        
        limite1 = 7470;
        limite2 = 8300;
        
    elseif i==4
        filename = 'chirp-5MHz-5us.csv';
        txt = 'f = 5 MHz';
        pulse_duration = '5 \mus';      % us
        
        transdType = '5 MHz';
        freq_central = '(fc = 5 MHz)';
        
        inicio_zoom = 16979;
        fim_zoom = inicio_zoom + dif;
        
        limite1 = 7510;
        limite2 = 7740;
        
    elseif i==5
        filename = 'chirp-5MHz-10us.csv';
        txt = 'f = 5 MHz';
        
        pulse_duration = '10 \mus';      % us
        
        transdType = '5 MHz';
        freq_central = '(fc = 5 MHz)';
        
        inicio_zoom = 9500;
        fim_zoom = inicio_zoom + dif;
        
        limite1 = 7510;
        limite2 = 7900;
        
    else
        filename = 'chirp-5MHz-20us.csv';
        txt = 'f = 5 MHz';
        pulse_duration = '20 \mus';      % us
        
        transdType = '5 MHz';
        freq_central = '(fc = 5 MHz)';
        
        inicio_zoom = 4003;
        fim_zoom = inicio_zoom + dif;
        
        limite1 = 7510;
        limite2 = 8300;
        
    end;
    
    
    T1 = readtable(filename);
    
    % Convers�o de Tabela para vetor 2D
    A = table2array(T1);
    
    % Pega informa��es somente do canal 4 (total de 8 canais)
    eco = A(:,4);
    
    [N,M]=size(eco);
    
    escala_n = (1:N)';
    escala_t = escala_n/fs;
    escala_x = escala_t * soundSpeed/2;
    
    eco_norm = eco/max(abs(eco));
    
    % Figura do sinal de eco de RF no tempo
    figure;
    plot(escala_n,eco_norm,'b-');
    titulo = ['Sinal de eco com pulso chirp de ',pulse_duration];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %    titulo_legenda = ['Sinal de RF (',txt,')'];
    %    legend(titulo_legenda,'Envelope');
    legenda = ['Sinal bruto ',freq_central];
    legend(legenda);
    xlabel('Amostras','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 escala_n(end) -1 1]);
    
    % % Figura do sinal de eco de RF no tempo
    % figure;
    % plot(escala_n,eco_norm,'b-');
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend('Sinal bruto');
    % xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % axis tight;
    
    eco_norm_limite = eco_norm(inicio_zoom:fim_zoom,1);
    [N,M]=size(eco_norm_limite);
    
    escala_n = (1:N)';
    escala_t = escala_n/fs;
    escala_x = escala_t * soundSpeed/2;
    
    % Figura do sinal de eco de RF no tempo
    figure;
    plot(escala_x*10^3,eco_norm_limite,'b-');
    titulo = ['Sinal de eco com pulso chirp de ',pulse_duration];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Sinal bruto ',freq_central];
    legend(legenda);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    %axis tight;
    axis ([0 160 -1 1]);
    
    
    %% Filtro Passa-Faixa
    
    %HI_PASS Returns a discrete-time filter object.
    
    % MATLAB Code
    % Generated by MATLAB(R) 8.3 and the Signal Processing Toolbox 6.21.
    % Generated on: 23-Nov-2020 17:34:17
    
    % All frequency values are in MHz.
    Fs = 40;  % Sampling Frequency
    
    % Passa-faixa
    Fstop1 = 0.05;             % First Stopband Frequency
    Fpass1 = 1;                % First Passband Frequency
    Fpass2 = 9;                % Second Passband Frequency
    Fstop2 = 9.95;             % Second Stopband Frequency
    Dstop1 = 0.0031622776602;  % First Stopband Attenuation
    Dpass  = 0.057501127785;   % Passband Ripple
    Dstop2 = 0.0031622776602;  % Second Stopband Attenuation
    dens   = 20;               % Density Factor
    
    % Calculate the order from the parameters using FIRPMORD.
    [N, Fo, Ao, W] = firpmord([Fstop1 Fpass1 Fpass2 Fstop2]/(Fs/2), [0 1 ...
        0], [Dstop1 Dpass Dstop2]);
    
    filter_order = N;
    
    % Calculate the coefficients using the FIRPM function.
    b  = firpm(N, Fo, Ao, W, {dens});
    Hd = dfilt.dffir(b);
    
    % Aplica��o do filtro FIR com Transformada de Hilbert
    q = filter(Hd,eco_norm_limite);
    
    [N,M]=size(q);
    
    escala_dado_n = (1:N)';
    escala_dado_t = escala_dado_n/fs;
    escala_dado_x = escala_dado_t * soundSpeed/2;
    
    % % Figura da sele��o
    % figure;
    % plot(escala_dado_t*10^6,q,'b-','LineWidth',1.5);
    % titulo = ['Resposta impulsiva - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %legend('Sinal de RF','Envelope');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % %axis tight;
    % axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    
    % figure;
    % plot(escala_dado_t*10^6,eco_norm,'b-',escala_dado_t*10^6,q,'r-');
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %legend('Sinal de RF','Envelope');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % legend('Sinal bruto de RF','Sinal filtrado');
    % %axis tight;
    % axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    
    % figure;
    % plot(escala_dado_t*10^6,eco_norm,'b-',escala_dado_t*10^6,q,'r-');
    % titulo = ['Resposta impulsiva - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %legend('Sinal de RF','Envelope');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % legend('Sinal bruto','Sinal filtrado');
    % %axis tight;
    % axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    % pos = ceil(max(size(sinal_tapLFMchirp))/2);
    % a_temp = a(pos:end-pos+1);
    % a = a_temp;
    
    % Retirada das amostras incluidas na convolu��o
    [N,M]=size(q);
    q_shift = zeros(N,M);
    q_shift(1:end-(filter_order/2),1) = q(filter_order/2+1:end,1);
    
    % figure;
    % plot(escala_dado_t*10^6,eco_norm,'b-',escala_dado_t*10^6,q_shift,'r-');
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend('Sinal bruto de RF','Sinal filtrado');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % legend('Sinal bruto','Sinal filtrado');
    % %axis tight;
    % axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    figure;
    plot(escala_dado_x*10^3,q_shift,'b-');
    titulo = ['Sinal de eco com pulso chirp de ',pulse_duration];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Sinal filtrado ',freq_central];
    legend(legenda);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 160 -1 1]);
    
    hilb = abs(hilbert(q_shift));
    
    % figure;
    % plot(escala_dado_x*10^3,eco_norm_limite,'b-',escala_dado_x*10^3,q_shift,'r-');
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend('Sinal bruto ','Sinal filtrado');
    % xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % %axis tight;
    % axis ([0 escala_dado_x(end)*10^3 -1 1]);
    
    
    figure;
    plot(escala_dado_x*10^3,q_shift,'b-',escala_dado_x*10^3,hilb,'r-');
    titulo = ['Sinal de eco com pulso chirp de ',pulse_duration];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Sinal filtrado ',freq_central];
    legend(legenda,'Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 160 -1 1]);
    
    %     figure;
    %     plot(escala_dado_x*10^3,q_shift,'b-',escala_dado_x*10^3,hilb,'r-');
    %     titulo = ['Amplia��o do sinal de eco',' - ',grupo];
    %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     legenda = ['Sinal filtrado ',freq_central];
    %     legend(legenda,'Envelope');
    %     xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeYlabel);
    %     %axis tight;
    %     %axis ([20 80 -0.6 0.6]);
    %
    %     tf = strcmp(grupo,'1o Grupo');
    %
    %     if tf == 1
    %         axis ([20 80 -0.6 0.6]);
    %     else
    %         axis ([50 80 -0.8 0.8]);
    %     end;
    
    
    % % Figura do sinal de eco de RF na amostra para sele��o de intervalo
    % figure;
    % plot(escala_n,eco_norm,'b-','LineWidth',1.5);
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend('Sinal de RF','Envelope');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % %axis tight;
    % axis tight;
    % %axis ([0 escala_x(end)*10^3 -1.1 1.1]);
    
    %% Resposta impulsiva
    
    dado1 = eco_norm_limite(limite1:limite2);
    dado1_filtrado = q_shift(limite1:limite2);
    [N,M]=size(dado1);
    
    escala_dado_n = (1:N)';
    escala_dado_t = escala_dado_n/fs;
    escala_dado_x = escala_dado_t * soundSpeed/2;
    
    dado_norm = dado1/max(abs(dado1));
    dado_filtrado_norm = dado1_filtrado/max(abs(dado1_filtrado));
    
    % Salva a resposta impulsiva dos sinais chirp
    [N,M] = size(dado_filtrado_norm);
    
    if (i==1)
        resposta_imp_225_5us = dado_filtrado_norm;
    elseif (i==2)
        resposta_imp_225_10us = dado_filtrado_norm;
    elseif (i==3)
        resposta_imp_225_20us = dado_filtrado_norm;
    elseif (i==4)
        resposta_imp_5_5us = dado_filtrado_norm;
    elseif (i==5)
        resposta_imp_5_10us = dado_filtrado_norm;
    else
        resposta_imp_5_20us = dado_filtrado_norm;
    end;
    
    chirp20 = dado_filtrado_norm;
    
    % Figura da sele��o
    figure;
    plot(escala_dado_t*10^6,dado_norm,'b-',escala_dado_t*10^6,dado_filtrado_norm,'r-');
    titulo = ['Resposta impulsiva com pulso chirp ',freq_central];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %    legenda = ['Sinal bruto ',freq_central];
    legend('Sinal bruto','Sinal filtrado');
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    
    %-----------------------------------
    %% FFT do pulso ultrass�nico
    %-----------------------------------
    [N,M]=size(dado_norm);
    impulse_response_norm_fft = zeros(256,1);
    impulse_response_norm_fft(1:N,1) = dado_norm;
    
    % N�mero de amostras para a FFT
    NFFT = length(impulse_response_norm_fft);
    N = NFFT;
    
    Y1 = fft(impulse_response_norm_fft);
    
    f=(fs*(0:(N-2)/2)/N)';
    f=f*1e-6;
    
    sinal_fft = abs(Y1(1:(N/4))/N);
    sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
    
    % figure;
    % plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1.5);
    % title('Espectro do pulso ultrass�nico','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend(freq_central);
    % grid on;
    % xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % axis tight;
    
    
    %-----------------------------------
    %% FFT do pulso ultrass�nico
    %-----------------------------------
    [N,M]=size(dado_filtrado_norm);
    impulse_response_norm_fft = zeros(256,1);
    impulse_response_norm_fft(1:N,1) = dado_filtrado_norm;
    
    % N�mero de amostras para a FFT
    NFFT = length(impulse_response_norm_fft);
    N = NFFT;
    
    Y1 = fft(impulse_response_norm_fft);
    
    f=(fs*(0:(N-2)/2)/N)';
    f=f*1e-6;
    
    sinal_fft = abs(Y1(1:(N/4))/N);
    sinal_fft_1 = 20*log10(sinal_fft/max(sinal_fft));
    
    figure;
    plot(f(1:NFFT/4),sinal_fft_0,'b-');
    hold on;
    plot(f(1:NFFT/4),sinal_fft_1,'r-');
    title(['Espectro do sinal com pulso chirp ',freq_central],'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend('Sinal bruto','Sinal filtrado');
    grid on;
    xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    axis tight;
    
    
    %% Processamento dos sinais com os filtros casados e descasado
    
    
    %--------------------------------------
    % Inverte (flip) do vetor do sinal
    %--------------------------------------
    tapChirpREAL = fliplr(chirp20')'; % MUDAR INTERVALO... chirp enviado para o transdutor capturado pelo sistema de aquisi��o
    [N,M]=size(tapChirpREAL);
    escala = (1:1:N)/fs;
    escala_x = escala * soundSpeed/2;
    
    figure;
    plot(escala*1e6,tapChirpREAL,'b-');
    titulo = ['Filtro casado (match) - Chirp de ',pulse_duration];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    titulo_legenda = ['Invers�o temporal (',txt,')'];
    legend(titulo_legenda);
    %legend('Invers�o temporal do sinal de chirp com tapering');
    %text(3.2,-1.2,txt);
    axis([0 escala(end)*10^6 -1.3 1.3]);
    
    figure;
    subplot(2,1,1);
    plot(escala*1e6,chirp20,'b-');
    titulo = ['Sinal com tapering - Chirp de ',pulse_duration];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    legend(txt);
    %text(3.2,-1.2,txt);
    axis([0 escala(end)*10^6 -2 2]);
    
    subplot(2,1,2);
    plot(escala*1e6,tapChirpREAL,'b-');
    titulo = ['Filtro casado (match) - Chirp de ',pulse_duration];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    legend('Invers�o temporal');
    axis([0 escala(end)*10^6 -2 2]);
    
    % Filtro com o mesmo tamanho do vetor com perfil Gaussuiano
    
    wn = usGenWindowFilter_TiagoMMachado(tapChirpREAL, 60,'chebyshev');
    
    wn = wn';
    [N,M]=size(wn);
    escala = (0:1:N-1)/fs; %frequencia de amostragem de 40MHz na recep��o
    
    figure;
    plot(escala*1e6, wn,'b-');
    title('Tapering Chebyshev com l�bulo secund�rio de 60 dB','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    axis tight;
    
    %----------------------------------------------------------
    %Sinal flip com aplica��o do filtro com perfil Gaussiano
    %Filtro mismatchFilt (descasado)
    %----------------------------------------------------------
    matchFilt = tapChirpREAL;
    mismatchFilt = wn.*tapChirpREAL;
    
    if (i==1)
        matchFilt_225_5us = matchFilt;
        mismatchFilt_225_5us = mismatchFilt;
    elseif (i==2)
        matchFilt_225_10us = matchFilt;
        mismatchFilt_225_10us = mismatchFilt;
    elseif (i==3)
        matchFilt_225_20us = matchFilt;
        mismatchFilt_225_20us = mismatchFilt;
    elseif (i==4)
        matchFilt_5_5us = matchFilt;
        mismatchFilt_5_5us = mismatchFilt;
    elseif (i==5)
        matchFilt_5_10us = matchFilt;
        mismatchFilt_5_10us = mismatchFilt;
    else
        matchFilt_5_20us = matchFilt;
        mismatchFilt_5_20us = mismatchFilt;
    end;
    
    [N,M]=size(mismatchFilt);
    escala = (1:1:N)/fs;
    
    figure;
    plot(escala*1e6,mismatchFilt,'b-');
    titulo = ['Filtro descasado (mismatch) - Chirp de ',pulse_duration];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    titulo_legenda = ['Filtro casado com tap. Chebyshev (',txt,')'];
    legend(titulo_legenda);
    axis([0 escala(end)*1e6 -1.3 1.3]);
    
    pause;
    close all;
    
    
end;


%% Processamento dos filtros

% La�o para processar os dois grupos de espalhadores - fios de nylon
%x=0;

disp('Incio do processamento dos filtros');
for i=1:1:12
    
    if (i == 1)
        %ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 1o grupo de espalhadores do phantom');
        
        txt = 'f = 2,25 MHz';
        pulse_duration = '5 \mus';      % us
        
        transdType = '2,25 MHz';
        freq_central = '(fc = 2,25 MHz)';
        grupo = '1o Grupo';
        
        filename = '2.25MHz-5u-5mm.csv';
        
        inicio_zoom = 5390;
        fim_zoom = inicio_zoom + dif;
        
        limite1 = 7450;
        limite2 = 7750;
        
        T1 = readtable(filename);
        
        % Convers�o de Tabela para vetor 2D
        A = table2array(T1);
        
        % Pega informa��es somente do canal 4 (total de 8 canais)
        ecoChirp20_temp = A(:,4);
        
        % Salva a linha de eco na tabela
        tabela_eco(:,i) = ecoChirp20_temp;
        
        %ecoChirp20 = ecoChirp20_temp;
        
        %chirp20 = sinal_tapLFMchirp;
        %chirp20 = resposta_imp_225_5us;
        
    elseif (i == 2)
        %ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 2o grupo de espalhadores do phantom');
        
        txt = 'f = 2,25 MHz';
        pulse_duration = '5 \mus';      % us
        
        transdType = '2,25 MHz';
        freq_central = '(fc = 2,25 MHz)';
        grupo = '2o Grupo';
        
        filename = '2.25MHz-5u-espacamento-dif.csv';
        
        inicio_zoom = 254;
        fim_zoom = inicio_zoom + dif;
        
        limite1 = 7450;
        limite2 = 7750;
        
        T1 = readtable(filename);
        
        % Convers�o de Tabela para vetor 2D
        A = table2array(T1);
        
        % Pega informa��es somente do canal 4 (total de 8 canais)
        ecoChirp20_temp = A(:,4);
        
        % Salva a linha de eco na tabela
        tabela_eco(:,i) = ecoChirp20_temp;
        
        %ecoChirp20 = ecoChirp20_temp;
        
        %chirp20 = sinal_tapLFMchirp;
        %chirp20 = resposta_imp_225_5us;
        
    elseif (i == 3)
        %ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 1o grupo de espalhadores do phantom');
        
        txt = 'f = 2,25 MHz';
        pulse_duration = '10 \mus';      % us
        
        transdType = '2,25 MHz';
        freq_central = '(fc = 2,25 MHz)';
        grupo = '1o Grupo';
        
        filename = '2.25MHz-10u-5mm.csv';
        
        inicio_zoom = 1603;
        fim_zoom = inicio_zoom + dif;
        
        limite1 = 7470;
        limite2 = 7920;
        
        T1 = readtable(filename);
        
        % Convers�o de Tabela para vetor 2D
        A = table2array(T1);
        
        % Pega informa��es somente do canal 4 (total de 8 canais)
        ecoChirp20_temp = A(:,4);
        
        % Salva a linha de eco na tabela
        tabela_eco(:,i) = ecoChirp20_temp;
        
        %ecoChirp20 = ecoChirp20_temp;
        
        %chirp20 = sinal_tapLFMchirp;
        %chirp20 = resposta_imp_225_10us;
        
    elseif (i == 4)
        %ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 1o grupo de espalhadores do phantom');
        
        txt = 'f = 2,25 MHz';
        pulse_duration = '10 \mus';      % us
        
        transdType = '2,25 MHz';
        freq_central = '(fc = 2,25 MHz)';
        grupo = '2o Grupo';
        
        filename = '2.25MHz-10u-espacamento-dif.csv';
        
        inicio_zoom = 9825;
        fim_zoom = inicio_zoom + dif;
        
        limite1 = 7470;
        limite2 = 7920;
        
        T1 = readtable(filename);
        
        % Convers�o de Tabela para vetor 2D
        A = table2array(T1);
        
        % Pega informa��es somente do canal 4 (total de 8 canais)
        ecoChirp20_temp = A(:,4);
        
        % Salva a linha de eco na tabela
        tabela_eco(:,i) = ecoChirp20_temp;
        
        %ecoChirp20 = ecoChirp20_temp;
        
        %chirp20 = sinal_tapLFMchirp;
        %chirp20 = resposta_imp_225_10us;
        
    elseif (i == 5)
        %ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 1o grupo de espalhadores do phantom');
        
        txt = 'f = 2,25 MHz';
        pulse_duration = '20 \mus';      % us
        
        transdType = '2,25 MHz';
        freq_central = '(fc = 2,25 MHz)';
        grupo = '1o Grupo';
        
        filename = '2.25MHz-20u-5mm.csv';
        
        inicio_zoom = 455;
        fim_zoom = inicio_zoom + dif;
        
        limite1 = 7470;
        limite2 = 8300;
        
        T1 = readtable(filename);
        
        % Convers�o de Tabela para vetor 2D
        A = table2array(T1);
        
        % Pega informa��es somente do canal 4 (total de 8 canais)
        ecoChirp20_temp = A(:,4);
        
        % Salva a linha de eco na tabela
        tabela_eco(:,i) = ecoChirp20_temp;
        
        %ecoChirp20 = ecoChirp20_temp;
        
        %chirp20 = sinal_tapLFMchirp;
        %chirp20 = resposta_imp_225_20us;
        
    elseif (i == 6)
        %ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 2o grupo de espalhadores do phantom');
        
        txt = 'f = 2,25 MHz';
        pulse_duration = '20 \mus';      % us
        
        transdType = '2,25 MHz';
        freq_central = '(fc = 2,25 MHz)';
        grupo = '2o Grupo';
        
        filename = '2.25MHz-20u-espacamento-dif.csv';
        
        inicio_zoom = 2446;
        fim_zoom = inicio_zoom + dif;
        
        limite1 = 7470;
        limite2 = 8300;
        
        T1 = readtable(filename);
        
        % Convers�o de Tabela para vetor 2D
        A = table2array(T1);
        
        % Pega informa��es somente do canal 4 (total de 8 canais)
        ecoChirp20_temp = A(:,4);
        
        % Salva a linha de eco na tabela
        tabela_eco(:,i) = ecoChirp20_temp;
        
        %ecoChirp20 = ecoChirp20_temp;
        
        %chirp20 = sinal_tapLFMchirp;
        %chirp20 = resposta_imp_225_20us;
        
    elseif (i == 7)
        %ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 1o grupo de espalhadores do phantom');
        
        txt = 'f = 5 MHz';
        pulse_duration = '5 \mus';      % us
        
        transdType = '5 MHz';
        freq_central = '(fc = 5 MHz)';
        grupo = '1o Grupo';
        
        filename = '5MHz-5u-5mm.csv';
        
        inicio_zoom = 10336;
        fim_zoom = inicio_zoom + dif;
        
        %        limite1 = 7450;
        %        limite2 = 7750;
        
        limite1 = 7510;
        limite2 = 7740;
        
        T1 = readtable(filename);
        
        % Convers�o de Tabela para vetor 2D
        A = table2array(T1);
        
        % Pega informa��es somente do canal 4 (total de 8 canais)
        ecoChirp20_temp = A(:,4);
        
        % Salva a linha de eco na tabela
        tabela_eco(:,i) = ecoChirp20_temp;
        
        %ecoChirp20 = ecoChirp20_temp;
        
        %chirp20 = sinal_tapLFMchirp;
        %chirp20 = resposta_imp_5_5us;
        
    elseif (i == 8)
        %ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 2o grupo de espalhadores do phantom');
        
        txt = 'f = 5 MHz';
        pulse_duration = '5 \mus';      % us
        
        transdType = '5 MHz';
        freq_central = '(fc = 5 MHz)';
        grupo = '2o Grupo';
        
        filename = '5MHz-5u-espacamento-dif.csv';
        
        inicio_zoom = 11037;
        fim_zoom = inicio_zoom + dif;
        
        %        limite1 = 7450;
        %        limite2 = 7750;
        
        limite1 = 7510;
        limite2 = 7740;
        
        T1 = readtable(filename);
        
        % Convers�o de Tabela para vetor 2D
        A = table2array(T1);
        
        % Pega informa��es somente do canal 4 (total de 8 canais)
        ecoChirp20_temp = A(:,4);
        
        % Salva a linha de eco na tabela
        tabela_eco(:,i) = ecoChirp20_temp;
        
        %ecoChirp20 = ecoChirp20_temp;
        
        %chirp20 = sinal_tapLFMchirp;
        %chirp20 = resposta_imp_5_5us;
        
    elseif (i == 9)
        %ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 1o grupo de espalhadores do phantom');
        
        txt = 'f = 5 MHz';
        pulse_duration = '10 \mus';      % us
        
        transdType = '5 MHz';
        freq_central = '(fc = 5 MHz)';
        grupo = '1o Grupo';
        
        filename = '5MHz-10u-5mm.csv';
        
        inicio_zoom = 39877;
        fim_zoom = inicio_zoom + dif;
        
        %        limite1 = 7450;
        %        limite2 = 7750;
        limite1 = 7510;
        limite2 = 7900;
        
        
        T1 = readtable(filename);
        
        % Convers�o de Tabela para vetor 2D
        A = table2array(T1);
        
        % Pega informa��es somente do canal 4 (total de 8 canais)
        ecoChirp20_temp = A(:,4);
        
        % Salva a linha de eco na tabela
        tabela_eco(:,i) = ecoChirp20_temp;
        
        %ecoChirp20 = ecoChirp20_temp;
        
        %chirp20 = sinal_tapLFMchirp;
        %chirp20 = resposta_imp_5_10us;
        
    elseif (i == 10)
        %ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 2o grupo de espalhadores do phantom');
        
        txt = 'f = 5 MHz';
        pulse_duration = '10 \mus';      % us
        
        transdType = '5 MHz';
        freq_central = '(fc = 5 MHz)';
        grupo = '2o Grupo';
        
        filename = '5MHz-10u-espacamento-dif.csv';
        
        inicio_zoom = 1295;
        fim_zoom = inicio_zoom + dif;
        
        %       limite1 = 7450;
        %       limite2 = 7750;
        limite1 = 7510;
        limite2 = 7900;
        
        
        T1 = readtable(filename);
        
        % Convers�o de Tabela para vetor 2D
        A = table2array(T1);
        
        % Pega informa��es somente do canal 4 (total de 8 canais)
        ecoChirp20_temp = A(:,4);
        
        % Salva a linha de eco na tabela
        tabela_eco(:,i) = ecoChirp20_temp;
        
        %ecoChirp20 = ecoChirp20_temp;
        
        %chirp20 = sinal_tapLFMchirp;
        %chirp20 = resposta_imp_5_10us;
        
    elseif (i == 11)
        %ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 1o grupo de espalhadores do phantom');
        
        txt = 'f = 5 MHz';
        pulse_duration = '20 \mus';      % us
        
        transdType = '5 MHz';
        freq_central = '(fc = 5 MHz)';
        grupo = '1o Grupo';
        
        filename = '5MHz-20u-5mm.csv';
        
        inicio_zoom = 39430;
        fim_zoom = inicio_zoom + dif;
        
        %       limite1 = 7450;
        %       limite2 = 7750;
        limite1 = 7510;
        limite2 = 8300;
        
        
        T1 = readtable(filename);
        
        % Convers�o de Tabela para vetor 2D
        A = table2array(T1);
        
        % Pega informa��es somente do canal 4 (total de 8 canais)
        ecoChirp20_temp = A(:,4);
        
        % Salva a linha de eco na tabela
        tabela_eco(:,i) = ecoChirp20_temp;
        
        %ecoChirp20 = ecoChirp20_temp;
        
        %chirp20 = sinal_tapLFMchirp;
        %chirp20 = resposta_imp_5_20us;
        
    else
        %ecoChirp20 = sinal_retroespalhado_grupo1;
        disp('Prcessamento do 2o grupo de espalhadores do phantom');
        
        txt = 'f = 5 MHz';
        pulse_duration = '20 \mus';      % us
        
        transdType = '5 MHz';
        freq_central = '(fc = 5 MHz)';
        grupo = '2o Grupo';
        
        filename = '5MHz-20u-espacamento-dif.csv';
        
        inicio_zoom = 7005;
        fim_zoom = inicio_zoom + dif;
        
        %        limite1 = 7450;
        %        limite2 = 7750;
        limite1 = 7510;
        limite2 = 8300;
        
        T1 = readtable(filename);
        
        % Convers�o de Tabela para vetor 2D
        A = table2array(T1);
        
        % Pega informa��es somente do canal 4 (total de 8 canais)
        ecoChirp20_temp = A(:,4);
        
        % Salva a linha de eco na tabela
        tabela_eco(:,i) = ecoChirp20_temp;
        
        %ecoChirp20 = ecoChirp20_temp;
        
        %chirp20 = sinal_tapLFMchirp;
        %chirp20 = resposta_imp_5_20us;
    end;
    
    eco = ecoChirp20_temp;
    [N,M] = size(eco);
    
    escala_n = (1:N)';
    escala_t = escala_n/fs;
    escala_x = escala_t * soundSpeed/2;
    
    eco_norm = eco/max(abs(eco));
    
    % Figura do sinal de eco de RF no tempo
    figure;
    plot(escala_n,eco_norm,'b-');
    titulo = ['Sinal de eco com pulso chirp de ',pulse_duration,' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %    titulo_legenda = ['Sinal de RF (',txt,')'];
    %    legend(titulo_legenda,'Envelope');
    legenda = ['Sinal bruto ',freq_central];
    legend(legenda);
    xlabel('Amostras','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 escala_n(end) -1 1]);
    
    % % Figura do sinal de eco de RF no tempo
    % figure;
    % plot(escala_n,eco_norm,'b-');
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend('Sinal bruto');
    % xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % axis tight;
    
    eco_norm_limite = eco_norm(inicio_zoom:fim_zoom,1);
    [N,M]=size(eco_norm_limite);
    
    escala_n = (1:N)';
    escala_t = escala_n/fs;
    escala_x = escala_t * soundSpeed/2;
    
    % Figura do sinal de eco de RF no tempo
    figure;
    plot(escala_x*10^3,eco_norm_limite,'b-');
    titulo = ['Sinal de eco com pulso chirp de ',pulse_duration,' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Sinal bruto ',freq_central];
    legend(legenda);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    %axis tight;
    axis ([0 160 -1 1]);
    
    
    %% Filtro Passa-Faixa
    
    %HI_PASS Returns a discrete-time filter object.
    
    % MATLAB Code
    % Generated by MATLAB(R) 8.3 and the Signal Processing Toolbox 6.21.
    % Generated on: 23-Nov-2020 17:34:17
    
    % All frequency values are in MHz.
    Fs = 40;  % Sampling Frequency
    
    % Passa-faixa
    Fstop1 = 0.05;             % First Stopband Frequency
    Fpass1 = 1;                % First Passband Frequency
    Fpass2 = 9;                % Second Passband Frequency
    Fstop2 = 9.95;             % Second Stopband Frequency
    Dstop1 = 0.0031622776602;  % First Stopband Attenuation
    Dpass  = 0.057501127785;   % Passband Ripple
    Dstop2 = 0.0031622776602;  % Second Stopband Attenuation
    dens   = 20;               % Density Factor
    
    
    % Passa alta - bom
    % Fstop = 0.5;              % Stopband Frequency
    % Fpass = 1;                % Passband Frequency
    % Dstop = 0.0031622776602;  % Stopband Attenuation
    % Dpass = 0.057501127785;   % Passband Ripple
    % dens  = 20;               % Density Factor
    
    % Calculate the order from the parameters using FIRPMORD.
    [N, Fo, Ao, W] = firpmord([Fstop1 Fpass1 Fpass2 Fstop2]/(Fs/2), [0 1 ...
        0], [Dstop1 Dpass Dstop2]);
    
    filter_order = N;
    
    % Calculate the coefficients using the FIRPM function.
    b  = firpm(N, Fo, Ao, W, {dens});
    Hd = dfilt.dffir(b);
    
    
    % Aplica��o do filtro FIR com Transformada de Hilbert
    q = filter(Hd,eco_norm_limite);
    
    [N,M]=size(q);
    
    escala_dado_n = (1:N)';
    escala_dado_t = escala_dado_n/fs;
    escala_dado_x = escala_dado_t * soundSpeed/2;
    
    % % Figura da sele��o
    % figure;
    % plot(escala_dado_t*10^6,q,'b-','LineWidth',1.5);
    % titulo = ['Resposta impulsiva - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %legend('Sinal de RF','Envelope');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % %axis tight;
    % axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    
    % figure;
    % plot(escala_dado_t*10^6,eco_norm,'b-',escala_dado_t*10^6,q,'r-');
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %legend('Sinal de RF','Envelope');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % legend('Sinal bruto de RF','Sinal filtrado');
    % %axis tight;
    % axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    
    % figure;
    % plot(escala_dado_t*10^6,eco_norm,'b-',escala_dado_t*10^6,q,'r-');
    % titulo = ['Resposta impulsiva - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %legend('Sinal de RF','Envelope');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % legend('Sinal bruto','Sinal filtrado');
    % %axis tight;
    % axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    % pos = ceil(max(size(sinal_tapLFMchirp))/2);
    % a_temp = a(pos:end-pos+1);
    % a = a_temp;
    
    % Retirada das amostras incluidas na convolu��o
    [N,M]=size(q);
    q_shift = zeros(N,M);
    q_shift(1:end-(filter_order/2),1) = q(filter_order/2+1:end,1);
    
    % figure;
    % plot(escala_dado_t*10^6,eco_norm,'b-',escala_dado_t*10^6,q_shift,'r-');
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend('Sinal bruto de RF','Sinal filtrado');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % legend('Sinal bruto','Sinal filtrado');
    % %axis tight;
    % axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    figure;
    plot(escala_dado_x*10^3,q_shift,'b-');
    titulo = ['Sinal de eco com pulso chirp de ',pulse_duration,' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Sinal filtrado ',freq_central];
    legend(legenda);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 160 -1 1]);
    
    hilb = abs(hilbert(q_shift));
    
    % figure;
    % plot(escala_dado_x*10^3,eco_norm_limite,'b-',escala_dado_x*10^3,q_shift,'r-');
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend('Sinal bruto ','Sinal filtrado');
    % xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % %axis tight;
    % axis ([0 escala_dado_x(end)*10^3 -1 1]);
    
    
    figure;
    plot(escala_dado_x*10^3,q_shift,'b-',escala_dado_x*10^3,hilb,'r-');
    titulo = ['Sinal de eco com pulso chirp de ',pulse_duration,' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legenda = ['Sinal filtrado ',freq_central];
    legend(legenda,'Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 160 -1 1]);
    
    %     figure;
    %     plot(escala_dado_x*10^3,q_shift,'b-',escala_dado_x*10^3,hilb,'r-');
    %     titulo = ['Amplia��o do sinal de eco',' - ',grupo];
    %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     legenda = ['Sinal filtrado ',freq_central];
    %     legend(legenda,'Envelope');
    %     xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeYlabel);
    %     %axis tight;
    %     %axis ([20 80 -0.6 0.6]);
    %
    %     tf = strcmp(grupo,'1o Grupo');
    %
    %     if tf == 1
    %         axis ([20 80 -0.6 0.6]);
    %     else
    %         axis ([50 80 -0.8 0.8]);
    %     end;
    
    
    % % Figura do sinal de eco de RF na amostra para sele��o de intervalo
    % figure;
    % plot(escala_n,eco_norm,'b-','LineWidth',1.5);
    % titulo = ['Sinal retroespalhado - Fc = ',transdType,' - 1o Grupo'];
    % title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend('Sinal de RF','Envelope');
    % xlabel('Amostra','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % %axis tight;
    % axis tight;
    % %axis ([0 escala_x(end)*10^3 -1.1 1.1]);
    
    %% Resposta impulsiva
    
    ecoChirp20 = q_shift;
    
    dado1 = eco_norm_limite(limite1:limite2);
    dado1_filtrado = q_shift(limite1:limite2);
    [N,M]=size(dado1);
    
    escala_dado_n = (1:N)';
    escala_dado_t = escala_dado_n/fs;
    escala_dado_x = escala_dado_t * soundSpeed/2;
    
    dado_norm = dado1/max(abs(dado1));
    dado_filtrado_norm = dado1_filtrado/max(abs(dado1_filtrado));
    
    % Salva a resposta impulsiva dos sinais chirp
    [N,M] = size(dado_filtrado_norm);
    
    if (i==1)
        resposta_imp_225_5us_g1 = dado_filtrado_norm;
    elseif (i==2)
        resposta_imp_225_5us_g2= dado_filtrado_norm;
    elseif (i==3)
        resposta_imp_225_10us_g1 = dado_filtrado_norm;
    elseif (i==4)
        resposta_imp_225_10us_g2 = dado_filtrado_norm;
    elseif (i==5)
        resposta_imp_225_20us_g1 = dado_filtrado_norm;
    elseif (i==6)
        resposta_imp_225_20us_g2 = dado_filtrado_norm;
    elseif (i==7)
        resposta_imp_5_5us_g1 = dado_filtrado_norm;
    elseif (i==8)
        resposta_imp_5_5us_g2 = dado_filtrado_norm;
    elseif (i==9)
        resposta_imp_5_10us_g1 = dado_filtrado_norm;
    elseif (i==10)
        resposta_imp_5_10us_g2 = dado_filtrado_norm;
    elseif (i==11)
        resposta_imp_5_20us_g1 = dado_filtrado_norm;
    else
        resposta_imp_5_20us_g2 = dado_filtrado_norm;
    end;
    
    % Figura da sele��o
    figure;
    plot(escala_dado_t*10^6,dado_norm,'b-',escala_dado_t*10^6,dado_filtrado_norm,'r-');
    titulo = ['Resposta impulsiva ',freq_central,' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %    legenda = ['Sinal bruto ',freq_central];
    legend('Sinal bruto','Sinal filtrado');
    xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    %axis tight;
    axis ([0 escala_dado_t(end)*10^6 -1 1]);
    
    
    %-----------------------------------
    %% FFT do pulso ultrass�nico
    %-----------------------------------
    [N,M]=size(dado_norm);
    impulse_response_norm_fft = zeros(256,1);
    impulse_response_norm_fft(1:N,1) = dado_norm;
    
    % N�mero de amostras para a FFT
    NFFT = length(impulse_response_norm_fft);
    N = NFFT;
    
    Y1 = fft(impulse_response_norm_fft);
    
    f=(fs*(0:(N-2)/2)/N)';
    f=f*1e-6;
    
    sinal_fft = abs(Y1(1:(N/4))/N);
    sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
    
    % figure;
    % plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1.5);
    % title('Espectro do pulso ultrass�nico','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % legend(freq_central);
    % grid on;
    % xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeXlabel);
    % ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    %     'FontSize',FontSizeYlabel);
    % axis tight;
    
    
    %-----------------------------------
    %% FFT do pulso ultrass�nico
    %-----------------------------------
    [N,M]=size(dado_filtrado_norm);
    impulse_response_norm_fft = zeros(256,1);
    impulse_response_norm_fft(1:N,1) = dado_filtrado_norm;
    
    % N�mero de amostras para a FFT
    NFFT = length(impulse_response_norm_fft);
    N = NFFT;
    
    Y1 = fft(impulse_response_norm_fft);
    
    f=(fs*(0:(N-2)/2)/N)';
    f=f*1e-6;
    
    sinal_fft = abs(Y1(1:(N/4))/N);
    sinal_fft_1 = 20*log10(sinal_fft/max(sinal_fft));
    
    figure;
    plot(f(1:NFFT/4),sinal_fft_0,'b-');
    hold on;
    plot(f(1:NFFT/4),sinal_fft_1,'r-');
    title(['Espectro do sinal ',freq_central,' - ',grupo],'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend('Sinal bruto','Sinal filtrado');
    grid on;
    xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    axis tight;
    
    pause;
    close all;
    
    %% Processamento dos sinais com os filtros casados e descasado
    
    
    %     %--------------------------------------
    %     % Inverte (flip) do vetor do sinal
    %     %--------------------------------------
    %     tapChirpREAL = fliplr(chirp20')'; % MUDAR INTERVALO... chirp enviado para o transdutor capturado pelo sistema de aquisi��o
    %     [N,M]=size(tapChirpREAL);
    %     escala = (1:1:N)/fs;
    %     escala_x = escala * soundSpeed/2;
    %
    %     figure;
    %     plot(escala*1e6,tapChirpREAL,'b-','LineWidth',1.5);
    %     titulo = ['Filtro casado (match) - Chirp de ',pulse_duration];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     titulo_legenda = ['Invers�o temporal (',txt,')'];
    %     legend(titulo_legenda);
    %     %legend('Invers�o temporal do sinal de chirp com tapering');
    %     %text(3.2,-1.2,txt);
    %     axis([0 escala(end)*10^6 -1.3 1.3]);
    %
    %     figure;
    %     subplot(2,1,1);
    %     plot(escala*1e6,chirp20,'b-','LineWidth',1.5);
    %     titulo = ['Sinal com tapering - Chirp de ',pulse_duration];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     legend(txt);
    %     %text(3.2,-1.2,txt);
    %     axis([0 escala(end)*10^6 -2 2]);
    %
    %     subplot(2,1,2);
    %     plot(escala*1e6,tapChirpREAL,'b-','LineWidth',1.5);
    %     titulo = ['Filtro casado (match) - Chirp de ',pulse_duration];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     legend('Invers�o temporal');
    %     axis([0 escala(end)*10^6 -2 2]);
    %
    %     % Filtro com o mesmo tamanho do vetor com perfil Gaussuiano
    %
    %     wn = usGenWindowFilter_TiagoMMachado(tapChirpREAL, 60,'chebyshev');
    %
    %     wn = wn';
    %     [N,M]=size(wn);
    %     escala = (0:1:N-1)/fs; %frequencia de amostragem de 40MHz na recep��o
    %
    %     figure;
    %     plot(escala*1e6, wn,'b-','LineWidth',1.5);
    %     title('Tapering Chebyshev com l�bulo secund�rio de 60 dB','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     axis tight;
    %
    %     %----------------------------------------------------------
    %     %Sinal flip com aplica��o do filtro com perfil Gaussiano
    %     %Filtro mismatchFilt (descasado)
    %     %----------------------------------------------------------
    %     mismatchFilt = wn.*tapChirpREAL;
    %     [N,M]=size(mismatchFilt);
    %     escala = (1:1:N)/fs;
    %
    %     figure;
    %     plot(escala*1e6,mismatchFilt,'b-','LineWidth',1.5);
    %     titulo = ['Filtro descasado (mismatch) - Chirp de ',pulse_duration];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     titulo_legenda = ['Filtro casado com tap. Chebyshev (',txt,')'];
    %     legend(titulo_legenda);
    %     axis([0 escala(end)*1e6 -1.3 1.3]);
    %     pause;
    %     close all;
    
    %% Aplica��o dos filtro
    
    %----------------------------------------------------------
    %%Sinal flip sem aplica��o do filtro com perfil Gaussiano
    %Filtro matchFilt (casado)
    %Convolu��o do sinal de eco com o filtro matchFilt (casado)
    %----------------------------------------------------------
    
    if (i==1 || i==2)
        matchFilt = matchFilt_225_5us;
        mismatchFilt = mismatchFilt_225_5us;
    elseif (i==3 || i==4)
        matchFilt = matchFilt_225_10us;
        mismatchFilt = mismatchFilt_225_10us;
    elseif (i==5 || i==6)
        matchFilt = matchFilt_225_20us;
        mismatchFilt = mismatchFilt_225_20us;
    elseif (i==7 || i==8)
        matchFilt = matchFilt_5_5us;
        mismatchFilt = mismatchFilt_5_5us;
    elseif (i==9 || i==10)
        matchFilt = matchFilt_5_10us;
        mismatchFilt = mismatchFilt_5_10us;
    else
        matchFilt = matchFilt_5_20us;
        mismatchFilt = mismatchFilt_5_20us;
    end;
    
    mismatchFilt_RF = conv(ecoChirp20, mismatchFilt); % ecoChirp20 � o RAW data capturado
    matchFilt_RF = conv(ecoChirp20, matchFilt);
    
    % Retirada das amostras incluidas na convolu��o
    pos = ceil(max(size(mismatchFilt))/2);
    mismatchFilt_RF_temp = mismatchFilt_RF(pos:end-pos+1);
    mismatchFilt_RF = mismatchFilt_RF_temp;
    
    matchFilt_RF_temp = matchFilt_RF(pos:end-pos+1);
    matchFilt_RF = matchFilt_RF_temp;
    
    %mismatchFilt_RF = mismatchFilt_RF/max(abs(mismatchFilt_RF));
    %matchFilt_RF = matchFilt_RF/max(abs(matchFilt_RF));
    
    % Aplica��o do filtro casado
    [N,M]=size(matchFilt_RF);
    escala = (1:1:N)/fs;
    escala_x = escala * soundSpeed/2;
    
    %     figure;
    %     plot(escala*1e3,matchFilt_RF,'b-','LineWidth',0.8);
    %     hold on;
    %     plot(escala*1e3,abs(hilbert(matchFilt_RF)),'r-','LineWidth',0.8);
    %     titulo_legenda = ['Sinal filtrado (',txt,')'];
    %     legend(titulo_legenda,'Envelope');
    %     %legend('Sinal de RF','Envelope');
    %     titulo = ['Aplica��o do filtro casado no sinal de RF - ',grupo];
    %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     axis([0 escala(end)*1e3 -1 1 ]) ;
    
    figure;
    plot(escala_x*1e3,matchFilt_RF,'b-','LineWidth',0.8);
    hold on;
    plot(escala_x*1e3,abs(hilbert(matchFilt_RF)),'r-','LineWidth',0.8);
    titulo_legenda = ['Sinal filtrado (',txt,')'];
    legend(titulo_legenda,'Envelope');
    %legend('Sinal de RF','Envelope');
    titulo = ['Aplica��o do filtro casado no sinal de RF - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    axis tight;
    
    % Versao 2
    figure;
    plot(escala_x*1e3,abs(hilbert(matchFilt_RF)),'r-','LineWidth',0.8);
    titulo_legenda = ['Envelope do sinal filtrado (',txt,')'];
    legend(titulo_legenda);
    titulo = ['Aplica��o do filtro casado no sinal de RF - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    axis tight;
    
    v1 = min(matchFilt_RF(1000:7000,1));
    v2 = max(matchFilt_RF(1000:7000,1));
    
    figure;
    plot(escala_x*1e3,matchFilt_RF,'b-','LineWidth',0.8);
    hold on;
    plot(escala_x*1e3,abs(hilbert(matchFilt_RF)),'r-','LineWidth',0.8);
    titulo_legenda = ['Sinal filtrado (',txt,')'];
    legend(titulo_legenda,'Envelope');
    %legend('Sinal de RF','Envelope');
    titulo = ['Amplia��o do sinal com filtro casado - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    
    if (strcmp(grupo,'1o Grupo'))
        axis ([20 85 v1 v2]);
    else
        axis ([50 85 v1 v2]);
    end;
       
    % Versao 2
    figure;
    plot(escala_x*1e3,abs(hilbert(matchFilt_RF)),'r-','LineWidth',0.8);
    titulo_legenda = ['Envelope do sinal filtrado (',txt,')'];
    legend(titulo_legenda);
    titulo = ['Amplia��o do sinal com filtro casado - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    
    if (strcmp(grupo,'1o Grupo'))
        axis ([20 85 0 v2]);
    else
        axis ([50 85 0 v2]);
    end;
          
    
    
    % Aplica��o do filtro descasado
    [N,M]=size(mismatchFilt_RF);
    escala = (0:1:N-1)/fs;
    escala_x = escala * soundSpeed/2;
    
    figure;
    plot(escala_x*1e3,mismatchFilt_RF,'b-','LineWidth',0.8);
    hold on;
    plot(escala_x*1e3,abs(hilbert(mismatchFilt_RF)),'r-','LineWidth',0.8);
    titulo_legenda = ['Sinal filtrado (',txt,')'];
    legend(titulo_legenda,'Envelope');
    titulo = ['Aplica��o do filtro descasado no sinal de RF - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
   % axis([0 escala_x(end)*1e3 -1 1 ]) ;
   axis tight;
  
   % Versao 2
    figure;
    plot(escala_x*1e3,abs(hilbert(mismatchFilt_RF)),'r-','LineWidth',0.8);
    titulo_legenda = ['Envelope do sinal filtrado (',txt,')'];
    legend(titulo_legenda);
    titulo = ['Aplica��o do filtro descasado no sinal de RF - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
   % axis([0 escala_x(end)*1e3 -1 1 ]) ;
   axis tight;
     
    v1 = min(mismatchFilt_RF(1000:7000,1));
    v2 = max(mismatchFilt_RF(1000:7000,1));
   
    figure;
    plot(escala_x*1e3,mismatchFilt_RF,'b-','LineWidth',0.8);
    hold on;
    plot(escala_x*1e3,abs(hilbert(mismatchFilt_RF)),'r-','LineWidth',0.8);
    titulo_legenda = ['Sinal filtrado (',txt,')'];
    legend(titulo_legenda,'Envelope');
    titulo = ['Amplia��o do sinal com filtro descasado - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    
   if (strcmp(grupo,'1o Grupo'))
        axis ([20 85 v1 v2]);
    else
        axis ([50 85 v1 v2]);
    end;
  
    % Vers�o 2
    figure;
    plot(escala_x*1e3,abs(hilbert(mismatchFilt_RF)),'r-','LineWidth',0.8);
    titulo_legenda = ['Envelope do sinal filtrado (',txt,')'];
    legend(titulo_legenda);
    titulo = ['Amplia��o do sinal com filtro descasado - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    
   if (strcmp(grupo,'1o Grupo'))
        axis ([20 85 0 v2]);
    else
        axis ([50 85 0 v2]);
    end;    
    
    
    %% Comparacao final
    
    [N,M]=size(ecoChirp20);
    escala = (1:1:N)/fs;
    escala_x = escala * soundSpeed/2;
    
    a = ecoChirp20./max(abs(ecoChirp20));
    b = matchFilt_RF;
    c = mismatchFilt_RF;
    
    [X,Y]=size(b);
    escala_conv = (1:1:X)/fs;
    escala_conv_x = escala_conv * soundSpeed/2;
    
    %-----------------------------
    % 1) Sinal casado
    %-----------------------------
    
    % Escala de tempo
%     figure;
%     subplot(2,1,1);
%     plot(escala*1e3,a,'b-','LineWidth',0.8);
%     hold on;
%     plot(escala*1e3,abs(hilbert(a)),'r-','LineWidth',0.8);
%     titulo = ['Sinal retroespalhado - Chirp de ',pulse_duration,' - ',grupo];
%     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     titulo_legenda = ['Sinal de RF (',txt,')'];
%     legend(titulo_legenda,'Envelope');
%     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     axis([0 escala(end)*1e3 -1 1]) ;
%     
%     subplot(2,1,2);
%     plot(escala_conv*1e3,b,'b-','LineWidth',0.8);
%     titulo = ['Aplica��o do filtro casado - ',grupo];
%     title(titulo,'FontName',FontName,...
%         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     hold on;
%     plot(escala_conv*1e3,abs(hilbert(b)),'r-','LineWidth',0.8);
%     legend('Sinal filtrado','Envelope');
%     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     axis([0 escala_conv(end)*1e3 -1 1]) ;
%     %axis([0 escala(end)*1e3 -1 1]) ;
     
      % Escala de profundidade
    figure;
    subplot(2,1,1);
    plot(escala_x*1e3,a,'b-','LineWidth',0.8);
    hold on;
    plot(escala_x*1e3,abs(hilbert(a)),'r-','LineWidth',0.8);
    titulo = ['Sinal retroespalhado - Chirp de ',pulse_duration,' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    titulo_legenda = ['Sinal de RF (',txt,')'];
    legend(titulo_legenda,'Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    %axis([0 escala_x(end)*1e3 -1 1]) ;
    axis tight;
    
    subplot(2,1,2);
    plot(escala_conv_x*1e3,b,'b-','LineWidth',0.8);
    titulo = ['Aplica��o do filtro casado - ',grupo];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    hold on;
    plot(escala_conv_x*1e3,abs(hilbert(b)),'r-','LineWidth',0.8);
    legend('Sinal filtrado','Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    %axis([0 escala_conv_x(end)*1e3 -1 1]) ;
    %axis([0 escala_x(end)*1e3 -1 1]) ;
    axis tight;
  
    % Ampliacao da escala de profundidade
    
    v1 = min(a(1000:7000,1));
    v2 = max(a(1000:7000,1));
    
    figure;
    subplot(2,1,1);
    plot(escala_x*1e3,a,'b-','LineWidth',0.8);
    hold on;
    plot(escala_x*1e3,abs(hilbert(a)),'r-','LineWidth',0.8);
    titulo = ['Amplia��o do eco - Chirp de ',pulse_duration,' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    titulo_legenda = ['Sinal de RF (',txt,')'];
    legend(titulo_legenda,'Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    
    if (strcmp(grupo,'1o Grupo'))
        axis ([20 85 v1 v2]);
    else
        axis ([50 85 v1 v2]);
    end;
    
    v1 = min(b(1000:7000,1));
    v2 = max(b(1000:7000,1));
    
    subplot(2,1,2);
    plot(escala_conv_x*1e3,b,'b-','LineWidth',0.8);
    hold on;
    plot(escala_conv_x*1e3,abs(hilbert(b)),'r-','LineWidth',0.8);
    titulo = ['Amplia��o do eco com filtro casado - ',grupo];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend('Sinal filtrado','Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
   
  if (strcmp(grupo,'1o Grupo'))
        axis ([20 85 v1 v2]);
    else
        axis ([50 85 v1 v2]);
    end;
     
   
    %-----------------------------
    % 2) Sinal descasado
    %-----------------------------
    
    % Escala de tempo
%     figure;
%     subplot(2,1,1);
%     plot(escala*1e3,a,'b-','LineWidth',0.8);
%     hold on;
%     plot(escala*1e3,abs(hilbert(a)),'r-','LineWidth',0.8);
%     titulo = ['Sinal retroespalhado - Chirp de ',pulse_duration,' - ',tg];
%     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     titulo_legenda = ['Sinal de RF (',txt,')'];
%     legend(titulo_legenda,'Envelope');
%     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     axis([0 escala(end)*1e3 -1 1]) ;
%     
%     subplot(2,1,2);
%     plot(escala_conv*1e3,c,'b-','LineWidth',0.8);
%     titulo = ['Aplica��o do filtro descasado - ',tg];
%     title(titulo,'FontName',FontName,...
%         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     hold on;
%     plot(escala_conv*1e3,abs(hilbert(c)),'r-','LineWidth',0.8);
%     legend('Sinal filtrado','Envelope');
%     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     %axis([0 escala_conv(end)*1e3 -1 1]) ;
%     axis([0 escala_conv(end)*1e3 -1 1]) ;
    
    % Escala de profundidade
    figure;
    subplot(2,1,1);
    plot(escala_x*1e3,a,'b-','LineWidth',0.8);
    hold on;
    plot(escala_x*1e3,abs(hilbert(a)),'r-','LineWidth',0.8);
    titulo = ['Sinal retroespalhado - Chirp de ',pulse_duration,' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    titulo_legenda = ['Sinal de RF (',txt,')'];
    legend(titulo_legenda,'Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    %axis([0 escala_x(end)*1e3 -1 1]) ;
    axis tight
    
    subplot(2,1,2);
    plot(escala_conv_x*1e3,c,'b-','LineWidth',0.8);
    titulo = ['Aplica��o do filtro descasado - ',grupo];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    hold on;
    plot(escala_conv_x*1e3,abs(hilbert(c)),'r-','LineWidth',0.8);
    legend('Sinal filtrado','Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    %axis([0 escala_conv_x(end)*1e3 -1 1]) ;
    %axis([0 escala_x(end)*1e3 -1 1]) ;
    axis tight;
    
     % Amplia�ao da scala de profundidade
    
    v1 = min(a(1000:7000,1));
    v2 = max(a(1000:7000,1));
     
     
    figure;
    subplot(2,1,1);
    plot(escala_x*1e3,a,'b-','LineWidth',0.8);
    hold on;
    plot(escala_x*1e3,abs(hilbert(a)),'r-','LineWidth',0.8);
    titulo = ['Amplia��o do eco - Chirp de ',pulse_duration,' - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    titulo_legenda = ['Sinal de RF (',txt,')'];
    legend(titulo_legenda,'Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
   
    if (strcmp(grupo,'1o Grupo'))
        axis ([20 85 v1 v2]);
    else
        axis ([50 85 v1 v2]);
    end;

        
    v1 = min(c(1000:7000,1));
    v2 = max(c(1000:7000,1));
    
    subplot(2,1,2);
    plot(escala_conv_x*1e3,c,'b-','LineWidth',0.8);
    hold on;
    plot(escala_conv_x*1e3,abs(hilbert(c)),'r-','LineWidth',0.8);
    titulo = ['Amplia��o do eco com filtro descasado - ',grupo];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend('Sinal filtrado','Envelope');
    xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
   if (strcmp(grupo,'1o Grupo'))
        axis ([20 85 v1 v2]);
    else
        axis ([50 85 v1 v2]);
    end;

   
   
    %% FFT do sinal com sinal de eco bruto

    [N,M]=size(a);
    
    phantom_fft = zeros(2^12,1);
    phantom_fft(1:N,1) = a;
    
    % N�mero de amostras para a FFT
    NFFT = length(phantom_fft);
    N = NFFT;
    
    Y1 = fft(phantom_fft);
    
    f=(fs*(0:(N-2)/2)/N)';
    f=f*1e-6;
    
    sinal_fft = abs(Y1(1:(N/4))/N);
    sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
    
    figure;
    %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
    plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
    titulo = ['Espectro do sinal bruto de RF - ',grupo];
    title(titulo,'FontName',FontName,...
        'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend(txt);
    grid on;
    xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    axis tight;
        
    %-----------------------------------
    % FFT do sinal com sinal de com filtro casado
    %-----------------------------------
    [N,M]=size(b);
    
    phantom_fft = zeros(2^12,1);
    phantom_fft(1:N,1) = b;
    
    % N�mero de amostras para a FFT
    NFFT = length(phantom_fft);
    N = NFFT;
    
    Y1 = fft(phantom_fft);
    
    f=(fs*(0:(N-2)/2)/N)';
    f=f*1e-6;
    
    sinal_fft = abs(Y1(1:(N/4))/N);
    sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
    
    figure;
    %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
    plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
    titulo = ['Espectro do sinal com filtro casado - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend(txt);
    grid on;
    xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    axis tight;
    
    %-----------------------------------
    % FFT do sinal com sinal de com filtro descasado
    %-----------------------------------
    [N,M]=size(c);
    
    phantom_fft = zeros(2^12,1);
    phantom_fft(1:N,1) = c;
    
    % N�mero de amostras para a FFT
    NFFT = length(phantom_fft);
    N = NFFT;
    
    Y1 = fft(phantom_fft);
    
    f=(fs*(0:(N-2)/2)/N)';
    f=f*1e-6;
    
    sinal_fft = abs(Y1(1:(N/4))/N);
    sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
    
    figure;
    %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
    plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
    titulo = ['Espectro do sinal com filtro descasado - ',grupo];
    title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    legend(txt);
    grid on;
    xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeXlabel);
    ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
        'FontSize',FontSizeYlabel);
    axis tight;
    
    pause;
    close all;   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    %
    %
    %
    %     %--------------------------------------
    %     % Inverte (flip) do vetor do sinal
    %     %--------------------------------------
    %     tapChirpREAL = fliplr(chirp20')'; % MUDAR INTERVALO... chirp enviado para o transdutor capturado pelo sistema de aquisi��o
    %     [N,M]=size(tapChirpREAL);
    %     escala = (1:1:N)/fs;
    %     escala_x = escala * soundSpeed/2;
    %
    %     figure;
    %     plot(escala*1e6,tapChirpREAL,'b-','LineWidth',1.5);
    %     titulo = ['Filtro casado (match) - Chirp de ',pulse_duration];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     titulo_legenda = ['Invers�o temporal (',txt,')'];
    %     legend(titulo_legenda);
    %     %legend('Invers�o temporal do sinal de chirp com tapering');
    %     %text(3.2,-1.2,txt);
    %     axis([0 escala(end)*10^6 -1.3 1.3]);
    %
    %     figure;
    %     subplot(2,1,1);
    %     plot(escala*1e6,chirp20,'b-','LineWidth',1.5);
    %     titulo = ['Sinal com tapering - Chirp de ',pulse_duration];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     legend(txt);
    %     %text(3.2,-1.2,txt);
    %     axis([0 escala(end)*10^6 -2 2]);
    %
    %     subplot(2,1,2);
    %     plot(escala*1e6,tapChirpREAL,'b-','LineWidth',1.5);
    %     titulo = ['Filtro casado (match) - Chirp de ',pulse_duration];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     legend('Invers�o temporal');
    %     axis([0 escala(end)*10^6 -2 2]);
    %
    %     % Filtro com o mesmo tamanho do vetor com perfil Gaussuiano
    %
    %     wn = usGenWindowFilter_TiagoMMachado(tapChirpREAL, 60,'chebyshev');
    %
    %     wn = wn';
    %     [N,M]=size(wn);
    %     escala = (0:1:N-1)/fs; %frequencia de amostragem de 40MHz na recep��o
    %
    %     figure;
    %     plot(escala*1e6, wn,'b-','LineWidth',1.5);
    %     title('Tapering Chebyshev com l�bulo secund�rio de 60 dB','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     axis tight;
    %
    %     %----------------------------------------------------------
    %     %Sinal flip com aplica��o do filtro com perfil Gaussiano
    %     %Filtro mismatchFilt (descasado)
    %     %----------------------------------------------------------
    %     mismatchFilt = wn.*tapChirpREAL;
    %     [N,M]=size(mismatchFilt);
    %     escala = (1:1:N)/fs;
    %
    %     figure;
    %     plot(escala*1e6,mismatchFilt,'b-','LineWidth',1.5);
    %     titulo = ['Filtro descasado (mismatch) - Chirp de ',pulse_duration];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     titulo_legenda = ['Filtro casado com tap. Chebyshev (',txt,')'];
    %     legend(titulo_legenda);
    %     axis([0 escala(end)*1e6 -1.3 1.3]);
    %     pause;
    %     close all;
    %
    %     %% Aplica��o dos filtro
    %
    %     %----------------------------------------------------------
    %     %%Sinal flip sem aplica��o do filtro com perfil Gaussiano
    %     %Filtro matchFilt (casado)
    %     %Convolu��o do sinal de eco com o filtro matchFilt (casado)
    %     %----------------------------------------------------------
    %
    %     matchFilt = tapChirpREAL;
    %     mismatchFilt_RF = conv(ecoChirp20, mismatchFilt); % ecoChirp20 � o RAW data capturado
    %     matchFilt_RF = conv(ecoChirp20, matchFilt);
    %
    %     % Retirada das amostras incluidas na convolu��o
    %     pos = ceil(max(size(mismatchFilt))/2);
    %     mismatchFilt_RF_temp = mismatchFilt_RF(pos:end-pos+1);
    %     mismatchFilt_RF = mismatchFilt_RF_temp;
    %
    %     matchFilt_RF_temp = matchFilt_RF(pos:end-pos+1);
    %     matchFilt_RF = matchFilt_RF_temp;
    %
    %     mismatchFilt_RF = mismatchFilt_RF/max(abs(mismatchFilt_RF));
    %     matchFilt_RF = matchFilt_RF/max(abs(matchFilt_RF));
    %
    %     % Aplica��o do filtro casado
    %     [N,M]=size(matchFilt_RF);
    %     escala = (1:1:N)/fs;
    %     escala_x = escala * soundSpeed/2;
    %
    % %     figure;
    % %     plot(escala*1e3,matchFilt_RF,'b-','LineWidth',0.8);
    % %     hold on;
    % %     plot(escala*1e3,abs(hilbert(matchFilt_RF)),'r-','LineWidth',0.8);
    % %     titulo_legenda = ['Sinal filtrado (',txt,')'];
    % %     legend(titulo_legenda,'Envelope');
    % %     %legend('Sinal de RF','Envelope');
    % %     titulo = ['Aplica��o do filtro casado no sinal de RF - ',tg];
    % %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    % %         'FontSize',FontSizeXlabel);
    % %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    % %         'FontSize',FontSizeXlabel);
    % %     axis([0 escala(end)*1e3 -1 1 ]) ;
    %
    %     figure;
    %     plot(escala_x*1e3,matchFilt_RF,'b-','LineWidth',0.8);
    %     hold on;
    %     plot(escala_x*1e3,abs(hilbert(matchFilt_RF)),'r-','LineWidth',0.8);
    %     titulo_legenda = ['Sinal filtrado (',txt,')'];
    %     legend(titulo_legenda,'Envelope');
    %     %legend('Sinal de RF','Envelope');
    %     titulo = ['Aplica��o do filtro casado no sinal de RF - ',tg];
    %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     axis([0 escala_x(end)*1e3 -1 1 ]) ;
    %
    %     % Aplica��o do filtro descasado
    %     [N,M]=size(mismatchFilt_RF);
    %     escala = (0:1:N-1)/fs;
    %     escala_x = escala * soundSpeed/2;
    %
    % %     figure;
    % %     plot(escala*1e3,mismatchFilt_RF,'b-','LineWidth',0.8);
    % %     hold on;
    % %     plot(escala*1e3,abs(hilbert(mismatchFilt_RF)),'r-','LineWidth',0.8);
    % %     titulo_legenda = ['Sinal filtrado (',txt,')'];
    % %     legend(titulo_legenda,'Envelope');
    % %     titulo = ['Aplica��o do filtro descasado no sinal de RF - ',tg];
    % %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    % %         'FontSize',FontSizeXlabel);
    % %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    % %         'FontSize',FontSizeXlabel);
    % %     axis([0 escala(end)*1e3 -1 1 ]) ;
    %
    %     figure;
    %     plot(escala_x*1e3,mismatchFilt_RF,'b-','LineWidth',0.8);
    %     hold on;
    %     plot(escala_x*1e3,abs(hilbert(mismatchFilt_RF)),'r-','LineWidth',0.8);
    %     titulo_legenda = ['Sinal filtrado (',txt,')'];
    %     legend(titulo_legenda,'Envelope');
    %     titulo = ['Aplica��o do filtro descasado no sinal de RF - ',tg];
    %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     axis([0 escala_x(end)*1e3 -1 1 ]) ;
    %
    %     pause;
    %     close;
    %
    %     %% Comparacao final
    %
    %     [N,M]=size(ecoChirp20);
    %     escala = (1:1:N)/fs;
    %     escala_x = escala * soundSpeed/2;
    %
    %     a = ecoChirp20./max(abs(ecoChirp20));
    %     b = matchFilt_RF;
    %     c = mismatchFilt_RF;
    %
    %     [X,Y]=size(b);
    %     escala_conv = (1:1:X)/fs;
    %     escala_conv_x = escala_conv * soundSpeed/2;
    %
    %     %-----------------------------
    %     % 1) Sinal casado
    %     %-----------------------------
    %
    %     % Escala de tempo
    % %     figure;
    % %     subplot(2,1,1);
    % %     plot(escala*1e3,a,'b-','LineWidth',0.8);
    % %     hold on;
    % %     plot(escala*1e3,abs(hilbert(a)),'r-','LineWidth',0.8);
    % %     titulo = ['Sinal retroespalhado - Chirp de ',pulse_duration,' - ',tg];
    % %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %     titulo_legenda = ['Sinal de RF (',txt,')'];
    % %     legend(titulo_legenda,'Envelope');
    % %     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    % %         'FontSize',FontSizeXlabel);
    % %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    % %         'FontSize',FontSizeXlabel);
    % %     axis([0 escala(end)*1e3 -1 1]) ;
    % %
    % %     subplot(2,1,2);
    % %     plot(escala_conv*1e3,b,'b-','LineWidth',0.8);
    % %     titulo = ['Aplica��o do filtro casado - ',tg];
    % %     title(titulo,'FontName',FontName,...
    % %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %     hold on;
    % %     plot(escala_conv*1e3,abs(hilbert(b)),'r-','LineWidth',0.8);
    % %     legend('Sinal filtrado','Envelope');
    % %     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    % %         'FontSize',FontSizeXlabel);
    % %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    % %         'FontSize',FontSizeXlabel);
    % %     axis([0 escala_conv(end)*1e3 -1 1]) ;
    % %     %axis([0 escala(end)*1e3 -1 1]) ;
    %
    %       % Escala de profundidade
    %     figure;
    %     subplot(2,1,1);
    %     plot(escala_x*1e3,a,'b-','LineWidth',0.8);
    %     hold on;
    %     plot(escala_x*1e3,abs(hilbert(a)),'r-','LineWidth',0.8);
    %     titulo = ['Sinal retroespalhado - Chirp de ',pulse_duration,' - ',tg];
    %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     titulo_legenda = ['Sinal de RF (',txt,')'];
    %     legend(titulo_legenda,'Envelope');
    %     xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     axis([0 escala_x(end)*1e3 -1 1]) ;
    %
    %     subplot(2,1,2);
    %     plot(escala_conv_x*1e3,b,'b-','LineWidth',0.8);
    %     titulo = ['Aplica��o do filtro casado - ',tg];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     hold on;
    %     plot(escala_conv_x*1e3,abs(hilbert(b)),'r-','LineWidth',0.8);
    %     legend('Sinal filtrado','Envelope');
    %     xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     axis([0 escala_conv_x(end)*1e3 -1 1]) ;
    %     %axis([0 escala_x(end)*1e3 -1 1]) ;
    %
    %     % Ampliacao da escala de profundidade
    %     figure;
    %     subplot(2,1,1);
    %     plot(escala_x*1e3,a,'b-','LineWidth',0.8);
    %     hold on;
    %     plot(escala_x*1e3,abs(hilbert(a)),'r-','LineWidth',0.8);
    %     titulo = ['Amplia��o do eco - Chirp de ',pulse_duration,' - ',tg];
    %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     titulo_legenda = ['Sinal de RF (',txt,')'];
    %     legend(titulo_legenda,'Envelope');
    %     xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     if grupo_phantom == 1
    %         axis([10 80 -2 2]) ;
    %     else
    %         axis([55 80 -2 2]) ;
    %     end;
    %
    %     subplot(2,1,2);
    %     plot(escala_conv_x*1e3,b,'b-','LineWidth',0.8);
    %     hold on;
    %     plot(escala_conv_x*1e3,abs(hilbert(b)),'r-','LineWidth',0.8);
    %     titulo = ['Amplia��o do eco com filtro casado - ',tg];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     legend('Sinal filtrado','Envelope');
    %     xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     if grupo_phantom == 1
    %         axis([10 80 -2 2]) ;
    %     else
    %         axis([55 80 -2 2]) ;
    %     end;
    %
    %
    %     %-----------------------------
    %     % 2) Sinal descasado
    %     %-----------------------------
    %
    %     % Escala de tempo
    % %     figure;
    % %     subplot(2,1,1);
    % %     plot(escala*1e3,a,'b-','LineWidth',0.8);
    % %     hold on;
    % %     plot(escala*1e3,abs(hilbert(a)),'r-','LineWidth',0.8);
    % %     titulo = ['Sinal retroespalhado - Chirp de ',pulse_duration,' - ',tg];
    % %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %     titulo_legenda = ['Sinal de RF (',txt,')'];
    % %     legend(titulo_legenda,'Envelope');
    % %     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    % %         'FontSize',FontSizeXlabel);
    % %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    % %         'FontSize',FontSizeXlabel);
    % %     axis([0 escala(end)*1e3 -1 1]) ;
    % %
    % %     subplot(2,1,2);
    % %     plot(escala_conv*1e3,c,'b-','LineWidth',0.8);
    % %     titulo = ['Aplica��o do filtro descasado - ',tg];
    % %     title(titulo,'FontName',FontName,...
    % %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    % %     hold on;
    % %     plot(escala_conv*1e3,abs(hilbert(c)),'r-','LineWidth',0.8);
    % %     legend('Sinal filtrado','Envelope');
    % %     xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
    % %         'FontSize',FontSizeXlabel);
    % %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    % %         'FontSize',FontSizeXlabel);
    % %     %axis([0 escala_conv(end)*1e3 -1 1]) ;
    % %     axis([0 escala_conv(end)*1e3 -1 1]) ;
    %
    %     % Escala de profundidade
    %     figure;
    %     subplot(2,1,1);
    %     plot(escala_x*1e3,a,'b-','LineWidth',0.8);
    %     hold on;
    %     plot(escala_x*1e3,abs(hilbert(a)),'r-','LineWidth',0.8);
    %     titulo = ['Sinal retroespalhado - Chirp de ',pulse_duration,' - ',tg];
    %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     titulo_legenda = ['Sinal de RF (',txt,')'];
    %     legend(titulo_legenda,'Envelope');
    %     xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     axis([0 escala_x(end)*1e3 -1 1]) ;
    %
    %     subplot(2,1,2);
    %     plot(escala_conv_x*1e3,c,'b-','LineWidth',0.8);
    %     titulo = ['Aplica��o do filtro descasado - ',tg];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     hold on;
    %     plot(escala_conv_x*1e3,abs(hilbert(c)),'r-','LineWidth',0.8);
    %     legend('Sinal filtrado','Envelope');
    %     xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     axis([0 escala_conv_x(end)*1e3 -1 1]) ;
    %     %axis([0 escala_x(end)*1e3 -1 1]) ;
    %
    %      % Amplia�ao da scala de profundidade
    %     figure;
    %     subplot(2,1,1);
    %     plot(escala_x*1e3,a,'b-','LineWidth',0.8);
    %     hold on;
    %     plot(escala_x*1e3,abs(hilbert(a)),'r-','LineWidth',0.8);
    %     titulo = ['Amplia��o do eco - Chirp de ',pulse_duration,' - ',tg];
    %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     titulo_legenda = ['Sinal de RF (',txt,')'];
    %     legend(titulo_legenda,'Envelope');
    %     xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     if grupo_phantom == 1
    %         axis([10 80 -2 2]) ;
    %     else
    %         axis([55 80 -2 2]) ;
    %     end;
    %
    %     subplot(2,1,2);
    %     plot(escala_conv_x*1e3,c,'b-','LineWidth',0.8);
    %     hold on;
    %     plot(escala_conv_x*1e3,abs(hilbert(c)),'r-','LineWidth',0.8);
    %     titulo = ['Amplia��o do eco com filtro descasado - ',tg];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     legend('Sinal filtrado','Envelope');
    %     xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Amplitude (u.a)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     if grupo_phantom == 1
    %         axis([10 80 -2 2]) ;
    %     else
    %         axis([55 80 -2 2]) ;
    %     end;
    %
    %
    %     %% FFT do sinal com sinal de eco bruto
    %
    %     [N,M]=size(a);
    %
    %     phantom_fft = zeros(2^12,1);
    %     phantom_fft(1:N,1) = a;
    %
    %     % N�mero de amostras para a FFT
    %     NFFT = length(phantom_fft);
    %     N = NFFT;
    %
    %     Y1 = fft(phantom_fft);
    %
    %     f=(fs*(0:(N-2)/2)/N)';
    %     f=f*1e-6;
    %
    %     sinal_fft = abs(Y1(1:(N/4))/N);
    %     sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
    %
    %     figure;
    %     %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
    %     plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
    %     titulo = ['Espectro do sinal bruto de RF - ',tg];
    %     title(titulo,'FontName',FontName,...
    %         'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     legend(txt);
    %     grid on;
    %     xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeYlabel);
    %     axis tight;
    %
    %     %-----------------------------------
    %     % FFT do sinal com sinal de com filtro casado
    %     %-----------------------------------
    %     [N,M]=size(b);
    %
    %     phantom_fft = zeros(2^12,1);
    %     phantom_fft(1:N,1) = b;
    %
    %     % N�mero de amostras para a FFT
    %     NFFT = length(phantom_fft);
    %     N = NFFT;
    %
    %     Y1 = fft(phantom_fft);
    %
    %     f=(fs*(0:(N-2)/2)/N)';
    %     f=f*1e-6;
    %
    %     sinal_fft = abs(Y1(1:(N/4))/N);
    %     sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
    %
    %     figure;
    %     %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
    %     plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
    %     titulo = ['Espectro do sinal com filtro casado - ',tg];
    %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     legend(txt);
    %     grid on;
    %     xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeYlabel);
    %     axis tight;
    %
    %     %-----------------------------------
    %     % FFT do sinal com sinal de com filtro descasado
    %     %-----------------------------------
    %     [N,M]=size(c);
    %
    %     phantom_fft = zeros(2^12,1);
    %     phantom_fft(1:N,1) = c;
    %
    %     % N�mero de amostras para a FFT
    %     NFFT = length(phantom_fft);
    %     N = NFFT;
    %
    %     Y1 = fft(phantom_fft);
    %
    %     f=(fs*(0:(N-2)/2)/N)';
    %     f=f*1e-6;
    %
    %     sinal_fft = abs(Y1(1:(N/4))/N);
    %     sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
    %
    %     figure;
    %     %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
    %     plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
    %     titulo = ['Espectro do sinal com filtro descasado - ',tg];
    %     title(titulo,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
    %     legend(txt);
    %     grid on;
    %     xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeXlabel);
    %     ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
    %         'FontSize',FontSizeYlabel);
    %     axis tight;
    %
    pause;
    close all;
    
end;


% Janela para compara��o da redu��o do l�bulo secund�rio com o filtro
% retangular

%wvtool(rectwin(comprimento_filtro));
%disp('An�lise do l�bilo secund�rio com janela retangular');

% Janela para compara��o da redu��o do l�bulo secund�rio com o filtro
% Chebyshev

%wvtool(wn);
%disp('An�lise do l�bilo secund�rio com janela Chebyshev');

















%
% %% Phantom 1D - conjunto de espalhadores para a analise com o chirp
%
% espacamento = 3*lambda;
%
% tamanho = 2048;
% phantom3 = zeros(tamanho,1);
% % snr = 7.5;               %db
% % out = awgn(in,snr);
%
% %n = 100;
% n = 10;
% r = rand(n,1);
%
% passo = round(tamanho/n);
%
% for i=1:1:n-1
%     phantom3(passo*i,1)=r(i,1);
% end;
%
% [N,M]=size(phantom3)
% escala_t = (0:1:N-1)/fs;
% escala_x = escala_t * soundSpeed/2;
%
% figure;
% plot(escala_t*10^6,phantom3,'b-','LineWidth',1);
% title('Espalhadores ac�sticos equivalentes - Phantom 3','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% %legend('Sinal de RF','Envelope');
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
%
% figure;
% plot(escala_x*10^3,phantom3,'b-','LineWidth',1);
% title('Espalhadores ac�sticos equivalentes','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% %legend('Sinal de RF','Envelope');
% xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
%
%
% %% SELE�AO DO SINAL DE ECO CHIRP20
%
% %%Convolu��o dos sinais retroespalhados
%
% %--------------------------------------------------------
% % A sele��o do sinal de eco � realizada no inicio do c�digo
% %--------------------------------------------------------
%
% pd = strcmp(pulse_duration,'5us');
% if pd == 1
%     chirp20 = dado1;                % sinal de eco com excita��o chirp de 5 us
%     disp('Eco com excita��o chirp de 5 us ');
% else
%     pd = strcmp(pulse_duration,'10us');
%     if pd == 1
%         chirp20 = dado2;            % sinal de eco com excita��o chirp de 10 us
%         disp('Eco com excita��o chirp de 10 us ');
%     else
%         chirp20 = dado3;            % sinal de eco com excita��o chirp de 20 us
%         disp('Eco com excita��o chirp de 20 us ');
%     end;
% end;
%
%
% ecoChirp20 = conv(chirp20,phantom3);
% [N,M]=size(ecoChirp20);
%
% escala_n = 0:1:N-1;
% escala_t = escala_n/fs;
% escala_t = escala_t';
% escala_x = escala_t * soundSpeed/2;
%
% b=abs(hilbert(ecoChirp20))';
% figure;
% plot(escala_t*10^6,ecoChirp20,'b-','LineWidth',1);
% hold on;
% plot(escala_t*10^6,b,'r--','LineWidth',1.5);
% title('Sinal retroespalhado (linha A)','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend('Sinal de RF','Envelope');
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
% figure;
% plot(escala_x*10^3,ecoChirp20,'b-','LineWidth',1);
% hold on;
% plot(escala_x*10^3,b,'r--','LineWidth',1.5);
% title('Sinal retroespalhado (linha A)','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend('Sinal de RF','Envelope');
% xlabel('Profundidade (mm)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude (u.a.)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
% %--------------------------------------
% % Inverte (flip) do vetor do sinal
% %--------------------------------------
% %tapChirpREAL = fliplr(chirp20(16090:16890)')'; % MUDAR INTERVALO... chirp enviado para o transdutor capturado pelo sistema de aquisi��o
% tapChirpREAL = fliplr(chirp20')'; % MUDAR INTERVALO... chirp enviado para o transdutor capturado pelo sistema de aquisi��o
% [N,M]=size(tapChirpREAL);
% % escala = (1:1:N)/samplingFreq;
% escala = (0:1:N-1)/samplingFreq2;
%
% figure;
% plot(escala*1e6,tapChirpREAL,'b-','LineWidth',0.8);
% title('Sinal chirp com tap real fliplr - tapChirpREAL','FontName',FontName,...
%     'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% figure;
% subplot(2,1,1);
% plot(escala*1e6,chirp20,'b-','LineWidth',0.8);
% title('Pulso - chirp20','FontName',FontName,...
%     'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% subplot(2,1,2);
% plot(escala*1e6,tapChirpREAL,'b-','LineWidth',0.8);
% title('Sinal chirp com tap real fliplr - tapChirpREAL','FontName',FontName,...
%     'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
%
% %------------------------------------
% % Filtro com o mesmo tamanho do vetor com perfil Gaussuiano
% %------------------------------------
% wn = usGenWindowFilter_TiagoMMachado(tapChirpREAL, 60,'chebyshev');
%
% wn = wn';
% [N,M]=size(wn);
% % escala = (1:1:N)/samplingFreq;
% escala = (0:1:N-1)/samplingFreq2; %frequencia de amostragem de 40MHz na recep��o
% figure;
% plot(escala*1e6, wn,'b-','LineWidth',0.8);
% title('Sinal chirp com tap','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% %----------------------------------------------------------
% %Sinal flip com aplica��o do filtro com perfil Gaussiano
% %Filtro mismatchFilt (descasado)
% %----------------------------------------------------------
% %wn = wn';
% mismatchFilt = wn.*tapChirpREAL;
% [N,M]=size(mismatchFilt);
% % escala = (1:1:N)/samplingFreq;
% escala = (1:1:N)/samplingFreq2;
% figure;
% plot(escala*1e6,mismatchFilt,'b-','LineWidth',0.8);
% title('mismatchFilt','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% %----------------------------------------------------------
% %Sinal flip sem aplica��o do filtro com perfil Gaussiano
% %Filtro matchFilt (casado)
% %Convolu��o do sinal de eco com o filtro matchFilt (casado)
% %----------------------------------------------------------
%
% matchFilt = tapChirpREAL;
% mismatchFilt_RF = conv(ecoChirp20, mismatchFilt); % ecoChirp20 � o RAW data capturado
% matchFilt_RF = conv(ecoChirp20, matchFilt);
%
% [N,M]=size(tapChirpREAL);
% % escala = (1:1:N)/samplingFreq;
% escala = (0:1:N-1)/samplingFreq2;
% figure;
% plot(escala*1e6,tapChirpREAL,'b-','LineWidth',0.8);
% title('tapChirpREAL','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
%
% [N,M]=size(mismatchFilt_RF);
% % escala = (1:1:N)/samplingFreq;
% escala = (0:1:N-1)/samplingFreq2; %amostragem de 40MHz na recep��o
% figure;
% plot(escala*1e3,mismatchFilt_RF,'b-','LineWidth',0.8);
% hold on;
% plot(escala*1e3,abs(hilbert(mismatchFilt_RF)),'r-','LineWidth',0.8);
% legend('Sinal Mismatch','Envelope');
% title('mismatchFilt RF','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% [N,M]=size(ecoChirp20);
% escala = (0:1:N-1)/samplingFreq2;
%
% a = ecoChirp20./max(abs(ecoChirp20));
% b = conv(ecoChirp20, matchFilt)./max(abs(conv(ecoChirp20, matchFilt)));
% c = conv(ecoChirp20, mismatchFilt)./max(abs(conv(ecoChirp20, mismatchFilt)));
%
% [X,Y]=size(b);
% escala_conv = (0:1:X-1)/samplingFreq2;
%
% figure;
%
% %plot(ecoChirp20./max(abs(ecoChirp20))), hold on, plot(conv(ecoChirp20, matchFilt)./max(abs(conv(ecoChirp20, matchFilt)))), plot(conv(ecoChirp20, mismatchFilt)./max(abs(conv(ecoChirp20, mismatchFilt))))
% plot(escala*1e3,a,'b-','LineWidth',0.8);
% hold on;
% plot(escala_conv*1e3,b,'k-','LineWidth',0.8);
% hold on;
% plot(escala_conv*1e3,c,'r-','LineWidth',0.8);
% legend('ecoChirp20','ecoChirp20 matchFilt','ecoChirp20 mismatchFilt');
% xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% figure;
% subplot(3,1,1);
% plot(escala*1e3,a,'b-','LineWidth',0.8);
% legend('ecoChirp20');
% axis tight;
% subplot(3,1,2);
% plot(escala_conv*1e3,b,'b-','LineWidth',0.8);
% hold on;
% plot(escala_conv*1e3,abs(hilbert(b)),'r-','LineWidth',0.8);
% legend('ecoChirp20 matchFilt','Envelope');
% axis tight;
% subplot(3,1,3);
% plot(escala_conv*1e3,c,'b-','LineWidth',0.8);
% hold on;
% plot(escala_conv*1e3,abs(hilbert(c)),'r-','LineWidth',0.8);
% legend('ecoChirp20 mismatchFilt','Envelope');
% xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% %ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
% %     'FontSize',FontSizeXlabel);
% axis tight;
%
% figure;
% subplot(2,1,1);
% plot(escala*1e3,a,'b-','LineWidth',0.8);
% legend('ecoChirp20');
% axis tight;
% subplot(2,1,2);
% plot(escala_conv*1e3,b,'b-','LineWidth',0.8);
% hold on;
% plot(escala_conv*1e3,abs(hilbert(b)),'r-','LineWidth',0.8);
% legend('ecoChirp20 matchFilt','Envelope');
% axis tight;
% xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% %ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
% %     'FontSize',FontSizeXlabel);
%
%
% figure;
% subplot(2,1,1);
% plot(escala*1e3,a,'b-','LineWidth',0.8);
% legend('ecoChirp20');
% axis tight;
% subplot(2,1,2);
% plot(escala_conv*1e3,c,'b-','LineWidth',0.8);
% hold on;
% plot(escala_conv*1e3,abs(hilbert(c)),'r-','LineWidth',0.8);
% legend('ecoChirp20 mismatchFilt','Envelope');
% axis tight;
% xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% %ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
% %     'FontSize',FontSizeXlabel);
%
% %-----------------------------------
% % FFT do sinal com sinal de eco bruto
% %-----------------------------------
% [N,M]=size(a);
%
% phantom_fft = zeros(2^12,1);
% phantom_fft(1:N,1) = a;
%
% % N�mero de amostras para a FFT
% NFFT = length(phantom_fft);
% N = NFFT;
%
% Y1 = fft(phantom_fft);
%
% f=(fs*(0:(N-2)/2)/N)';
% f=f*1e-6;
%
% sinal_fft = abs(Y1(1:(N/4))/N);
% sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
%
% figure;
% %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
% plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
% title('Espectro do sinal bruto de RF','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% %legend('Eco');
% grid on;
% xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
%
% %-----------------------------------
% % FFT do sinal com sinal de com filtro casado
% %-----------------------------------
% [N,M]=size(b);
%
% phantom_fft = zeros(2^12,1);
% phantom_fft(1:N,1) = b;
%
% % N�mero de amostras para a FFT
% NFFT = length(phantom_fft);
% N = NFFT;
%
% Y1 = fft(phantom_fft);
%
% f=(fs*(0:(N-2)/2)/N)';
% f=f*1e-6;
%
% sinal_fft = abs(Y1(1:(N/4))/N);
% sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
%
% figure;
% %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
% plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
% title('Espectro do sinal bruto com aplica��o de filtro casado','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% %legend('Eco');
% grid on;
% xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
% %-----------------------------------
% % FFT do sinal com sinal de com filtro descasado
% %-----------------------------------
% [N,M]=size(c);
%
% phantom_fft = zeros(2^12,1);
% phantom_fft(1:N,1) = c;
%
% % N�mero de amostras para a FFT
% NFFT = length(phantom_fft);
% N = NFFT;
%
% Y1 = fft(phantom_fft);
%
% f=(fs*(0:(N-2)/2)/N)';
% f=f*1e-6;
%
% sinal_fft = abs(Y1(1:(N/4))/N);
% sinal_fft_0 = 20*log10(sinal_fft/max(sinal_fft));
%
% figure;
% %plot(f(1:NFFT/4),sinal_fft_1,'--r','LineWidth',1);
% plot(f(1:NFFT/4),sinal_fft_0,'b-','LineWidth',1);
% title('Espectro do sinal bruto com aplica��o de filtro descasado','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% %legend('Eco');
% grid on;
% xlabel('Frequ�ncia (MHz)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Magnitude (dB)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
%
%
%
% break;
%
%
%
%
%
%
% %% Leitura dos dados de arquivo do tipo csv
%
%
% %----------------------------------------------------------
% % Leitura do primeiro arquivo *.csv referente ao pulso (variavel chirp20)
% %----------------------------------------------------------
% [filename1,path] = uigetfile('*.csv','Selecione o arquivo referente ao PULSO (chirp*.cvs');
% if isequal(filename1,0)
%     disp('User selected Cancel');
%     return;
% else
%     disp(['Arquivo 1 ', fullfile(path,filename1)]);
% end
%
% % Leitura da Tabela de dados
% T1 = readtable(filename1);
%
% % Convers�o de Tabela para vetor 2D
% A = table2array(T1);
% pulso = A(:,4);
%
% % [N,M] = size(A);
% % escala = (1:1:N);
% % figure;
% % plot(escala,A);
% % title(filename1);
% % % legend('1','2','3','4','5','6','7','8');
% % xlabel('Indice'); ylabel('Amplitude');
% % axis tight;
%
% %----------------------------------------------------------
% % Leitura do segundo arquivo *.csv referente ao pulso+eco
% %----------------------------------------------------------
% [filename2,path] = uigetfile('*.csv','Selecione o arquivo referente ao PULSO+ECO');
% if isequal(filename1,0)
%     disp('User selected Cancel');
%     return;
% else
%     disp(['Arquivo 2 ', fullfile(path,filename2)]);
% end
%
% % Leitura da Tabela de dados
% T2 = readtable(filename2);
%
% % Convers�o de Tabela para vetor 2D
% B = table2array(T2);
% pulso_eco = B(:,4);
%
% %----------------------------------------------------------
% % Plot da primeira onda e selecao de intervalo para processamento
% % Sinal pulso para sele��o de intervalo
% %----------------------------------------------------------
% fs = 40e6;
%
% [N,M] = size(pulso);
% %escala = (1:1:N)/samplingFreq*1e6;  % ajuste para escala em us
% escala = (0:1:N-1);
% escala_tempo = (0:1:N-1)/fs;
%
% figure;
% plot(escala,pulso,'b-','LineWidth',0.8);
% title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend('Eco');
% xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
% figure;
% plot(escala_tempo*1e3,pulso,'b-','LineWidth',0.8);
% title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend('Eco');
% xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
% figure;
% plot(escala_tempo*1e3,pulso,'b-','LineWidth',0.8);
% hold on;
% plot(escala_tempo*1e3,abs(hilbert(pulso)),'r-','LineWidth',0.8);
% title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend('Eco','Envelope');
% xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
% pulso_norm = pulso/max(abs(pulso));
%
% figure;
% plot(escala_tempo*1e3,pulso_norm,'b-','LineWidth',0.8);
% title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend('Eco');
% xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
%
% %Cria��o dos vetores de intervalor de amostras
% intervalo = zeros(2,1);
%
% %-------------------------------------------------------------------------
% % Teste para aplicar zoom na �rea selecionada
% % O la�o � repetido caso a tecla pressionada ao final seja diferente de 1
% %-------------------------------------------------------------------------
% teste = 0;              % valor inicial para o la�o
%
% while (teste ~= 1)
%     %Leitura do intervalo entre as amostras
%     intervalo(1) = input('Digite o intervalo inicial (�ndice) do sinal PULSO: ');
%     intervalo(2) = input('Digite o intervalo final (�ndice) do sinal PULSO: ');
%
%     figure;
%     plot(escala,pulso,'b-','LineWidth',0.8);
%     title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     legend('Pulso');
%     xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeYlabel);
%     axis tight;
%
%     figure;
%     plot(escala,pulso,'b-','LineWidth',0.8);
%     title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     legend('Pulso');
%     xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeYlabel);
%     axis ([intervalo(1) intervalo(2) ...
%         min(min(A(intervalo(1):intervalo(2),:))) max(max(A(intervalo(1):intervalo(2),:)))]);
%
%     figure;
%     plot(escala,pulso,'b-','LineWidth',0.8);
%     hold on;
%     plot(escala,abs(hilbert(pulso)),'r-','LineWidth',0.8);
%     title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
%     % grid on;);
%     legend('Pulso','Envelope');
%     xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeXlabel);
%     ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%         'FontSize',FontSizeYlabel);
%
%     axis ([intervalo(1) intervalo(2) ...
%         min(min(A(intervalo(1):intervalo(2),:))) max(max(A(intervalo(1):intervalo(2),:)))]);
%
%     teste = input('Repetir ajuste? Digite 1 para nao repetir: ');
%
% end;
%
% disp('Selecao apresentada');
%
% chirp20 = pulso(intervalo(1):intervalo(2),1);
% ecoChirp20 = pulso_eco;
%
% [N,M] = size(chirp20);
%
% escala_amostra_pulso = 0:1:N-1;
% escala_tempo_pulso = escala_amostra_pulso/fs;
%
% [N,M] = size(ecoChirp20);
%
% escala_amostra_pulso_eco = 0:1:N-1;
% escala_tempo_pulso_eco = escala_amostra_pulso_eco/fs;
%
% figure;
% subplot(2,1,1);
% plot(chirp20,'b-','LineWidth',0.8);
% title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend('Pulso - chirp20');
% xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% subplot(2,1,2);
% plot(ecoChirp20);
% title(filename2);
% legend('Pulso + Eco - ecoChirp20');
% xlabel('�ndice','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
% figure;
% subplot(2,1,1);
% plot(escala_tempo_pulso,chirp20,'b-','LineWidth',0.8);
% title(filename1,'FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% legend('Pulso - chirp20');
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% subplot(2,1,2);
% plot(escala_tempo_pulso_eco, ecoChirp20);
% title(filename2);
% legend('Pulso + Eco - ecoChirp20');
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeYlabel);
% axis tight;
%
% % [N,M] = size(pulso_eco);
% % %escala = (1:1:N)/samplingFreq*1e6;  % ajuste para escala em us
% % escala = (1:1:N);
% %
% % figure;
% % plot(escala,pulso_eco);
% % %title('Sinal 2')
% % title(filename2);
% % legend('Pulso Eco');
% % %xlabel('Tempo (us)');ylabel('Amplitude');
% % xlabel('Indice');ylabel('Amplitude');
% % axis tight;
%
% %return;
%
%
% %% CHIRP (OR LINEAR FREQUENCY MODULATION) CONSTRUCTION
%
% %chirp20 = zeros(20000,1);
% %chirp20(16090:16890)=sinal_tapLFMchirp;
% %ecoChirp20 = zeros(20000,1);
% %posicao1 = 1000;
% %posicao2 = 5000;
% %posicao3 = 10000;
% %posicao4 = 15000;
% %ecoChirp20(posicao1:posicao1+800)=sinal_tapLFMchirp;
% %ecoChirp20(posicao2:posicao2+800)=sinal_tapLFMchirp;
% %ecoChirp20(posicao3:posicao3+800)=sinal_tapLFMchirp;
% %ecoChirp20(posicao4:posicao4+800)=sinal_tapLFMchirp;
%
% samplingFreq2=  40 * 10^6;        % *************frequencia de amostragem da recep��o de 40MHz
%
% %--------------------------------------
% % Inverte (flip) do vetor do sinal
% %--------------------------------------
%
% %tapChirpREAL = fliplr(chirp20(16090:16890)')'; % MUDAR INTERVALO... chirp enviado para o transdutor capturado pelo sistema de aquisi��o
% tapChirpREAL = fliplr(chirp20')'; % MUDAR INTERVALO... chirp enviado para o transdutor capturado pelo sistema de aquisi��o
% [N,M]=size(tapChirpREAL);
% % escala = (1:1:N)/samplingFreq;
% escala = (0:1:N-1)/samplingFreq2;
%
% figure;
% plot(escala*1e6,tapChirpREAL,'b-','LineWidth',0.8);
% title('Sinal chirp com tap real fliplr - tapChirpREAL','FontName',FontName,...
%     'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% figure;
% subplot(2,1,1);
% plot(escala*1e6,chirp20,'b-','LineWidth',0.8);
% title('Pulso - chirp20','FontName',FontName,...
%     'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% subplot(2,1,2);
% plot(escala*1e6,tapChirpREAL,'b-','LineWidth',0.8);
% title('Sinal chirp com tap real fliplr - tapChirpREAL','FontName',FontName,...
%     'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
%
% %------------------------------------
% % Filtro com o mesmo tamanho do vetor com perfil Gaussuiano
% %------------------------------------
% wn = usGenWindowFilter_TiagoMMachado(tapChirpREAL, 60,'chebyshev');
%
% wn = wn';
% [N,M]=size(wn);
% % escala = (1:1:N)/samplingFreq;
% escala = (0:1:N-1)/samplingFreq2; %frequencia de amostragem de 40MHz na recep��o
% figure;
% plot(escala*1e6, wn,'b-','LineWidth',0.8);
% title('Sinal chirp com tap','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% %----------------------------------------------------------
% %Sinal flip com aplica��o do filtro com perfil Gaussiano
% %Filtro mismatchFilt (descasado)
% %----------------------------------------------------------
% %wn = wn';
% mismatchFilt = wn.*tapChirpREAL;
% [N,M]=size(mismatchFilt);
% % escala = (1:1:N)/samplingFreq;
% escala = (1:1:N)/samplingFreq2;
% figure;
% plot(escala*1e6,mismatchFilt,'b-','LineWidth',0.8);
% title('mismatchFilt','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% %----------------------------------------------------------
% %Sinal flip sem aplica��o do filtro com perfil Gaussiano
% %Filtro matchFilt (casado)
% %Convolu��o do sinal de eco com o filtro matchFilt (casado)
% %----------------------------------------------------------
%
% matchFilt = tapChirpREAL;
% mismatchFilt_RF = conv(ecoChirp20, mismatchFilt); % ecoChirp20 � o RAW data capturado
% matchFilt_RF = conv(ecoChirp20, matchFilt);
%
% [N,M]=size(tapChirpREAL);
% % escala = (1:1:N)/samplingFreq;
% escala = (0:1:N-1)/samplingFreq2;
% figure;
% plot(escala*1e6,tapChirpREAL,'b-','LineWidth',0.8);
% title('tapChirpREAL','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (\mus)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
%
% [N,M]=size(mismatchFilt_RF);
% % escala = (1:1:N)/samplingFreq;
% escala = (0:1:N-1)/samplingFreq2; %amostragem de 40MHz na recep��o
% figure;
% plot(escala*1e3,mismatchFilt_RF,'b-','LineWidth',0.8);
% title('mismatchFilt RF','FontName',FontName,'FontWeight',FontWeight,'FontSize',FontSizeTitle);
% xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% [N,M]=size(ecoChirp20);
% escala = (0:1:N-1)/samplingFreq2;
%
% a = ecoChirp20./max(abs(ecoChirp20));
% b = conv(ecoChirp20, matchFilt)./max(abs(conv(ecoChirp20, matchFilt)));
% c = conv(ecoChirp20, mismatchFilt)./max(abs(conv(ecoChirp20, mismatchFilt)));
%
% [X,Y]=size(b);
% escala_conv = (0:1:X-1)/samplingFreq2;
%
% figure;
%
% %plot(ecoChirp20./max(abs(ecoChirp20))), hold on, plot(conv(ecoChirp20, matchFilt)./max(abs(conv(ecoChirp20, matchFilt)))), plot(conv(ecoChirp20, mismatchFilt)./max(abs(conv(ecoChirp20, mismatchFilt))))
% plot(escala*1e3,a,'b-','LineWidth',0.8);
% hold on;
% plot(escala_conv*1e3,b,'k-','LineWidth',0.8);
% hold on;
% plot(escala_conv*1e3,c,'r-','LineWidth',0.8);
% legend('ecoChirp20','ecoChirp20 matchFilt','ecoChirp20 mismatchFilt');
% xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% ylabel('Amplitude Normalizada','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% axis tight;
%
% figure;
% subplot(3,1,1);
% plot(escala*1e3,a,'b-','LineWidth',0.8);
% legend('ecoChirp20');
% axis tight;
% subplot(3,1,2);
% plot(escala_conv*1e3,b,'k-','LineWidth',0.8);
% legend('ecoChirp20 matchFilt');
% axis tight;
% subplot(3,1,3);
% plot(escala_conv*1e3,c,'r-','LineWidth',0.8);
% legend('ecoChirp20 mismatchFilt');
% xlabel('Tempo (ms)','FontName',FontName,'FontWeight',FontWeight,...
%     'FontSize',FontSizeXlabel);
% %ylabel('Amplitude','FontName',FontName,'FontWeight',FontWeight,...
% %     'FontSize',FontSizeXlabel);
% axis tight;
%
